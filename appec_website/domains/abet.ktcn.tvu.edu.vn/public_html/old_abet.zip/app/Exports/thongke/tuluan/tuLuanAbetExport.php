<?php

namespace App\Exports\thongke\tuluan;

use Maatwebsite\Excel\Concerns\FromCollection;

class tuLuanAbetExport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        //
    }
}
