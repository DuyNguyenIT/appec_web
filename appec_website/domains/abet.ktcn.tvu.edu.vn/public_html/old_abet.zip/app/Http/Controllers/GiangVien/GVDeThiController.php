<?php

namespace App\Http\Controllers\giangvien;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class GVDeThiController extends Controller
{
    
}
