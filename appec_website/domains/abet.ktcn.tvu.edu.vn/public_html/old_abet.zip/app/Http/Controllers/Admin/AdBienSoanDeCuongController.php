<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AdBienSoanDeCuongController extends Controller
{
    public function index()
    {
       
    }

    public function them(Request $request)
    {
        
    }

    public function sua(Request $request)
    {
        
    }

    public function xoa(Type $var = null)
    {
        
    }
}
