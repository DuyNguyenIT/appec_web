<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class coNDQuyHoach extends Model
{
    //model này không biết dùng làm gì -- không dám xóa>>>????
    use HasFactory;
    protected $table='co_ndqh';
}
