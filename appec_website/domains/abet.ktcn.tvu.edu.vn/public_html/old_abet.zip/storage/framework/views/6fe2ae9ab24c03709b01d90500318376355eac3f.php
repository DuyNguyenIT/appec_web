<h5><b>2.<?php echo e(__('Learning resources')); ?></b></h5>
<table class="table table-bordered">
    <tr>
        <td><?php echo e(__('Books ')); ?></td>
        <td style="text-align: justify">
            <?php if($tailieu): ?>
                <?php echo $tailieu->giaoTrinh; ?>

            <?php endif; ?>
        </td>
        <td>
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addgiaoTrinh">
                <i class="fas fa-edit"></i>
            </button>
            <!-- Modal -->
            <div class="modal fade" id="addgiaoTrinh" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-lg" role="document">
                    <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/sua_giao_trinh')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Books ')); ?></h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <input type="text" name="maHocPhan" value="<?php echo e($hocPhan->maHocPhan); ?>" hidden>
                                </div>
                                <div class="form-group">
                                    <textarea name="giaoTrinh" id="giaoTrinh" cols="30" rows="10" class="form-control"
                                        required>
                                <?php if($tailieu): ?>
                                    <?php echo e($tailieu->giaoTrinh); ?>

                              <?php endif; ?>  
                              </textarea>
                                    <script>
                                        CKEDITOR.replace('giaoTrinh', {
                                            filebrowserUploadUrl: "<?php echo e(route('upload', ['_token' => csrf_token()])); ?>",
                                            filebrowserUploadMethod: 'form'
                                        });

                                    </script>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                <button type="button" class="btn btn-secondary"
                                    data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </td>
    </tr>
    <tr>
        <td><?php echo e(__('References')); ?></td>
        <td>
            <?php if($tailieu): ?>
                <?php echo $tailieu->thamKhaoThem; ?>

            <?php endif; ?>
        </td>
        <td>
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addthamKhaoThem">
                <i class="fas fa-edit"></i>
            </button>
            <!--///////////////////////////// Modal thêm tài liệu tham khảo thêm-->
            <div class="modal fade" id="addthamKhaoThem" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-lg" role="document">
                    <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/sua_tai_lieu_tham_khao_them')); ?>"
                        method="post">
                        <?php echo csrf_field(); ?>
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('References')); ?></h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <input type="text" name="maHocPhan" value="<?php echo e($hocPhan->maHocPhan); ?>" hidden>
                                </div>
                                <div class="form-group">
                                    <textarea name="thamKhaoThem" id="thamKhaoThem" cols="30" rows="10"
                                        class="form-control" required>
                                  <?php if($tailieu): ?>
                                      <?php echo e($tailieu->thamKhaoThem); ?>

                                <?php endif; ?>  
                                </textarea>
                                    <script>
                                        CKEDITOR.replace('thamKhaoThem', {
                                            filebrowserUploadUrl: "<?php echo e(route('upload', ['_token' => csrf_token()])); ?>",
                                            filebrowserUploadMethod: 'form'
                                        });

                                    </script>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                <button type="button" class="btn btn-secondary"
                                    data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </td>
    </tr>
    <tr>
        <td><?php echo e(__('Other learning materials')); ?></td>
        <td>
            <?php if($tailieu): ?>
                <?php echo $tailieu->taiLieuKhac; ?>

            <?php endif; ?>
        </td>
        <td>
            <!-- Button trigger modal -->
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addtaiLieuKhac">
                <i class="fas fa-edit"></i>
            </button>
            <!--//////////////////////// Modal thêm các loại tài liệu khác -->
            <div class="modal fade" id="addtaiLieuKhac" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-lg" role="document">
                    <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/sua_tai_lieu_khac')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Other learning materials ')); ?>

                                </h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <input type="text" name="maHocPhan" value="<?php echo e($hocPhan->maHocPhan); ?>" hidden>
                                </div>
                                <div class="form-group">
                                    <textarea name="taiLieuKhac" id="taiLieuKhac" cols="30" rows="10"
                                        class="form-control" required>
                            <?php if($tailieu): ?>
                                  <?php echo e($tailieu->taiLieuKhac); ?>

                            <?php endif; ?>  
                          </textarea>
                                    <script>
                                        CKEDITOR.replace('taiLieuKhac', {
                                            filebrowserUploadUrl: "<?php echo e(route('upload', ['_token' => csrf_token()])); ?>",
                                            filebrowserUploadMethod: 'form'
                                        });

                                    </script>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                <button type="button" class="btn btn-secondary"
                                    data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </td>
    </tr>
</table>
<?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/layouts/decuong/chitietnoidung/2_tailieuthamkhao.blade.php ENDPATH**/ ?>