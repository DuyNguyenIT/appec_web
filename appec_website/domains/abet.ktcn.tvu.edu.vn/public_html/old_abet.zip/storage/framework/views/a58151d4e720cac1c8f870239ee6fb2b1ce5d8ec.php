
<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">
                            Tự Luận<noscript></noscript>
                            <nav></nav>
                        </h1>
                    </div>
                    <!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(asset('giang-vien')); ?>">Trang chủ</a>
                            </li>
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(asset('giang-vien/ket-qua-danh-gia')); ?>"><?php echo e($hp->tenHocPhan); ?></a>
                            </li>
                            <li class="breadcrumb-item active">Tự luận</li>
                        </ol>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">
                                    <!-- Button trigger modal -->
                                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addOne">
                                        Chọn đề cho từng sinh viên
                                    </button>
                                    <!-- Button trigger modal -->
                                    <button type="button" class="btn btn-primary" data-toggle="modal"
                                        data-target="#exampleModal">
                                        Chọn đề cho cả lớp
                                    </button>
                                    <!-- Modal thêm 1-->
                                    <div class="modal fade" id="addOne" tabindex="-1" role="dialog"
                                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <form
                                                action="<?php echo e(asset('/giang-vien/ket-qua-danh-gia/tu-luan/them-mot-phieu-cham')); ?>"
                                                method="post">
                                                <?php echo csrf_field(); ?>
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Adding a new
                                                            Assessment Rubrics</h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                            <label for="">Chọn đề thi</label>
                                                            <select name="maDe" id="" class="form-control">
                                                                <?php $__currentLoopData = $deThi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($dt->maDe); ?>"><?php echo e($dt->maDeVB); ?>

                                                                    </option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="">Chọn sinh viên</label>
                                                            <select name="dssv[]" id="" class="form-control" multiple>
                                                                <?php $__currentLoopData = $dssv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($sv->maSSV); ?>">
                                                                        <?php echo e($sv->maSSV); ?>-- <?php echo e($sv->HoSV); ?>

                                                                        <?php echo e($sv->TenSV); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="submit" class="btn btn-primary">Save</button>
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">Cancel</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <!-- Modal thêm nhiều-->
                                    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog"
                                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <form
                                                action="<?php echo e(asset('/giang-vien/ket-qua-danh-gia/tu-luan/them-nhieu-phieu-cham')); ?>"
                                                method="post">
                                                <?php echo csrf_field(); ?>
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Thêm 1 đề thi cho cả
                                                            lớp</h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                            <label for="">Chọn đề thi</label>
                                                            <select name="maDe" id="" class="form-control">
                                                                <?php $__currentLoopData = $deThi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($dt->maDe); ?>">
                                                                        <?php echo e($dt->maDeVB); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="submit" class="btn btn-primary">Save</button>
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </h4>
                                <div class="card-tools">
                                    <a href="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/quy-hoach-ket-qua/'.session::get('maHocPhan').'/'.session::get('maBaiQH').'/'.session::get('maHK').'/'.session::get('namHoc').'/'.session::get('maLop'))); ?>" class="btn btn-secondary">
                                           <i class="fas fa-arrow-left"></i>
                                     </a>
                                </div>
                            </div>
                            
                            <!-- /.card-header -->
                            <div class="card-body">
                                <table id="example2" class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>STT</th>
                                            <th>Mã sinh viên</th>
                                            <th>Sinh viên thực hiện</th>
                                            <th>Mã đề</th>
                                            <th>Điểm đánh giá</th>
                                            <th>Trạng thái</th>
                                            <th>Tùy chọn</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $i = 1;
                                        ?>
                                        <?php $__currentLoopData = $phieucham; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($i++); ?></td>
                                                <td><?php echo e($data->maSSV); ?></td>
                                                <td><?php echo e($data->HoSV); ?> <?php echo e($data->TenSV); ?></td>
                                                <td><?php echo e($data->maDeVB); ?></td>
                                                <td><?php echo e($data->diemSo); ?></td>
                                                <td>
                                                    <?php if($data->trangThai == true): ?>
                                                        <span class="badge bg-success">Đã chấm</span>
                                                    <?php else: ?>
                                                        <span class="badge bg-warning">Chờ chấm</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if($data->trangThai == true): ?>
                                                    <a href="<?php echo e(asset('/giang-vien/ket-qua-danh-gia/tu-luan/xem-ket-qua-danh-gia-tu-luan/' . $data->maDe . '/' . $data->maSSV)); ?>"
                                                        class="btn btn-primary">Xem KQ</a>
                                                        <a href="<?php echo e(asset('/giang-vien/ket-qua-danh-gia/tu-luan/sua-diem-tu-luan/' . $data->maDe . '/' . $data->maSSV)); ?>"
                                                            class="btn btn-primary">Sửa</a>

                                                <?php else: ?>
                                                <a href="<?php echo e(asset('/giang-vien/ket-qua-danh-gia/tu-luan/sua-diem-tu-luan/' . $data->maDe . '/' . $data->maSSV)); ?>"
                                                    class="btn btn-primary">chấm</a>
                                                <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot></tfoot>
                                </table>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('giangvien.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2_Co Nam\1_source code\source code 31-5\resources\views/giangvien/ketqua/tuluan/ketquatuluan.blade.php ENDPATH**/ ?>