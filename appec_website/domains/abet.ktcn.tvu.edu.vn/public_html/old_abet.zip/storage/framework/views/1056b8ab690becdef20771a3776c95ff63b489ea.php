
<?php $__env->startSection('content'); ?>
    <script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
    <div class="content-wrapper" style="min-height: 96px;">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">
                            Câu hỏi thực hành<noscript></noscript>
                            <nav></nav>
                        </h1>
                    </div>
                    <!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(asset('/giang-vien')); ?>">Trang chủ</a></li>
                            <li class="breadcrumb-item">
                                Quy hoạch
                            </li>
                            <li class="breadcrumb-item ">
                                Ngân hàng câu hỏi
                            </li>
                            
                            <li class="breadcrumb-item active">Câu hỏi thực hành</li>
                        </ol>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        
        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title"></h3>
                                <h3 class="d-flex justify-content-between">
                                    <button type="button" class="btn btn-primary" data-toggle="modal"
                                        data-target="#exampleModal">
                                        <i class="fas fa-plus"></i>
                                    </button>
                                    <a href="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/quy-hoach-ket-qua/'.Session::get('maHocPhan').'/'.Session::get('maBaiQH').'/'.Session::get('maHK').'/'.Session::get('namHoc').'/'.Session::get('maLop'))); ?>"
                                        class="btn btn-secondary"><i class="fas fa-arrow-left"></i></a>
                                </h3>
                                <!-- Modal -->
                                <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog"
                                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-lg" role="document">
                                        <form
                                            action="<?php echo e(asset('/giang-vien/hoc-phan/chuong/muc/cau-hoi-thuc-hanh/them')); ?>"
                                            method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Add')); ?>

                                                    </h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <input type="text" name="maChuong" value="<?php echo e($chuong->id); ?>" id=""
                                                        hidden>
                                                        <div class="form-group">
                                                            <label for=""> Nội dung quy hoạch:</label>
                                                            <select name="maNoiDungQH" id="" class="form-control" required>
                                                                <?php $__currentLoopData = $ndqh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($nd->maNoiDungQH); ?>">
                                                                        <?php echo e($nd->tenNoiDungQH); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                    <div class="form-group">
                                                        <label for=""><?php echo e(__('Question content')); ?>:</label>
                                                        <textarea name="noiDungCauHoi" id="ckcontent" cols="30" rows="10"
                                                            class="form-control" required></textarea>
                                                        <script>
                                                            CKEDITOR.replace('ckcontent', {
                                                                filebrowserUploadUrl: "<?php echo e(route('uploadgv', ['_token' => csrf_token()])); ?>",
                                                                filebrowserUploadMethod: 'form'
                                                            });

                                                        </script>
                                                    </div>
                                                    
                                                    
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                                    <button type="button" class="btn btn-secondary"
                                                        data-dismiss="modal"><?php echo e(__('Cancle')); ?></button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <!-- /.card-header -->
                                <div class="card-body">
                                    <table id="example2" class="table table-bordered table-hover">
                                        <thead>
                                            <tr>
                                                <th><?php echo e(__('No.')); ?></th>
                                                <th><?php echo e(__('Question content')); ?></th>
                                                <th><?php echo e(__('SOs')); ?></th>
                                                <th><?php echo e(__('Option')); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                $i = 1;
                                            ?>
                                            <?php $__currentLoopData = $cauhoi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($i++); ?></td>
                                                    <td><?php echo html_entity_decode($x->noiDungCauHoi); ?></td>
                                                    <td><?php echo e($x->kqht->maKQHTVB); ?></td>
                                                    <td>
                                                        <div class="btn-group">
                                                            <!-- Button trigger modal -->
                                                            <button type="button" class="btn btn-primary"
                                                                data-toggle="modal"
                                                                data-target="#edit_<?php echo e($x->maCauHoi); ?>">
                                                                <li class="fas fa-edit"></li>
                                                            </button>
                                                            <a class="btn btn-danger" onclick="return confirm('Confirm?')"
                                                                href="<?php echo e(asset('/giang-vien/hoc-phan/chuong/muc/cau-hoi-thuc-hanh/xoa/' . $x->maCauHoi)); ?>">
                                                                <i class="fas fa-trash"></i>
                                                            </a>
                                                        </div>
                                                        <!-- Modal -->
                                                        <div class="modal fade" id="edit_<?php echo e($x->maCauHoi); ?>"
                                                            tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                                                            aria-hidden="true">
                                                            <div class="modal-dialog modal-lg" role="document">
                                                                <form
                                                                    action="<?php echo e(asset('/giang-vien/hoc-phan/chuong/muc/cau-hoi-thuc-hanh/sua')); ?>"
                                                                    method="post">
                                                                    <?php echo csrf_field(); ?>
                                                                    <div class="modal-content">
                                                                        <div class="modal-header">
                                                                            <h5 class="modal-title" id="exampleModalLabel">
                                                                                <?php echo e(__('Edit')); ?></h5>
                                                                            <button type="button" class="close"
                                                                                data-dismiss="modal" aria-label="Close">
                                                                                <span aria-hidden="true">&times;</span>
                                                                            </button>
                                                                        </div>
                                                                        <div class="modal-body">
                                                                            <input type="text" name="maChuong"
                                                                                value="<?php echo e($chuong->id); ?>" id="" hidden>
                                                                            <input type="text" name="maCauHoi"
                                                                                value="<?php echo e($x->maCauHoi); ?>" id="" hidden>
                                                                            <div class="form-group">
                                                                                <label for=""><?php echo e(__('Question content')); ?>:</label>
                                                                                <textarea name="noiDungCauHoi"
                                                                                    id="ckcontent_<?php echo e($x->maCauHoi); ?>"
                                                                                    cols="30" rows="10" class="form-control"
                                                                                    required>
                                                                                <?php echo e($x->noiDungCauHoi); ?>

                                                                                </textarea>
                                                                                <script>
                                                                                    CKEDITOR.replace(
                                                                                        'ckcontent_<?php echo e($x->maCauHoi); ?>', {
                                                                                            filebrowserUploadUrl: "<?php echo e(route('uploadgv', ['_token' => csrf_token()])); ?>",
                                                                                            filebrowserUploadMethod: 'form'
                                                                                        });

                                                                                </script>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <label for=""> <?php echo e(__('Studying results')); ?>:</label>
                                                                                <select name="maKQHT" id=""
                                                                                    class="form-control" required>
                                                                                    <?php $__currentLoopData = $kqht; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <option
                                                                                            value="<?php echo e($x->maKQHT); ?>">
                                                                                            <?php echo e($x->maKQHTVB); ?>-<?php echo e($x->tenKQHT); ?>

                                                                                        </option>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                        <div class="modal-footer">
                                                                            <button type="submit"
                                                                                class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                                                            <button type="button" class="btn btn-secondary"
                                                                                data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                                                                        </div>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        <tfoot></tfoot>
                                    </table>
                                </div>
                                <!-- /.card-body -->
                            </div>
                            <!-- /.card -->
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('giangvien.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/giangvien/hocphan/chuong/muc/cauhoi/index_thuchanh.blade.php ENDPATH**/ ?>