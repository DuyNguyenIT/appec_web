
<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="<?php echo e(asset('dist/css/foldertree.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist/css/hortreebootstrap.css')); ?>">

    <div class="content-wrapper" style="min-height: 22px;">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">
                            <?php echo e(__('Curriculum')); ?><noscript></noscript>
                            <nav></nav>
                        </h1>
                    </div>
                    <!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(asset('/quan-ly')); ?>"><?php echo e(__('Home')); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo e(__('Curriculum')); ?></li>
                        </ol>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>

        
        <section class="content">

            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">
                                    <button type="button" class="btn btn-primary" data-toggle="modal"
                                        data-target="#exampleModal">
                                        <i class="fas fa-plus"></i>
                                    </button>
                                    
                                    <!-- Modal -->
                                    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog"
                                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <form action="<?php echo e(asset('quan-ly/xem-chuong-trinh-dao-tao/them')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">
                                                            <?php echo e(__('Adding a new')); ?> <?php echo e(__('Curriculum')); ?></h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                            <label for=""><?php echo e(__('Curriculum name')); ?>:</label>
                                                            <input type="text" name="tenCT" class="form-control" required>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for=""><?php echo e(__('Education level')); ?></label>
                                                            <select name="maBac" id="" class="form-control" required>
                                                                <?php $__currentLoopData = $bac; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($x->maBac); ?>"><?php echo e($x->tenBac); ?>

                                                                    </option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for=""><?php echo e(__('Specialized')); ?></label>
                                                            <select name="maCNganh" id="" class="form-control" required>
                                                                <?php $__currentLoopData = $chuyennganh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($y->maCNganh); ?>">
                                                                        <?php echo e($y->tenCNganh); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for=""><?php echo e(__('Forms of training')); ?></label>
                                                            <select name="maHe" id="" class="form-control" required>
                                                                <?php $__currentLoopData = $he; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $z): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($z->maHe); ?>">
                                                                        <?php echo e($z->tenHe); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="submit"
                                                            class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </h3>
                            </div>
                            <!-- /.card-header -->
                        
                            
        <div class="card-body">   
            <div class="tree">                                 
            <ul>

                <?php $__currentLoopData = $XemctDaoTao; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                <li>     
                    <span>            
                        
                        <a style="color:rgb(141, 5, 5); text-decoration:none;" data-toggle="collapse" href="#Page_<?php echo e($ct->maCT); ?>"  aria-expanded="false" aria-controls="Page_<?php echo e($ct->maCT); ?>">
                            <i class="collapsed">
                                <i class="fas fa-folder"> </i>
                            </i>
                            <i class="expanded">
                                <i class="far fa-folder-open"> </i>
                            </i>       
                            <?php echo e($ct->tenCT); ?> -- <?php echo e($ct->soHocKy); ?> 
                        </a>
                    </span>
                <div id="Page_<?php echo e($ct->maCT); ?>" class="collapse">  
                <ul>                   
                <?php for($i=1;$i<=$ct->soHocKy;$i++): ?>
                    <li>                          
                            <span>
                                    <a style="color:#080808; text-decoration:none;" data-toggle="collapse" href="#Page_<?php echo e($ct->maCT.$i); ?>"  aria-expanded="false" aria-controls="Page_<?php echo e($ct->maCT.$i); ?>">
                            
                                    <i class="collapsed"><i class="fas fa-folder"></i></i>
                                    <i class="expanded"><i class="far fa-folder-open"></i></i>                        
                                        <b> Hoc Ky: <?php echo e($i); ?>   </b>
                                    </a>                      
                            </span>   
                            <div id="Page_<?php echo e($ct->maCT.$i); ?>" class="collapse"> 

                            <ul> 
                                <li>                          
                                    <span>
                                            <a style="color:#080808; text-decoration:none;" data-toggle="collapse" href="#Page_B<?php echo e($ct->maCT.$i); ?>"  aria-expanded="false" aria-controls="Page_<?php echo e($ct->maCT.$i); ?>">
                                    
                                            <i class="collapsed"><i class="fas fa-folder"></i></i>
                                            <i class="expanded"><i class="far fa-folder-open"></i></i>                        
                                                <b> HỌC PHAN BB   </b>
                                            </a>                      
                                    </span>   
                                    <div id="Page_B<?php echo e($ct->maCT.$i); ?>" class="collapse"> 

                                        <ul> <?php $__currentLoopData = $hocphan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($ct->maCT == $hp->maCT && $hp->phanPhoiHocKy==$i): ?>
                                                <?php $__currentLoopData = $hocphan_ten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hpt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                               
                                                    <?php if($hp->maHocPhan == $hpt->maHocPhan && $hp->maLoaiHocPhan=="BB"): ?>
                                                        <li>                                      
                                                            <i class="far fa-circle"></i>
                                                            <a href="<?php echo e(asset('quan-ly/hoc-phan/de-cuong-mon-hoc/' . $hp->maHocPhan)); ?>" >
                                                                <?php echo e($hpt->tenHocPhan); ?>  
                                                            </a>
                                                        </li>
                                                    <?php endif; ?>                                 
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>                
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
        
                                        </ul>

                                    </div>
                                </li>

                                <li>                          
                                    <span>
                                            <a style="color:#080808; text-decoration:none;" data-toggle="collapse" href="#Page_TC<?php echo e($ct->maCT.$i); ?>"  aria-expanded="false" aria-controls="Page_<?php echo e($ct->maCT.$i); ?>">
                                    
                                            <i class="collapsed"><i class="fas fa-folder"></i></i>
                                            <i class="expanded"><i class="far fa-folder-open"></i></i>                        
                                                <b> HỌC PHAN TC   </b>
                                            </a>                      
                                    </span>   
                                    <div id="Page_TC<?php echo e($ct->maCT.$i); ?>" class="collapse"> 

                                        <ul> <?php $__currentLoopData = $hocphan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($ct->maCT == $hp->maCT && $hp->phanPhoiHocKy==$i): ?>
                                                <?php $__currentLoopData = $hocphan_ten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hpt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                               
                                                    <?php if($hp->maHocPhan == $hpt->maHocPhan && $hp->maLoaiHocPhan=="TC"): ?>
                                                        <li>                                      
                                                            <i class="far fa-circle"></i>
                                                            <a href="<?php echo e(asset('quan-ly/hoc-phan/de-cuong-mon-hoc/' . $hp->maHocPhan)); ?>" >
                                                                <?php echo e($hpt->tenHocPhan); ?>  
                                                            </a>
                                                        </li>
                                                    <?php endif; ?>                                 
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>                
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
        
                                        </ul>

                                    </div>
                                </li>
                                
                                                    </div> 
                                                                            
                                            </li>
                                            <?php endfor; ?>
                                    </ul>
                                    </div>            
                                </li> 
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            </ul>    
                            </div>                             
                                                            
                            </div>                      
                            
                        
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
            <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    </div>
    <script src="<?php echo e(asset('dist/js/foldertree.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2_Co Nam\1_source code\source code 31-5\resources\views/admin/xemchuongtrinhDT.blade.php ENDPATH**/ ?>