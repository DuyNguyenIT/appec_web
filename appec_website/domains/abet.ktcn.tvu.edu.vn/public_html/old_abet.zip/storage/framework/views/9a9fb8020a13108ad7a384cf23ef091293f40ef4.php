
<link rel="stylesheet" href="<?php echo e(asset('dist/css/hortreebootstrap.css')); ?>">
<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">
                            <?php echo e(__('Assessment Planning')); ?><noscript></noscript>
                            <nav></nav>
                        </h1>
                    </div>
                    <!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(asset('giang-vien')); ?>"><?php echo e(__('Home')); ?></a>
                            </li>
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(asset('giang-vien/quy-hoach-danh-gia')); ?>">
                                    <?php echo e($hp->tenHocPhan); ?></a>
                            </li>
                            <li class="breadcrumb-item active">
                                <?php echo e(__('Assessment Planning')); ?>

                            </li>
                        </ol>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">
                                    <?php if($count_ct == 0): ?>
                                        <form action="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/chon-nhom-cong-thuc')); ?>"
                                            method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <label for="">Chọn nhóm công thức:</label>
                                                <select name="groupCT" id="" class="form-control">
                                                    <option value="1">
                                                        <?php
                                                            $n = $hocphan_loai_htdg_array->where('groupCT', 1)->count();
                                                            $cr = 0;
                                                        ?>
                                                        <?php $__currentLoopData = $hocphan_loai_htdg_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($cr != 0 && $cr < $n && $data->groupCT == 1): ?>
                                                                +
                                                                <?php
                                                                    $cr++;
                                                                ?>
                                                                <?php echo e($data->loaiHTDanhGia['maLoaiHTDG']); ?>*<?php echo e($data->trongSo); ?>%
                                                            <?php elseif($data->groupCT==1): ?>
                                                                <?php
                                                                    $cr++;
                                                                ?>
                                                                <?php echo e($data->loaiHTDanhGia['maLoaiHTDG']); ?>*<?php echo e($data->trongSo); ?>%
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </option>
                                                    <?php
                                                        $n = $hocphan_loai_htdg_array->where('groupCT', 2)->count();
                                                        $cr = 0;
                                                    ?>
                                                    <?php if($n > 0): ?>
                                                        <option value="2">
                                                            <?php $__currentLoopData = $hocphan_loai_htdg_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($cr != 0 && $cr < $n && $data->groupCT == 2): ?>
                                                                    +
                                                                    <?php
                                                                        $cr++;
                                                                    ?>
                                                                    <?php echo e($data->loaiHTDanhGia['maLoaiHTDG']); ?>*<?php echo e($data->trongSo); ?>%
                                                                <?php elseif($data->groupCT==2): ?>
                                                                    <?php
                                                                        $cr++;
                                                                    ?>
                                                                    <?php echo e($data->loaiHTDanhGia['maLoaiHTDG']); ?>*<?php echo e($data->trongSo); ?>%
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </option>
                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                            <button type="submit" class="btn btn-primary">
                                                <i class="fas fa-plus"></i> <?php echo e(__('Choose')); ?>

                                            </button>
                                    <?php endif; ?>
                                    </form>
                                </h3>
                                <div class="card-tools">
                                    <a href="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia')); ?>" class="btn btn-secondary"><i
                                            class="fas fa-arrow-left"></i></a>
                                </div>
                            </div>
                            <div class="card-body">
                                <?php if($count_ndqh==0): ?>
                                <a title="Delete" class="btn btn-danger"
                                    onclick="return confirm('Confirm?')"
                                    href="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/xoa-nhom-cong-thuc/'.Session::get('maBaiQH'))); ?>">
                                <i class="fa fa-trash"></i> Xóa công thức
                            </a>
                                <?php endif; ?>
                                
                                <div class="tree ">
                                    <ul>
                                        <li><span><a style="color:#000; text-decoration:none;" data-toggle="collapse"
                                                    href="#Web" aria-expanded="true" aria-controls="Web"><i
                                                        class="collapsed"><i class="fas fa-folder"></i></i>
                                                    <i class="expanded"><i class="far fa-folder-open"></i></i>
                                                    <?php echo e(__('Course')); ?>: <?php echo e($gd[0]->tenHocPhan); ?> --
                                                    <?php echo e(__('Semester')); ?>: <?php echo e($gd[0]->maHK); ?> --
                                                    <?php echo e(__('Academic year')); ?>: <?php echo e($gd[0]->namHoc); ?> --||--
                                                    <?php echo e(__('Class ID')); ?>: <?php echo e($gd[0]->maLop); ?></a></span>
                                            <div id="Web" class="collapse show">
                                                <ul>
                                                    
                                                    <?php $__currentLoopData = $qh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li>
                                                            <span><a style="color:#000; text-decoration:none;"
                                                                    data-toggle="collapse"
                                                                    href="#Page_<?php echo e($x->maCTBaiQH); ?>"
                                                                    aria-expanded="false"
                                                                    aria-controls="Page_<?php echo e($x->maCTBaiQH); ?>"><i
                                                                        class="collapsed"><i class="fas fa-folder"></i></i>
                                                                    <i class="expanded"><i
                                                                            class="far fa-folder-open"></i></i>
                                                                    <?php if(Session::has('language') && Session::get('language') == 'en'): ?>
                                                                        <?php echo e($x->tenLoaiDG_EN); ?>

                                                                    <?php else: ?>
                                                                        <?php echo e($x->tenLoaiDG); ?>

                                                                    <?php endif; ?> --
                                                                    <?php if(Session::has('language') && Session::get('language') == 'en'): ?>
                                                                        <?php echo e($x->tenLoaiHTDG_EN); ?>

                                                                    <?php else: ?>
                                                                        <?php echo e($x->tenLoaiHTDG); ?>

                                                                    <?php endif; ?> -- <?php echo e($x->trongSo); ?>%
                                                                </a></span>
                                                            <ul>
                                                                <div id="Page_<?php echo e($x->maCTBaiQH); ?>" class="collapse">
                                                                    <li><span><i class="far fa-circle"></i><a 
                                                                                href="<?php echo e(asset('giang-vien/quy-hoach-danh-gia/noi-dung-quy-hoach/' . $x->maCTBaiQH)); ?>">
                                                                                1.
                                                                                <?php echo e(__('Planning Content')); ?></a></span>
                                                                    </li>
                                                                    <?php if($x->maLoaiHTDG == 'T8' ||  $x->maLoaiHTDG == 'T6'): ?>
                                                                        <li><span><i class="far fa-circle"></i><a 
                                                                                    href="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/noi-dung-danh-gia/xem-tieu-chi-danh-gia/' . $x->maCTBaiQH)); ?>">
                                                                                    2.
                                                                                    <?php echo e(__('Assessment form')); ?></a></span>
                                                                        </li>
                                                                        <li><span><i class="far fa-circle"></i><a 
                                                                                    href="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/noi-dung-danh-gia/xem-noi-dung-danh-gia/' . $x->maCTBaiQH)); ?>">
                                                                                    3.
                                                                                    <?php echo e(__('Project title')); ?></a></span>
                                                                        </li>
                                                                    <?php else: ?>
                                                                        
                                                                        <?php if($x->maLoaiHTDG == 'T1'): ?>
                                                                            <li><span><a style="color:#000; text-decoration:none;"
                                                                                        data-toggle="collapse"
                                                                                        href="#store_<?php echo e($x->maCTBaiQH); ?>"
                                                                                        aria-expanded="false"
                                                                                        aria-controls="store_<?php echo e($x->maCTBaiQH); ?>"><i
                                                                                            class="collapsed"><i
                                                                                                class="fas fa-folder"></i></i>
                                                                                        <i class="expanded"><i
                                                                                                class="far fa-folder-open"></i></i>
                                                                                        2. <?php echo e(__('Questions store')); ?>

                                                                                        <?php if(Session::has('language') && Session::get('language') == 'en'): ?>
                                                                                            (<?php echo e($x->tenLoaiHTDG_EN); ?>)
                                                                                        <?php else: ?>
                                                                                            (<?php echo e($x->tenLoaiHTDG); ?>)
                                                                                        <?php endif; ?>
                                                                                    </a></span>
                                                                                <ul>
                                                                                    <div id="store_<?php echo e($x->maCTBaiQH); ?>"
                                                                                        class="collapse">
                                                                                        <?php $__currentLoopData = $chuong; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                            <li><span><a style="color:#000; text-decoration:none;"
                                                                                                        data-toggle="collapse"
                                                                                                        href="#chapter_<?php echo e($x->maLoaiHTDG); ?>_<?php echo e($ch->id); ?>"
                                                                                                        aria-expanded="false"
                                                                                                        aria-controls="chapter_<?php echo e($x->maLoaiHTDG); ?>_<?php echo e($ch->id); ?>"><i
                                                                                                            class="collapsed"><i
                                                                                                                class="fas fa-folder"></i></i>
                                                                                                        <i class="expanded"><i
                                                                                                                class="far fa-folder-open"></i></i>
                                                                                                        <?php echo e($ch->tenchuong); ?></a></span>
                                                                                                <ul>
                                                                                                    <div id="chapter_<?php echo e($x->maLoaiHTDG); ?>_<?php echo e($ch->id); ?>"
                                                                                                        class="collapse">
                                                                                                        <?php $__currentLoopData = $ch->muc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                            <li><span><i
                                                                                                                        class="far fa-file"></i><a 
                                                                                                                        href="<?php echo e(asset('giang-vien/quy-hoach-danh-gia/noi-dung-danh-gia/ngan-hang-cau-hoi-tu-luan/' . $m->id.'/'.$x->maCTBaiQH)); ?>">
                                                                                                                        <?php echo e($m->maMucVB); ?>

                                                                                                                        <?php echo e($m->tenMuc); ?></a></span>
                                                                                                            </li>
                                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                    </div>
                                                                                                </ul>
                                                                                            </li>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                </ul>
                                                                            </li>
                                                                        <?php else: ?>
                                                                            
                                                                            <?php if($x->maLoaiHTDG == 'T2'): ?>
                                                                                <li><span><a style="color:#000; text-decoration:none;"
                                                                                            data-toggle="collapse"
                                                                                            href="#store_<?php echo e($x->maCTBaiQH); ?>"
                                                                                            aria-expanded="false"
                                                                                            aria-controls="store_<?php echo e($x->maCTBaiQH); ?>"><i
                                                                                                class="collapsed"><i
                                                                                                    class="fas fa-folder"></i></i>
                                                                                            <i class="expanded"><i
                                                                                                    class="far fa-folder-open"></i></i>
                                                                                            2.
                                                                                            <?php echo e(__('Questions store')); ?>

                                                                                            <?php if(Session::has('language') && Session::get('language') == 'en'): ?>
                                                                                                (<?php echo e($x->tenLoaiHTDG_EN); ?>)
                                                                                            <?php else: ?>
                                                                                                (<?php echo e($x->tenLoaiHTDG); ?>)
                                                                                            <?php endif; ?>
                                                                                        </a></span>
                                                                                    <ul>
                                                                                        <div id="store_<?php echo e($x->maCTBaiQH); ?>"
                                                                                            class="collapse">
                                                                                            <?php $__currentLoopData = $chuong; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                <li><span><a style="color:#000; text-decoration:none;"
                                                                                                            data-toggle="collapse"
                                                                                                            href="#chapter_<?php echo e($x->maLoaiHTDG); ?>_<?php echo e($ch->id); ?>"
                                                                                                            aria-expanded="false"
                                                                                                            aria-controls="chapter_<?php echo e($x->maLoaiHTDG); ?>_<?php echo e($ch->id); ?>"><i
                                                                                                                class="collapsed"><i
                                                                                                                    class="fas fa-folder"></i></i>
                                                                                                            <i
                                                                                                                class="expanded"><i
                                                                                                                    class="far fa-folder-open"></i></i>
                                                                                                            <?php echo e($ch->tenchuong); ?></a></span>
                                                                                                    <ul>
                                                                                                        <div id="chapter_<?php echo e($x->maLoaiHTDG); ?>_<?php echo e($ch->id); ?>"
                                                                                                            class="collapse">
                                                                                                            <?php $__currentLoopData = $ch->muc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                                <li><span><i
                                                                                                                            class="far fa-file"></i><a 
                                                                                                                            href="<?php echo e(asset('giang-vien/quy-hoach-danh-gia/noi-dung-danh-gia/ngan-hang-cau-hoi-trac-nghiem/' . $m->id.'/'.$x->maCTBaiQH)); ?>">
                                                                                                                            <?php echo e($m->maMucVB); ?>

                                                                                                                            <?php echo e($m->tenMuc); ?></a></span>
                                                                                                                </li>
                                                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                        </div>
                                                                                                    </ul>
                                                                                                </li>
                                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                    </ul>
                                                                                </li>
                                                                            <?php else: ?>
                                                                                
                                                                                <?php if($x->maLoaiHTDG == 'T3'): ?>
                                                                                    <li><span><a style="color:#000; text-decoration:none;"
                                                                                                data-toggle="collapse"
                                                                                                href="#store_<?php echo e($x->maCTBaiQH); ?>"
                                                                                                aria-expanded="false"
                                                                                                aria-controls="store_<?php echo e($x->maCTBaiQH); ?>"><i
                                                                                                    class="collapsed"><i
                                                                                                        class="fas fa-folder"></i></i>
                                                                                                <i class="expanded"><i
                                                                                                        class="far fa-folder-open"></i></i>
                                                                                                2.
                                                                                                <?php echo e(__('Questions store')); ?>

                                                                                                <?php if(Session::has('language') && Session::get('language') == 'en'): ?>
                                                                                                    (<?php echo e($x->tenLoaiHTDG_EN); ?>)
                                                                                                <?php else: ?>
                                                                                                    (<?php echo e($x->tenLoaiHTDG); ?>)
                                                                                                <?php endif; ?>
                                                                                            </a></span>
                                                                                        <ul>
                                                                                            <div id="store_<?php echo e($x->maCTBaiQH); ?>"
                                                                                                class="collapse">
                                                                                                <?php $__currentLoopData = $chuong; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                    <li><span><a style="color:#000; text-decoration:none;"
                                                                                                                data-toggle="collapse"
                                                                                                                href="#chapter_<?php echo e($x->maLoaiHTDG); ?>_<?php echo e($ch->id); ?>"
                                                                                                                aria-expanded="false"
                                                                                                                aria-controls="chapter_<?php echo e($x->maLoaiHTDG); ?>_<?php echo e($ch->id); ?>"><i
                                                                                                                    class="collapsed"><i
                                                                                                                        class="fas fa-folder"></i></i>
                                                                                                                <i
                                                                                                                    class="expanded"><i
                                                                                                                        class="far fa-folder-open"></i></i>
                                                                                                                <?php echo e($ch->tenchuong); ?></a></span>
                                                                                                        <ul>
                                                                                                            <div id="chapter_<?php echo e($x->maLoaiHTDG); ?>_<?php echo e($ch->id); ?>"
                                                                                                                class="collapse">
                                                                                                                <?php $__currentLoopData = $ch->muc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                                    <li><span><i
                                                                                                                                class="far fa-file"></i><a 
                                                                                                                                href="<?php echo e(asset('giang-vien/quy-hoach-danh-gia/noi-dung-danh-gia/ngan-hang-cau-hoi-thuc-hanh/' . $m->id.'/'.$x->maCTBaiQH)); ?>">
                                                                                                                                <?php echo e($m->maMucVB); ?>

                                                                                                                                <?php echo e($m->tenMuc); ?></a></span>
                                                                                                                    </li>
                                                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                                        </ul>
                                                                                                    </li>
                                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                        </ul>
                                                                                    </li>
                                                                                <?php endif; ?>
                                                                            <?php endif; ?>
                                                                        <?php endif; ?>
                                                                        <li><span><i class="far fa-circle"></i><a 
                                                                                    href="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/noi-dung-danh-gia/xem-noi-dung-danh-gia/'.$x->maCTBaiQH)); ?>">
                                                                                    3. <?php echo e(__('Examination')); ?></a></span>
                                                                        </li>
                                                                    <?php endif; ?>
                                                                    <li><span><i class="far fa-circle"></i><a 
                                                                                href="<?php echo e(asset('/giang-vien/ket-qua-danh-gia/nhap-ket-qua-danh-gia/'.$x->maCTBaiQH)); ?>">
                                                                                4. <?php echo e(__('Result')); ?></a></span></li>
                                                                    <li>
                                                                                <span><a style="color:#000; text-decoration:none;"
                                                                                    data-toggle="collapse"
                                                                                    href="#Statistics_<?php echo e($x->maCTBaiQH); ?>"
                                                                                    aria-expanded="false"
                                                                                    aria-controls="store_<?php echo e($x->maCTBaiQH); ?>"><i
                                                                                        class="collapsed"><i
                                                                                            class="fas fa-folder"></i></i>
                                                                                    <i class="expanded"><i
                                                                                            class="far fa-folder-open"></i></i>
                                                                                    5. <?php echo e(__('Statistics')); ?>

                                                                                </a></span>
                                                                        <ul>
                                                                            <div id="Statistics_<?php echo e($x->maCTBaiQH); ?>"
                                                                                class="collapse">
                                                                                <?php if($x->maLoaiHTDG=='T8' || $x->maLoaiHTDG=='T6'): ?>
                                                                                    <li>
                                                                                        <span><a style="color:#000; text-decoration:none;"
                                                                                            data-toggle="collapse"
                                                                                            href="#project_<?php echo e($x->maLoaiHTDG); ?>"
                                                                                            aria-expanded="false"
                                                                                            aria-controls="project_<?php echo e($x->maLoaiHTDG); ?>"><i
                                                                                                class="collapsed"><i
                                                                                                    class="fas fa-folder"></i></i>
                                                                                            <i
                                                                                                class="expanded"><i
                                                                                                    class="far fa-folder-open"></i></i>
                                                                                            <?php echo e(__('Granding officer')); ?></a></span>
                                                                                            <div class="collapse" id="project_<?php echo e($x->maLoaiHTDG); ?>">
                                                                                                <ul>
                                                                                                    <li>
                                                                                                        <span><a style="color:#000; text-decoration:none;"
                                                                                                            data-toggle="collapse"
                                                                                                            href="#project_CP1_<?php echo e($x->maLoaiHTDG); ?>"
                                                                                                            aria-expanded="false"
                                                                                                            aria-controls="project_<?php echo e($x->maLoaiHTDG); ?>"><i
                                                                                                                class="collapsed"><i
                                                                                                                    class="fas fa-folder"></i></i>
                                                                                                            <i
                                                                                                                class="expanded"><i
                                                                                                                    class="far fa-folder-open"></i></i>
                                                                                                            1</a></span>
                                                                                                        <div class="collapse" id="project_CP1_<?php echo e($x->maLoaiHTDG); ?>">
                                                                                                            <ul>
                                                                                                                <li><span><i class="far fa-circle"></i><a 
                                                                                                                    href="<?php echo e(asset('giang-vien/thong-ke/thong-ke-theo-hoc-phan/do-an/thong-ke-theo-clo/' . $x->maCTBaiQH.'/1')); ?>">
                                                                                                                    <?php echo e(__("CLOs")); ?></a></span></li>
                                                                                                                <li><span><i class="far fa-circle"></i><a 
                                                                                                                    href="<?php echo e(asset('/giang-vien/thong-ke/thong-ke-theo-hoc-phan/do-an/thong-ke-theo-abet/' . $x->maCTBaiQH).'/1'); ?>">
                                                                                                                     <?php echo e(__("ABET'sSO")); ?></a></span></li>
                                                                                                                <li><span><i class="far fa-circle"></i><a 
                                                                                                                    href="<?php echo e(asset('/giang-vien/thong-ke/thong-ke-theo-hoc-phan/do-an/thong-ke-theo-tieu-chi/' . $x->maCTBaiQH . '/1')); ?>">
                                                                                                                     <?php echo e(__('SOs')); ?></a></span></li>
                                                                                                                <li><span><i class="far fa-circle"></i><a 
                                                                                                                    href="<?php echo e(asset('giang-vien/thong-ke/thong-ke-theo-hoc-phan/do-an/thong-ke-theo-xep-hang/' . $x->maCTBaiQH . '/1')); ?>">
                                                                                                                    <?php echo e(__('Rank')); ?></a></span></li>
                                                                                                                <li><span><i class="far fa-circle"></i><a 
                                                                                                                    href="<?php echo e(asset('giang-vien/thong-ke/thong-ke-theo-hoc-phan/do-an/thong-ke-theo-diem-chu/' . $x->maCTBaiQH . '/1')); ?>">
                                                                                                                     <?php echo e(__('Grate')); ?></a></span></li>
                                                                                                            </ul>
                                                                                                        </div>
                                                                                                    </li>
                                                                                                    <?php if($x->maGV_2!='00000'): ?>
                                                                                                    <li> 
                                                                                                        <span><a style="color:#000; text-decoration:none;"
                                                                                                        data-toggle="collapse"
                                                                                                        href="#project_CP2_<?php echo e($x->maLoaiHTDG); ?>"
                                                                                                        aria-expanded="false"
                                                                                                        aria-controls="project_<?php echo e($x->maLoaiHTDG); ?>"><i
                                                                                                            class="collapsed"><i
                                                                                                                class="fas fa-folder"></i></i>
                                                                                                        <i
                                                                                                            class="expanded"><i
                                                                                                                class="far fa-folder-open"></i></i>
                                                                                                        2</a></span>
                                                                                                        <div class="collapse" id="project_CP2_<?php echo e($x->maLoaiHTDG); ?>">
                                                                                                            <ul>
                                                                                                                <li><span><i class="far fa-circle"></i><a 
                                                                                                                    href="<?php echo e(asset('giang-vien/thong-ke/thong-ke-theo-hoc-phan/do-an/thong-ke-theo-clo/' . $x->maCTBaiQH.'/2')); ?>">
                                                                                                                    <?php echo e(__("CLOs")); ?></a></span></li>
                                                                                                                <li><span><i class="far fa-circle"></i><a 
                                                                                                                    href="<?php echo e(asset('/giang-vien/thong-ke/thong-ke-theo-hoc-phan/do-an/thong-ke-theo-abet/' . $x->maCTBaiQH.'/2')); ?>">
                                                                                                                     <?php echo e(__("ABET'sSO")); ?></a></span></li>
                                                                                                                <li><span><i class="far fa-circle"></i><a 
                                                                                                                    href="<?php echo e(asset('/giang-vien/thong-ke/thong-ke-theo-hoc-phan/do-an/thong-ke-theo-tieu-chi/' . $x->maCTBaiQH . '/2')); ?>">
                                                                                                                     <?php echo e(__('SOs')); ?></a></span></li>
                                                                                                                <li><span><i class="far fa-circle"></i><a 
                                                                                                                    href="<?php echo e(asset('giang-vien/thong-ke/thong-ke-theo-hoc-phan/do-an/thong-ke-theo-xep-hang/' . $x->maCTBaiQH . '/2')); ?>">
                                                                                                                    <?php echo e(__('Rank')); ?></a></span></li>
                                                                                                                <li><span><i class="far fa-circle"></i><a 
                                                                                                                    href="<?php echo e(asset('giang-vien/thong-ke/thong-ke-theo-hoc-phan/do-an/thong-ke-theo-diem-chu/' . $x->maCTBaiQH . '/2')); ?>">
                                                                                                                     <?php echo e(__('Grate')); ?></a></span></li>
                                                                                                            </ul>
                                                                                                        </div>
                                                                                                    </li>
                                                                                                    <?php endif; ?>
                                                                                                    
                                                                                                </ul>
                                                                                            </div>
                                                                                    </li>
                                                                                <?php endif; ?>
                                                                                <?php if($x->maLoaiHTDG=='T1'): ?>  
                                                                                    <li><span><i class="far fa-circle"></i><a 
                                                                                        href="<?php echo e(asset('giang-vien/thong-ke/thong-ke-theo-hoc-phan/tu-luan/thong-ke-theo-clo/' . $x->maCTBaiQH)); ?>">
                                                                                        <?php echo e(__("CLOs")); ?></a></span></li>
                                                                                    <li><span><i class="far fa-circle"></i><a 
                                                                                        href="<?php echo e(asset('giang-vien/thong-ke/thong-ke-theo-hoc-phan/tu-luan/thong-ke-theo-abet/' . $x->maCTBaiQH)); ?>">
                                                                                         <?php echo e(__("ABET'sSO")); ?></a></span></li>
                                                                                    <li><span><i class="far fa-circle"></i><a 
                                                                                        href="<?php echo e(asset('/giang-vien/thong-ke/thong-ke-theo-hoc-phan/tu-luan/thong-ke-theo-tieu-chi/' . $x->maCTBaiQH)); ?>">
                                                                                         <?php echo e(__('SOs')); ?></a></span></li>
                                                                                    <li><span><i class="far fa-circle"></i><a 
                                                                                       href="<?php echo e(asset('giang-vien/thong-ke/thong-ke-theo-hoc-phan/tu-luan/thong-ke-theo-xep-hang/' . $x->maCTBaiQH)); ?>">
                                                                                        <?php echo e(__('Rank')); ?></a></span></li>
                                                                                    <li><span><i class="far fa-circle"></i><a 
                                                                                        href="<?php echo e(asset('giang-vien/thong-ke/thong-ke-theo-hoc-phan/tu-luan/thong-ke-theo-diem-chu/' . $x->maCTBaiQH)); ?>">
                                                                                         <?php echo e(__('Grate')); ?></a></span></li>
                                                                                <?php else: ?>
                                                                                    <?php if($x->maLoaiHTDG=='T2'): ?>
                                                                                        <li><span><i class="far fa-circle"></i><a 
                                                                                            href="<?php echo e(asset('giang-vien/thong-ke/thong-ke-theo-hoc-phan/trac-nghiem/thong-ke-theo-clo/' . $x->maCTBaiQH)); ?>">
                                                                                            <?php echo e(__("CLOs")); ?></a></span></li>
                                                                                        <li><span><i class="far fa-circle"></i><a 
                                                                                            href="<?php echo e(asset('giang-vien/thong-ke/thong-ke-theo-hoc-phan/trac-nghiem/thong-ke-theo-abet/' . $x->maCTBaiQH)); ?>">
                                                                                            <?php echo e(__("ABET'sSO")); ?></a></span></li>
                                                                                        <li><span><i class="far fa-circle"></i><a 
                                                                                            href="<?php echo e(asset('/giang-vien/thong-ke/thong-ke-theo-hoc-phan/trac-nghiem/thong-ke-theo-tieu-chi/' . $x->maCTBaiQH)); ?>">
                                                                                            <?php echo e(__('SOs')); ?></a></span></li>
                                                                                        <li><span><i class="far fa-circle"></i><a 
                                                                                        href="<?php echo e(asset('giang-vien/thong-ke/thong-ke-theo-hoc-phan/trac-nghiem/thong-ke-theo-xep-hang/' . $x->maCTBaiQH)); ?>">
                                                                                            <?php echo e(__('Rank')); ?></a></span></li>
                                                                                        <li><span><i class="far fa-circle"></i><a 
                                                                                            href="<?php echo e(asset('giang-vien/thong-ke/thong-ke-theo-hoc-phan/trac-nghiem/thong-ke-theo-diem-chu/' . $x->maCTBaiQH)); ?>">
                                                                                            <?php echo e(__('Grate')); ?></a></span></li>
                                                                                    <?php else: ?>
                                                                                        <?php if($x->maLoaiHTDG=='T3'): ?>
                                                                                            <li><span><i class="far fa-circle"></i><a 
                                                                                                href="<?php echo e(asset('giang-vien/thong-ke/thong-ke-theo-hoc-phan/thuc-hanh/thong-ke-theo-clo/' . $x->maCTBaiQH)); ?>">
                                                                                                <?php echo e(__("CLOs")); ?></a></span></li>
                                                                                            <li><span><i class="far fa-circle"></i><a 
                                                                                                href="<?php echo e(asset('giang-vien/thong-ke/thong-ke-theo-hoc-phan/thuc-hanh/thong-ke-theo-abet/' . $x->maCTBaiQH)); ?>">
                                                                                                <?php echo e(__("ABET'sSO")); ?></a></span></li>
                                                                                            <li><span><i class="far fa-circle"></i><a 
                                                                                                href="<?php echo e(asset('/giang-vien/thong-ke/thong-ke-theo-hoc-phan/thuc-hanh/thong-ke-theo-tieu-chi/' . $x->maCTBaiQH)); ?>">
                                                                                                <?php echo e(__('SOs')); ?></a></span></li>
                                                                                            <li><span><i class="far fa-circle"></i><a 
                                                                                            href="<?php echo e(asset('giang-vien/thong-ke/thong-ke-theo-hoc-phan/thuc-hanh/thong-ke-theo-xep-hang/' . $x->maCTBaiQH)); ?>">
                                                                                                <?php echo e(__('Rank')); ?></a></span></li>
                                                                                            <li><span><i class="far fa-circle"></i><a 
                                                                                                href="<?php echo e(asset('giang-vien/thong-ke/thong-ke-theo-hoc-phan/thuc-hanh/thong-ke-theo-diem-chu/' . $x->maCTBaiQH)); ?>">
                                                                                                <?php echo e(__('Grate')); ?></a></span></li>
                                                                                        <?php endif; ?>
                                                                                    <?php endif; ?>
                                                                                <?php endif; ?>
                                                                            </div>
                                                                        </ul>        
                                                                    </li>
                                                                </div>
                                                            </ul>
                                                        </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                </ul>
                                            </div>
                                        </li>
                                    </ul>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('giangvien.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2_Co Nam\1_source code\source code 31-5\resources\views/giangvien/quyhoach/quyhoach2.blade.php ENDPATH**/ ?>