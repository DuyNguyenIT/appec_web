<h5><b>5. Nội dung môn học: </b></h5>
<!-----------------------------------5.Nội dung môn học: --------------------------->
<table class="table table-bordered">
    <thead style="background-color: green">
        <tr>
            <th rowspan="2"> <?php echo e(__('Course contents')); ?>

                <!-- Button trigger modal -->
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addChuong">
                    <i class="fas fa-plus"></i> Chapter
                </button>
                <!-- Modal thêm nội dung môn học-->
                <div class="modal fade" id="addChuong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/them_noi_dung_mon_hoc')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Add')); ?></h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <input type="text" name="maHocPhan" value="<?php echo e($hocPhan->maHocPhan); ?>" hidden>
                                    <div class="form-group">
                                        <label for=""><?php echo e(__('Chapter name')); ?>:</label>
                                        <input type="text" name="tenchuong" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Số tiết lý thuyết:</label>
                                        <input type="number" min="0" name="soTietLT" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Số tiết thực hành:</label>
                                        <input type="number" min="0" name="soTietTH" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Số tiết khác:</label>
                                        <input type="number" min="0" name="khác" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Chọn kết quả học tập:</label>
                                        <select name="maKQHT[]" id="" class="form-control" multiple required>
                                            <?php $__currentLoopData = $getKQHT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($data->maKQHT); ?>"><?php echo e($data->maKQHTVB); ?> --
                                                    <?php echo e($data->tenKQHT); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary">Save</button>
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </th>
            <th rowspan="2">Chuẩn đầu ra học phần lý thuyết</th>
            <th colspan="3"> <?php echo e(__('Number of learning periods')); ?></th>
        </tr>
        <tr>
            <th><?php echo e(__('Theory')); ?></th>
            <th><?php echo e(__('Practice')); ?></th>
            <th><?php echo e(__('Others')); ?></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $noidung; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <b><?php echo e($data->tenchuong); ?></b><br>
                    <div class="btn-group">
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#edit_chapter_<?php echo e($data->id); ?>">
                            <i class="fas fa-edit"></i>
                        </button>
                        <a title="Delete" class="btn btn-danger"
                            onclick="return confirm('Confirm?')"
                            href="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/xoa-noi-dung-mon-hoc/'.$data->id)); ?>">
                            <i class="fa fa-trash"></i>
                        </a> 
                    </div>
                    
                    <!-- Modal edit chuong -->
                    <div class="modal fade" id="edit_chapter_<?php echo e($data->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/sua-noi-dung-mon-hoc')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Edit')); ?></h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="text" name="id" value="<?php echo e($data->id); ?>" hidden>
                                        <div class="form-group">
                                            <label for=""><?php echo e(__('Chapter name')); ?>:</label>
                                            <input type="text" name="tenchuong" class="form-control" required value="<?php echo e($data->tenchuong); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="">Số tiết lý thuyết:</label>
                                            <input type="number" min="0" name="soTietLT" value="<?php echo e($data->soTietLT); ?>" class="form-control" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="">Số tiết thực hành:</label>
                                            <input type="number" min="0" name="soTietTH" value="<?php echo e($data->soTietTH); ?>"  class="form-control" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="">Số tiết khác:</label>
                                            <input type="number" name="soTietKhac" value="<?php echo e($data->soTietKhac); ?>" min="0"  class="form-control" >
                                        </div>
                                      
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-primary"><?php echo e(__("Save")); ?></button>
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- Button thêm mục -->
                    <button type="button" class="btn btn-primary" data-toggle="modal"
                        data-target="#addMuc_<?php echo e($data->id); ?>">
                        <i class="fas fa-plus"></i><?php echo e(__('Adding item')); ?>

                    </button>

                    <!-- Modal thêm mục -->
                    <div class="modal fade" id="addMuc_<?php echo e($data->id); ?>" tabindex="-1" role="dialog"
                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/them_noi_dung_muc_chuong')); ?>"
                                method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Adding item')); ?></h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="text" name="id_chuong" value="<?php echo e($data->id); ?>" hidden>
                                        <div class="form-group">
                                            <label for=""><?php echo e(__('Item ID')); ?>:</label>
                                            <input type="text" name="maMucVB" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for=""><?php echo e(__('Item name')); ?>:</label>
                                            <input type="text" name="tenMuc" class="form-control">
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                        <button type="button" class="btn btn-secondary"
                                            data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <button type="button" class="btn btn-primary" data-toggle="modal"
                        data-target="#addMucDoKyNangUIT_<?php echo e($data->id); ?>">
                        <i class="fas fa-plus"></i><?php echo e(__('Adding level of skill')); ?>

                    </button>
                     
                    <div class="modal fade" id="addMucDoKyNangUIT_<?php echo e($data->id); ?>" tabindex="-1" role="dialog"
                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/them_muc_do_ky_nang_uti')); ?>"
                                method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Adding level of skill')); ?></h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="text" name="id_chuong" value="<?php echo e($data->id); ?>" hidden>
                                        <div class="form-group">
                                            <label for=""><?php echo e(__('Choosing topic')); ?>:</label>
                                            <select name="maCDR1" id="" class="form-control">
                                                <?php for($i = 1; $i < count($CDR1); $i++): ?>
                                                    <option value="<?php echo e($CDR1[$i]['maCDR1']); ?>"><?php echo e($CDR1[$i]['tenCDR1']); ?>

                                                    </option>
                                                <?php endfor; ?>
                                                
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for=""><?php echo e(__('Studying results')); ?>:</label>
                                            <select name="maKQHT[]" id="" class="form-control" multiple>
                                                <?php $__currentLoopData = $getKQHT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($x->maKQHT); ?>"><?php echo e($x->maKQHTVB); ?>--
                                                        <?php echo e($x->tenKQHT); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for=""><?php echo e(__('Choosing')); ?> U - I - T:</label>
                                            <select name="ky_nang" id="" class="form-control">
                                                <option value="U">U</option>
                                                <option value="I">I</option>
                                                <option value="T">T</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                        <button type="button" class="btn btn-secondary"
                                            data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                   
                </td>
                <td>
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#add_hpkqht_<?php echo e($data->id); ?>">
                        <i class="fas fa-plus"></i> LO
                    </button>

                    <?php $__currentLoopData = $data->chuong_kqht; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($item->maKQHTVB); ?> 
                        <a title="Delete" 
                            onclick="return confirm('Confirm?')"
                            href="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/xoa-chuong-ket-qua-hoc-tap/'.$data->id.'/'.$item->maKQHT)); ?>">
                            <i class="fa fa-trash"></i>
                        </a>;
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <!-- Modal chuong kqht-->
                    <div class="modal fade" id="add_hpkqht_<?php echo e($data->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                        <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/them-chuong-ket-qua-hoc-tap')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Edit')); ?></h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>

                            <div class="modal-body">
                                <input type="text" name="machuong" value="<?php echo e($data->id); ?>" hidden>
                                <div class="form-group">
                                    <label for="">Chọn kết quả học tập:</label>
                                    <select name="maKQHT[]" id="" class="form-control" multiple required>
                                        <?php $__currentLoopData = $getKQHT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kqht): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($kqht->maKQHT); ?>"><?php echo e($kqht->maKQHTVB); ?> --
                                                <?php echo e($kqht->tenKQHT); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
                            </div>
                        </div>
                        </form>
                      
                        </div>
                    </div>
                </td>
                <td>
                    <?php echo e($data->soTietLT); ?>

                </td>
                <td><?php echo e($data->soTietTH); ?></td>
                <td><?php echo e($data->soTietKhac); ?></td>
            </tr>
            <?php $__currentLoopData = $data->muc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <div class="btn-group">
                            <!-- Button edit item modal -->
                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#edit_muc_<?php echo e($m->id); ?>">
                                <i class="fas fa-edit"></i>
                            </button>
                            <a title="Delete" class="btn btn-danger"
                                onclick="return confirm('Confirm?')"
                                href="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/xoa_noi_dung_muc_chuong/'.$m->id)); ?>">
                                <i class="fa fa-trash"></i>
                            </a>
                        </div>
                        <?php echo e($m->maMucVB); ?>

                        <?php echo e($m->tenMuc); ?>

                    </td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>

                    <!-- Modal -->
                    <div class="modal fade" id="edit_muc_<?php echo e($m->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/sua_noi_dung_muc_chuong')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="modal-content">
                                <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Edit')); ?> <?php echo e(__('Item')); ?></h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                </div>
                                <div class="modal-body">
                                    <input type="text" name="id" value="<?php echo e($m->id); ?>" hidden>
                                    <div class="form-group">
                                        <label for=""><?php echo e(__('Item ID')); ?>:</label>
                                        <input type="text" name="maMucVB" class="form-control" value="<?php echo e($m->maMucVB); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for=""><?php echo e(__('Item name')); ?>:</label>
                                        <input type="text" name="tenMuc" class="form-control" value="<?php echo e($m->tenMuc); ?>">
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary"><?php echo e(__("Save")); ?></button>
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(_('Cancel')); ?></button>
                                </div>
                            </div>
                            </form>
                      
                        </div>
                    </div>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php for($i = 1; $i < count($CDR1); $i++): ?>
                <tr>
                    <td><b><?php echo e(__('Topic')); ?>: <?php echo e($CDR1[$i]['tenCDR1']); ?></b></td>
                    <td colspan="4">
                        <?php $__currentLoopData = $mudokynangUIT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($uit->maCDR1 == $CDR1[$i]['maCDR1'] && $uit->id_chuong == $data->id): ?>
                                <?php echo e($uit->maKQHTVB); ?>(<?php echo e($uit->ky_nang); ?>)
                                <a title="Delete" 
                                    onclick="return confirm('Confirm?')"
                                    href="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/xoa_muc_do_ky_nang_uti/'.$uit->id)); ?>">
                                    <i class="fa fa-trash"></i>
                                </a>;
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                </tr>
            <?php endfor; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH D:\2_Co Nam\1_source code\source code 31-5\resources\views/layouts/decuong/chitietnoidung/5_noidungmonhoc.blade.php ENDPATH**/ ?>