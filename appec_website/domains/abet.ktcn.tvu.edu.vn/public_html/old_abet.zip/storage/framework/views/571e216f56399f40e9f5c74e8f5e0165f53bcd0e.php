<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">
                            <?php echo e(__('Project')); ?><noscript></noscript>
                            <nav></nav>
                        </h1>
                    </div>
                    <!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(asset('/giang-vien')); ?>"><?php echo e(__('Home')); ?></a>
                            </li>
                            <li class="breadcrumb-item">
                                <a href="#">Đồ án</a>
                            </li>
                            <li class="breadcrumb-item active">Nội dung đánh giá</li>
                        </ol>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>

        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">
                                    <button type="button" class="btn btn-primary" data-toggle="modal"
                                        data-target="#exampleModal">
                                        <i class="far fa-address-card"></i> Thêm phiếu chấm
                                    </button>
                                    
                                    <button class="btn btn-primary" data-toggle="modal" data-target="#moichambc">
                                        Mời chấm báo cáo
                                    </button>
                                    <!-- Modal mời chấm báo cáo -->
                                    <div class="modal fade" id="moichambc" tabindex="-1" role="dialog"
                                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <form
                                                action="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/noi-dung-danh-gia/moi-cham-bao-cao')); ?>"
                                                method="post">
                                                <?php echo csrf_field(); ?>
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Mời chấm báo cáo</h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                            <label for=""> Chọn giảng viên:</label>
                                                            <select name="maGV_2" id="" class="form-control select2" style="width:100%">
                                                                <option value="00000">Chọn riêng giảng viên chấm cho đề tài
                                                                </option>
                                                                <?php $__currentLoopData = $gv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($x->maGV); ?>"><?php echo e($x->hoGV); ?>

                                                                        <?php echo e($x->tenGV); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="submit" class="btn btn-primary">Lưu</button>
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">Đóng</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <!-- Modal thêm phiếu chấm -->
                                    <div class="modal fade bd-example-modal-lg" id="exampleModal" tabindex="-1"
                                        role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg" role="document">
                                            <form
                                                action="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/noi-dung-danh-gia/them-phieu-cham')); ?>"
                                                method="post">
                                                <?php echo csrf_field(); ?>
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">
                                                            Thêm phiếu chấm
                                                        </h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                            <label for="hocphan" style="font-size: 20px">Chọn đề tài</label>
                                                            <!-- Button trigger modal -->
                                                            <select name="maDe" id="" class="form-control custom-select  select2" style="width:100%" required>
                                                                <?php $__currentLoopData = $deTai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($md->maDe); ?>">
                                                                        <?php echo e($md->maDeVB); ?>--<?php echo e($md->tenDe); ?>

                                                                    </option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="">Chọn sinh viên</label>
                                                            <select name="maSSV" id="" class="form-control custom-select select2" style="width:100%" required>
                                                                <?php $__currentLoopData = $dsLop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($sv->maSSV); ?>">
                                                                        <?php echo e($sv->maSSV); ?>--<?php echo e($sv->HoSV); ?>

                                                                        <?php echo e($sv->TenSV); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                        <?php if($canbo2->maGV == '00000'): ?>
                                                            <div class="form-group">
                                                                <label for=""> Chọn giảng viên:</label>
                                                                <select name="maGV_2" id="" class="form-control select2" style="width:100%">
                                                                    <?php $__currentLoopData = $gv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($x->maGV); ?>">
                                                                            <?php echo e($x->hoGV); ?> <?php echo e($x->tenGV); ?>

                                                                        </option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="submit" class="btn btn-primary">
                                                            <?php echo e(__('Save')); ?>

                                                        </button>
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">
                                                            <?php echo e(__("Cancel")); ?>

                                                        </button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <hr>
                                    Cán bộ chấm 2: <?php echo e($canbo2->hoGV); ?> <?php echo e($canbo2->tenGV); ?>

                                </h3>
                                <div class="card-tools">
                                    <a href="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/quy-hoach-ket-qua/' . Session::get('maHocPhan') . '/' . Session::get('maBaiQH') . '/' . Session::get('maHK') . '/' . Session::get('namHoc') . '/' . Session::get('maLop'))); ?>"
                                        class="btn btn-secondary"><i class="fas fa-arrow-left"></i></a>
                                </div>
                            </div>
                            
                            <!-- /.card-header -->
                            <div class="card-body">
                                <table id="example2" class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th><?php echo e(__("No.")); ?></th>
                                            <th>Mã đề tài</th>
                                            <th>

                                                <!-- Button trigger modal -->
                                                <button type="button" class="btn btn-primary" data-toggle="modal"
                                                    data-target="#themDT">
                                                    <i class="fas fa-plus"></i>
                                                </button>


                                              


                                                <!-- Modal -->
                                                <div class="modal fade" id="themDT" tabindex="-1" role="dialog"
                                                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog" role="document">
                                                        <form
                                                            action="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/noi-dung-danh-gia/them-de-tai')); ?>"
                                                            method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title" id="exampleModalLabel">Thêm đề
                                                                        tài</h5>
                                                                    <button type="button" class="close" data-dismiss="modal"
                                                                        aria-label="Close">
                                                                        <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <div class="form-group">
                                                                        <label for="">Nhập mã đề tài:</label>
                                                                        <input type="text" name="maDe" class="form-control">
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="">Nhập tên đề tài:</label>
                                                                        <input type="text" name="tenDe"
                                                                            class="form-control">
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="submit"
                                                                        class="btn btn-primary">Lưu</button>
                                                                    <button type="button" class="btn btn-secondary"
                                                                        data-dismiss="modal">Hủy</button>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                                Tên đề tài
                                            </th>
                                            <th>Sinh viên thực hiện</th>
                                            <th>Mã sinh viên</th>
                                            <th>Cán bộ chấm 2</th>
                                            <th>Tùy chọn</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $i = 1;
                                            $chayTenDT = 0;
                                            $maDe_cur = 0;
                                        ?>
                                        <?php $__currentLoopData = $deThi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $demTenDT = $deThi->where('maDe', $dt->maDe)->count();
                                                if ($chayTenDT > $demTenDT) {
                                                    $chayTenDT = 1;
                                                } else {
                                                    $chayTenDT += 1;
                                                }
                                                if ($maDe_cur !== $dt->maDe) {
                                                    $maDe_cur = $dt->maDe;
                                                    $chayTenDT = 1;
                                                }
                                            ?>
                                            <?php if($chayTenDT == 1): ?>
                                                <tr>
                                                    <td rowspan=<?php echo e($demTenDT); ?>><?php echo e($i++); ?></td>
                                                    <td rowspan=<?php echo e($demTenDT); ?>><?php echo e($dt->maDeVB); ?></td>
                                                    <td rowspan=<?php echo e($demTenDT); ?>>
                                                        <button type="button" class="btn btn-primary" data-toggle="modal"
                                                            data-target="#editTen_<?php echo e($dt->maDe); ?>">
                                                            <i class="fas fa-edit"></i> Sửa ĐT
                                                        </button>

                                                        <a href="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/noi-dung-danh-gia/xoa-ten-de-tai/'.$dt->maDe)); ?>"
                                                            onclick="return confirm('Confirm?')"
                                                            class="btn btn-danger">
                                                            <i class="fas fa-trash"></i> Xóa ĐT
                                                        </a>
                                                        <?php echo e($dt->tenDe); ?>

                                                        <!-- Modal -->
                                                        <div class="modal fade" id="editTen_<?php echo e($dt->maDe); ?>"
                                                            tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                                                            aria-hidden="true">
                                                            <div class="modal-dialog" role="document">
                                                                <form
                                                                    action="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/noi-dung-danh-gia/sua-ten-de-tai')); ?>"
                                                                    method="post">
                                                                    <?php echo csrf_field(); ?>
                                                                    <div class="modal-content">
                                                                        <div class="modal-header">
                                                                            <h5 class="modal-title" id="exampleModalLabel">
                                                                                Sửa tên DT</h5>
                                                                            <button type="button" class="close"
                                                                                data-dismiss="modal" aria-label="Close">
                                                                                <span aria-hidden="true">&times;</span>
                                                                            </button>
                                                                        </div>
                                                                        <div class="modal-body">
                                                                            <input type="text" name="maDe" id="" hidden
                                                                                value="<?php echo e($dt->maDe); ?>">
                                                                            <div class="form-group">
                                                                                <label for="">Tên đề tài:</label>
                                                                                <input type="text" class="form-control"
                                                                                    name="tenDe" id=""
                                                                                    value="<?php echo e($dt->tenDe); ?>">
                                                                            </div>
                                                                        </div>
                                                                        <div class="modal-footer">
                                                                            <button type="submit"
                                                                                class="btn btn-primary">Save</button>
                                                                            <button type="button" class="btn btn-secondary"
                                                                                data-dismiss="modal">Close</button>
                                                                        </div>
                                                                    </div>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td><?php echo e($dt->HoSV); ?> <?php echo e($dt->TenSV); ?></td>
                                                    <td><?php echo e($dt->maSSV); ?></td>
                                                    <td><?php echo e($dt->hoGV); ?> <?php echo e($dt->tenGV); ?></td>
                                                    <td>
                                                        <button class="btn btn-primary">
                                                            <i class="fas fa-edit"></i>
                                                        </button>
                                                        <a class="btn btn-danger"
                                                            href="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/noi-dung-danh-gia/xoa-phieu-cham-do-an/' . $dt->maDe . '/' . $dt->maSSV)); ?>"
                                                            onclick="confirm('Confirm?')"><i
                                                                class="fas fa-trash"></i></a>
                                                    </td>
                                                </tr>
                                            <?php else: ?>
                                                <tr>
                                                    <td><?php echo e($dt->HoSV); ?> <?php echo e($dt->TenSV); ?></td>
                                                    <td><?php echo e($dt->maSSV); ?></td>
                                                    <td><?php echo e($dt->hoGV); ?> <?php echo e($dt->tenGV); ?></td>
                                                    <td>
                                                        <button class="btn btn-primary">
                                                            <i class="fas fa-edit"></i> 
                                                        </button>
                                                        <a class="btn btn-danger"
                                                            href="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/noi-dung-danh-gia/xoa-phieu-cham-do-an/' . $dt->maDe . '/' . $dt->maSSV)); ?>"
                                                            onclick="confirm('Confirm?')"><i
                                                                class="fas fa-trash"></i></a>
                                                    </td>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot></tfoot>
                                </table>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('giangvien.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/giangvien/quyhoach/noidungdanhgia/xemnddanhgia.blade.php ENDPATH**/ ?>