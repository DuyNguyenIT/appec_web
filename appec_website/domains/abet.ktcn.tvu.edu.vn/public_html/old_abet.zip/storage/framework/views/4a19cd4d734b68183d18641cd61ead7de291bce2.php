
<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><?php echo e(__('Course')); ?> - <?php echo e(__('Curriculum')); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(asset('quan-ly')); ?>"><?php echo e(__('Home')); ?></a></li>
                            <li class="breadcrumb-item"><a
                                    href="<?php echo e(asset('quan-ly/hoc-phan')); ?>"><?php echo e(__('Courses')); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo e(__('Courses')); ?> - <?php echo e(__('Curriculum')); ?></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <div class="card-title">
                                    <?php echo e(__('Course name')); ?>: <?php echo e($hp->tenHocPhan); ?>--<?php echo e(__('Course ID')); ?>:
                                    <?php echo e($hp->maHocPhan); ?>

                                </div>
                                <div class="card-tools">
                                    <a href="<?php echo e(asset('/quan-ly/hoc-phan')); ?>" class="btn btn-secondary"><i
                                            class="fas fa-arrow-left"></i></a>
                                </div>
                            </div>
                            <div class="card-body">
                                <table id="example2" class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th><?php echo e(__('No.')); ?></th>
                                            <th><?php echo e(__('Curriculum name')); ?></th>
                                            <th><?php echo e(__('Semester')); ?></th>
                                            <th><?php echo e(__('Course type')); ?></th>
                                            <th><?php echo e(__('Option')); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $i = 1;
                                        ?>
                                        <?php $__currentLoopData = $hp_ctdt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($i++); ?></td>
                                                <td>
                                                    <?php echo e($data->ctDaoTao[0]->tenCT); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($data->phanPhoiHocKy); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($data->loaiHocPhan[0]->tenLoaiHocPhan); ?>

                                                </td>
                                                <td>
                                                    <!-- Button trigger modal -->
                                                    <button type="button" class="btn btn-primary" data-toggle="modal"
                                                        data-target="#edit_<?php echo e($data->id); ?>">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    <a title="Delete" class="btn btn-danger"
                                                        onclick="return confirm('Do you want to delete ?')"
                                                        href="<?php echo e(asset('quan-ly/hoc-phan/xoa-hoc-phan-ct-dao-tao/' . $data->id)); ?>"><i
                                                            class="fa fa-trash"></i></a>
                                                    <!-- Modal -->
                                                    <div class="modal fade" id="edit_<?php echo e($data->id); ?>" tabindex="-1"
                                                        role="dialog" aria-labelledby="exampleModalLabel"
                                                        aria-hidden="true">
                                                        <div class="modal-dialog" role="document">
                                                            <form
                                                                action="<?php echo e(asset('/quan-ly/hoc-phan/chinh-sua-hoc-phan-ct-dao-tao')); ?>"
                                                                method="post">
                                                                <?php echo csrf_field(); ?>
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title" id="exampleModalLabel">
                                                                            <?php echo e(__('Course')); ?> -
                                                                            <?php echo e(__('Curriculum')); ?></h5>
                                                                        <button type="button" class="close"
                                                                            data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <input type="text" name="id"
                                                                            value="<?php echo e($data->id); ?>" hidden>
                                                                        <input type="text" name="maHocPhan"
                                                                            value="<?php echo e($hp->maHocPhan); ?>" hidden>
                                                                        <div class="form-group">
                                                                            <label for=""><?php echo e(__('Curriculum')); ?></label>
                                                                            <select name="maCT" class="form-control">
                                                                                <?php $__currentLoopData = $ctdt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <?php if($ct->maCT == $data->maCT): ?>
                                                                                        <option value="<?php echo e($ct->maCT); ?>"
                                                                                            selected><?php echo e($ct->tenCT); ?>

                                                                                        </option>
                                                                                    <?php else: ?>
                                                                                        <option
                                                                                            value="<?php echo e($ct->maCT); ?>">
                                                                                            <?php echo e($ct->tenCT); ?></option>
                                                                                    <?php endif; ?>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </select>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for=""><?php echo e(__('Semester')); ?></label>
                                                                            <input type="text" name="phanPhoiHocKy"
                                                                                class="form-control"
                                                                                value="<?php echo e($data->phanPhoiHocKy); ?>">
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for=""><?php echo e(__('Course type')); ?></label>
                                                                            <select name="maLoaiHocPhan"
                                                                                class="form-control">
                                                                                <?php $__currentLoopData = $loaihp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lhp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <?php if($lhp->maLoaiHocPhan == $data->maLoaiHocPhan): ?>
                                                                                        <option
                                                                                            value="<?php echo e($lhp->maLoaiHocPhan); ?>"
                                                                                            selected>
                                                                                            <?php echo e($lhp->tenLoaiHocPhan); ?>

                                                                                        </option>
                                                                                    <?php else: ?>
                                                                                        <option
                                                                                            value="<?php echo e($lhp->maLoaiHocPhan); ?>">
                                                                                            <?php echo e($lhp->tenLoaiHocPhan); ?>

                                                                                        </option>
                                                                                    <?php endif; ?>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="submit"
                                                                            class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                                                        <button type="button" class="btn btn-secondary"
                                                                            data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                                                                    </div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.error-page -->
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2_Co Nam\1_source code\source code 31-5\resources\views/admin/hocphan/hocphan_ctdaotao.blade.php ENDPATH**/ ?>