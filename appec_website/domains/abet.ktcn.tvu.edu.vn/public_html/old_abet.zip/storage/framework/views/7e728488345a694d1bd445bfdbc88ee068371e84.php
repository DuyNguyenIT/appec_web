<table>   
    <thead>  
  <tr>
    <th>No.</th>
    <th>Course Name</th>
    <?php
        $tongmon_dapung=[];//biến lưu tổng theo cột CDR3
      ?>
    <?php $__currentLoopData = $ctdt_cdr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <th> <?php echo e($x->maCDR3VB); ?> </th>
          <?php
          $tongmon_dapung[$x->maCDR3]=0;
          ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <th>Total</th>
  </tr>
  </thead>
   
   <tbody>
      <?php
        $i=1;
        $tongcong=0;//biến lưu tổng của cột tổng
      ?>
      <?php $__currentLoopData = $hp_ctdt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
              <th><?php echo e($i++); ?> </th>
              <th><?php echo e($y->tenHocPhan); ?></th>
              <?php
              $tongcdr_cuamon=0;
              $ktra=0;//kiểm tra xem môn học có được nhập CDR3 chưa
              ?>
              <?php $__currentLoopData = $hp_cdr3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $z): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php if($y->maHocPhan==$z->maHocPhan ): ?>
                  <?php //Nếu học phần đang xét mà có trong bảng học phần-chuẩn đầu ra 3
                  $ktra=1; // môn học đã có chuẩn đầu ra
                  break;
                  ?>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php if($ktra==1): ?>
                <?php $__currentLoopData = $ctdt_cdr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php //nếu học phần có đáp ứng chuẩn đầu ra thì kiểm tra xem đáp ứng CDR3 nào
                  $dapung=0;
                  ?>
                  <?php $__currentLoopData = $hp_cdr3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $z): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($z->maCDR3==$x->maCDR3 && $y->maHocPhan==$z->maHocPhan): ?>
                      <?php
                      $dapung=1; // môn học đáp ứng chuẩn đầu ra 3 tương ứng với cột CDR3
                      $tongcdr_cuamon++;
                      $tongmon_dapung[$x->maCDR3]++;
                      break;
                      ?> 
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php if($dapung==1): ?>
                    <td>x</td>
                  <?php else: ?>
                    <td>&nbsp;</td>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
              <?php else: ?>
                <?php $__currentLoopData = $ctdt_cdr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                  <td>&nbsp;</td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            <td><?php echo e($tongcdr_cuamon); ?></td>
            <?php
              $tongcong=$tongcong+$tongcdr_cuamon;
            ?>  
          </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <tfoot>
        <tr>
          <td ></td> 
          <td >Total</td>
          <?php $__currentLoopData = $ctdt_cdr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td ><?php echo e($tongmon_dapung[$x->maCDR3]); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <td ><?php echo e($tongcong); ?></td>
        </tr>
      </tfoot>
  </table><?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/admin/thongke/viewExportThongKeCTCDR3.blade.php ENDPATH**/ ?>