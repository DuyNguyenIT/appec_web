
<?php $__env->startSection('content'); ?>
    <style>
        table {
            z-index: 1;
        }

        .fixed_header thead {
            background: green;
            color: #fff;
            width: 300px;
        }

        .fixed_header th,
        td {
            padding: 0.25rem;
        }

        .fixed_header th {
            background: green;
            color: black;
            position: sticky;
            top: 0;
            /* Don't forget this, required for the stickiness */
            box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.4);
        }

        .fixed_header tr:hover {
            background-color: rgb(181, 209, 138);
        }

        .fixed_header td:hover::after,
        .fixed_header th:hover::after {
            content: "";
            position: absolute;
            background-color: rgb(181, 209, 138);
            left: 0;
            top: -5000px;
            height: 100px;
            width: 100%;
            z-index: -1;
        }

    </style>
    <div class="content-wrapper" style="min-height: 96px;">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">
                            <?php echo e(__('Level-2 Student Outcomes')); ?> <-> Abet <noscript></noscript>
                                <nav></nav>
                        </h1>
                    </div>
                    <!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(asset('quan-ly')); ?>"><?php echo e(__('Home')); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo e(__('Level-2 Student Outcomes')); ?> <-> Abet </li>
                        </ol>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">
                                    <button type="button" class="btn btn-primary" data-toggle="modal"
                                        data-target="#exampleModal">
                                        <i class="fas fa-plus"></i>
                                    </button>
                                </h3>
                                <!-- Modal add-->
                                <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog"
                                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-lg" role="document">
                                        <form action="<?php echo e(asset('quan-ly/chuan-dau-ra2-abet/them')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">
                                                        <?php echo e(__('Adding a new')); ?> <?php echo e(__('Level-2 Student Outcomes')); ?>

                                                        <?php echo e(__('Abet')); ?> </h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="form-group">
                                                        <label><?php echo e(__('Level-2 Student Outcomes')); ?></label>
                                                        <select name="maCDR2" class="form-control">
                                                            <?php $__currentLoopData = $cdr2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($cd->maCDR2); ?>">
                                                                    <?php if(Session::has('language') && Session::get('language') == 'vi'): ?>
                                                                        <?php echo e($cd->maCDR2VB); ?>--<?php echo e($cd->tenCDR2); ?>

                                                                    <?php else: ?>
                                                                        <?php echo e($cd->maCDR2VB); ?>--<?php echo e($cd->tenCDR2EN); ?>

                                                                    <?php endif; ?>
                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                    <div class="form-group">
                                                        <label><?php echo e(__('Abet')); ?></label>
                                                        <select name="maChuanAbet" class="form-control">
                                                            <?php $__currentLoopData = $chuanAbet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($abet->maChuanAbet); ?>">
                                                                    <?php if(Session::has('language') && Session::get('language') == 'vi'): ?>
                                                                        <?php echo e($abet->maChuanAbetVB); ?>--<?php echo e($abet->tenChuanAbet); ?>

                                                                    <?php else: ?>
                                                                        <?php echo e($abet->maChuanAbetVB); ?>--<?php echo e($abet->tenChuanAbet_EN); ?>

                                                                    <?php endif; ?>
                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="submit" class="btn btn-primary">
                                                        <?php echo e(__('Save')); ?>

                                                    </button>
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                                                        <?php echo e(__('Cancel')); ?>

                                                    </button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <table class="table table-bordered fixed_header">
                                    <thead>
                                        <tr>
                                            <th><?php echo e(__('Level-2 Student Outcomes')); ?></th>
                                            <?php $__currentLoopData = $chuanAbet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <th><?php echo e($abet->maChuanAbetVB); ?></th>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $i = 1;
                                        ?>
                                        <?php $__currentLoopData = $cdr2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cd2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php if(Session::has('language') && Session::get('language') == 'vi'): ?>
                                                        <?php echo e($cd2->maCDR2VB); ?>--<?php echo e($cd2->tenCDR2); ?>

                                                    <?php else: ?>
                                                        <?php echo e($cd2->maCDR2VB); ?>--<?php echo e($cd2->tenCDR2EN); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <?php $__currentLoopData = $chuanAbet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <td>
                                                        <?php $__currentLoopData = $cdr2_abet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($data->maChuanAbet == $abet->maChuanAbet && $data->maCDR2 == $cd2->maCDR2): ?>
                                                                <!-- Button trigger modal -->
                                                                <button type="button" class="btn btn-primary"
                                                                    data-toggle="modal"
                                                                    data-target="#edit_<?php echo e($data->id); ?>">
                                                                    x
                                                                </button>
                                                                <!-- Modal -->
                                                                <div class="modal fade" id="edit_<?php echo e($data->id); ?>"
                                                                    tabindex="-1" role="dialog"
                                                                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                                    <div class="modal-dialog" role="document">
                                                                        <form
                                                                            action="<?php echo e(asset('/quan-ly/chuan-dau-ra2-abet/sua')); ?>"
                                                                            method="post">
                                                                            <?php echo csrf_field(); ?>
                                                                            <div class="modal-content">
                                                                                <div class="modal-header">
                                                                                    <h5 class="modal-title"
                                                                                        id="exampleModalLabel">
                                                                                        <?php echo e(__('Edit')); ?></h5>
                                                                                    <button type="button" class="close"
                                                                                        data-dismiss="modal"
                                                                                        aria-label="Close">
                                                                                        <span
                                                                                            aria-hidden="true">&times;</span>
                                                                                    </button>
                                                                                </div>
                                                                                <div class="modal-body">
                                                                                    <div class="form-group">
                                                                                        <input type="text" name="id"
                                                                                            value="<?php echo e($data->id); ?>"
                                                                                            hidden>
                                                                                    </div>
                                                                                    <div class="form-group">
                                                                                        <label><?php echo e(__('Level-2 Student Outcomes')); ?></label>
                                                                                        <select name="maCDR2"
                                                                                            class="form-control">
                                                                                            <?php $__currentLoopData = $cdr2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                <?php if($data->maCDR2 == $cd->maCDR2): ?>
                                                                                                    <option
                                                                                                        value="<?php echo e($cd->maCDR2); ?>"
                                                                                                        selected>
                                                                                                        <?php if(Session::has('language') && Session::get('language') == 'vi'): ?>
                                                                                                            <?php echo e($cd->maCDR2VB); ?>--<?php echo e($cd->tenCDR2); ?>

                                                                                                        <?php else: ?>
                                                                                                            <?php echo e($cd->maCDR2VB); ?>--<?php echo e($cd->tenCDR2EN); ?>

                                                                                                        <?php endif; ?>
                                                                                                    </option>
                                                                                                <?php else: ?>
                                                                                                    <option
                                                                                                        value="<?php echo e($cd->maCDR2); ?>">
                                                                                                        <?php if(Session::has('language') && Session::get('language') == 'vi'): ?>
                                                                                                            <?php echo e($cd->maCDR2VB); ?>--<?php echo e($cd->tenCDR2); ?>

                                                                                                        <?php else: ?>
                                                                                                            <?php echo e($cd->maCDR2VB); ?>--<?php echo e($cd->tenCDR2EN); ?>

                                                                                                        <?php endif; ?>
                                                                                                    </option>
                                                                                                <?php endif; ?>
                                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                        </select>
                                                                                    </div>
                                                                                    <div class="form-group">
                                                                                        <label><?php echo e(__('Abet')); ?></label>
                                                                                        <select name="maChuanAbet"
                                                                                            class="form-control">
                                                                                            <?php $__currentLoopData = $chuanAbet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                                <?php if($data->maChuanAbet == $abet->maChuanAbet): ?>
                                                                                                    <option
                                                                                                        value="<?php echo e($abet->maChuanAbet); ?>"
                                                                                                        selected>
                                                                                                        <?php if(Session::has('language') && Session::get('language') == 'vi'): ?>
                                                                                                            <?php echo e($abet->maChuanAbetVB); ?>--<?php echo e($abet->tenChuanAbet); ?>

                                                                                                        <?php else: ?>
                                                                                                            <?php echo e($abet->maChuanAbetVB); ?>--<?php echo e($abet->tenChuanAbet_EN); ?>

                                                                                                        <?php endif; ?>
                                                                                                    </option>
                                                                                                <?php else: ?>
                                                                                                    <option
                                                                                                        value="<?php echo e($abet->maChuanAbet); ?>">
                                                                                                        <?php if(Session::has('language') && Session::get('language') == 'vi'): ?>
                                                                                                            <?php echo e($abet->maChuanAbetVB); ?>--<?php echo e($abet->tenChuanAbet); ?>

                                                                                                        <?php else: ?>
                                                                                                            <?php echo e($abet->maChuanAbetVB); ?>--<?php echo e($abet->tenChuanAbet_EN); ?>

                                                                                                        <?php endif; ?>
                                                                                                    </option>
                                                                                                <?php endif; ?>
                                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                        </select>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="modal-footer">
                                                                                    <button type="submit"
                                                                                        class="btn btn-primary">
                                                                                        <?php echo e(__('Update')); ?>

                                                                                    </button>
                                                                                    <?php if(Session::has('language') && Session::get('language') == 'vi'): ?>
                                                                                        <a href="<?php echo e(asset('/quan-ly/chuan-dau-ra2-abet/xoa/' . $data->id)); ?>"
                                                                                            class="btn btn-danger"
                                                                                            onclick=" return confirm('Xác nhận xóa?')">
                                                                                            <i class="fas fa-trash"></i>
                                                                                        </a>
                                                                                    <?php else: ?>
                                                                                        <a href="<?php echo e(asset('/quan-ly/chuan-dau-ra2-abet/xoa/' . $data->id)); ?>"
                                                                                            class="btn btn-danger"
                                                                                            onclick=" return confirm('delete confirmation?')">
                                                                                            <i class="fas fa-trash"></i>
                                                                                        </a>
                                                                                    <?php endif; ?>
                                                                                    <button type="button"
                                                                                        class="btn btn-secondary"
                                                                                        data-dismiss="modal"><?php echo e(__('Cancel')); ?>

                                                                                    </button>
                                                                                </div>
                                                                            </div>
                                                                        </form>

                                                                    </div>
                                                                </div>
                                                            <?php break; ?>
                                                        <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot></tfoot>
                                </table>
                            </div>
                            <!-- /.card-body -->
                            <!-- /.card -->
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/admin/cdr2_chuanAbet.blade.php ENDPATH**/ ?>