
<?php $__env->startSection('content'); ?>
<div class="content-wrapper" style="min-height: 155px;">
     <!-- Content Header (Page header) -->
     <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark"> <?php echo e(__('Course information')); ?><noscript></noscript>
                        <nav></nav>
                    </h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(asset('/giao-vu')); ?>"><?php echo e(__('Home')); ?></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(asset('/giao-vu/cap-nhat-diem-ket-thuc')); ?>"><?php echo e($maHK); ?> <?php echo e($namHoc); ?></a></li>
                        <li class="breadcrumb-item active"><?php echo e(__('Course')); ?></li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
      <!-- /.content-header -->
      <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <?php echo e(__('Semester')); ?>: <?php echo e($maHK); ?> -- <?php echo e(__('Academic year')); ?>: <?php echo e($namHoc); ?>

                            </h3>
                            <div class="card-tools">
                                <a href="<?php echo e(asset('/giao-vu/cap-nhat-diem-ket-thuc')); ?>" class="btn btn-success">
                                      <i class="fas fa-arrow-left"></i>
                                </a>
                        </div>
                        </div>
                        <div class="card-body">
                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th><?php echo e(__('No.')); ?></th>
                                        <th><?php echo e(__('Course name')); ?></th>
                                        <th><?php echo e(__('Lecture')); ?></th>
                                        <th><?php echo e(__('Class')); ?></th>
                                        <th><?php echo e(__('Option')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $i=1;
                                    ?>
                                    <?php $__currentLoopData = $giangday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <tr>
                                            <td><?php echo e($i++); ?></td>
                                            <td><?php echo e($gd->hocphan->tenHocPhan); ?></td>
                                            <td>
                                                <?php $__currentLoopData = $gd->GV; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($gv->hoGV); ?> <?php echo e($gv->tenGV); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td>
                                                <?php echo e($gd->maLop); ?>

                                            </td>
                                            <td></td>
                                       </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot></tfoot>
                            </table>
                            <!-- /.col -->
                        </div>
                        <!-- /.row -->
                    </div>
                    <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('giaovu.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/giaovu/capnhatdiem/hocphan.blade.php ENDPATH**/ ?>