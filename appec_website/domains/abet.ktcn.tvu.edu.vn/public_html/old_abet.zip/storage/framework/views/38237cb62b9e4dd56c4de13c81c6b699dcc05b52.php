<table id="" class="table table-bordered table-hover">
    <thead>
        <tr>
            <th>STT</th>
            <th>Điểm chữ</th>
            <th>Số lượng</th>
            <th>Tỉ lệ (%)</th>
            <th>Tỉ lệ tích lũy</th>
        </tr>
    </thead>
    <tbody>
        <?php
            $tongSL=$tongTiLe=0;
        ?>
        <?php for($i = 0; $i < 8; $i++): ?>
            <tr>
                <td><?php echo e($i + 1); ?></td>
                <td>
                    <?php echo e($chu[$i]); ?>

                </td>
                <td><?php echo e($diemChu[$i]); ?></td>
                <td><?php echo e($tiLe[$i]); ?>%</td>
                <td></td>
            </tr>
            <?php
                $tongSL+=$diemChu[$i];
                $tongTiLe+=$tiLe[$i];
            ?>
        <?php endfor; ?>
        <tr>
            <td colspan="2"><b>Tổng</b></td>
            <td><?php echo e($tongSL); ?></td>
            <td><?php echo e($tongTiLe); ?></td>
            <td></td>
        </tr>
    </tbody>
    <tfoot>
    </tfoot>
</table><?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/layouts/thongke/thongke_diemchu.blade.php ENDPATH**/ ?>