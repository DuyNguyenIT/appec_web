<table>
    <thead>
        <tr>
            <th><?php echo e(__('No.')); ?></th>
            <th><?php echo e(__('Student name')); ?></th>
            <th><?php echo e(__('Student Name')); ?></th>
            <th><?php echo e(__('Exame ID')); ?></th>
            <th><?php echo e(__('Mark')); ?></th>
        </tr>
    </thead>
    <tbody>
        <?php
            $i = 1;
        ?>
        <?php $__currentLoopData = $phieucham; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($i++); ?></td>
                <td><?php echo e($data->maSSV); ?></td>
                <td><?php echo e($data->HoSV); ?> <?php echo e($data->TenSV); ?></td>
                <td><?php echo e($data->maDeVB); ?></td>
                <td><?php echo e($data->diemSo); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <tfoot></tfoot>
</table><?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/giangvien/ketqua/thuchanh/exportViewThucHanh/exportDiemThucHanh.blade.php ENDPATH**/ ?>