
<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">
                            <?php echo e(__('Project')); ?><noscript></noscript>
                            <nav></nav>
                        </h1>
                    </div>
                    <!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(asset('giang-vien')); ?>"><?php echo e(__('Home')); ?></a>
                            </li>
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/quy-hoach-ket-qua/' . Session::get('maHocPhan') . '/' . Session::get('maBaiQH') . '/' . Session::get('maHK') . '/' . Session::get('namHoc') . '/' . Session::get('maLop'))); ?>">
                                    <?php if(session::has('language') && session::get('language')=='en'): ?>
                                        <?php echo e($hp->tenHocPhanEN); ?>

                                    <?php else: ?>
                                       <?php echo e($hp->tenHocPhan); ?>

                                    <?php endif; ?>
                                    </a>
                            </li>
                            <li class="breadcrumb-item active"><?php echo e(__('Project')); ?></li>
                        </ol>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">
                                    <b><?php echo e(__("Granding officer")); ?> 1:</b> <?php echo e($gv->hoGV); ?> <?php echo e($gv->tenGV); ?> <?php echo e($gv->LoaiCB); ?><br />
                                    <b><?php echo e(__("Granding officer")); ?> 2:</b> <?php echo e($gv2->hoGV); ?> <?php echo e($gv2->tenGV); ?> <?php echo e($gv2->LoaiCB); ?><br />
                                </h4>
                                <div class="card-tools">
                                    <a href="<?php echo e(asset('/giang-vien/ket-qua-danh-gia/xuat-bang-diem-do-an/'.Session::get('maCTBaiQH'))); ?>" class="btn btn-success">
                                        <i class="fas fa-download"></i> <i class="fas fa-file-excel"></i>
                                    </a>
                                    <a href="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/quy-hoach-ket-qua/' . Session::get('maHocPhan') . '/' . Session::get('maBaiQH') . '/' . Session::get('maHK') . '/' . Session::get('namHoc') . '/' . Session::get('maLop'))); ?>"
                                        class="btn btn-success"><i class="fas fa-arrow-left"></i></a>
                                </div>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <table id="example2" class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th><?php echo e(__('No.')); ?></th>
                                            <th><?php echo e(__('Project name')); ?></th>
                                            <th><?php echo e(__('Student name')); ?></th>
                                            <th><?php echo e(__('Student ID')); ?></th>
                                            <th><?php echo e(__('Mark of granding officer')); ?> 1</th>
                                            <th><?php echo e(__('Mark of granding officer')); ?> 2</th>
                                            <th><?php echo e(__('Option')); ?></th>
                                            <th><?php echo e(__('Edit')); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $i = 1;
                                            $chayTenDT = 0;
                                            $maDe_cur = 0;
                                        ?>
                                        <?php $__currentLoopData = $deThi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                
                                                $demTenDT = $deThi->where('maDe', $dt->maDe)->count();
                                                if ($chayTenDT > $demTenDT) {
                                                    $chayTenDT = 1;
                                                } else {
                                                    $chayTenDT += 1;
                                                }
                                                if ($maDe_cur !== $dt->maDe) {
                                                    $maDe_cur = $dt->maDe;
                                                    $chayTenDT = 1;
                                                }
                                            ?>
                                            <?php if($chayTenDT == 1): ?>
                                                <tr>
                                                    <td rowspan=<?php echo e($demTenDT); ?>><?php echo e($i++); ?></td>
                                                    <td rowspan=<?php echo e($demTenDT); ?>><?php echo e($dt->tenDe); ?></td>
                                                    <td><?php echo e($dt->HoSV); ?> <?php echo e($dt->TenSV); ?></td>
                                                    <td><?php echo e($dt->maSSV); ?></td>
                                                    <?php if($dt->trangThai == false): ?>
                                                        <td>
                                                            <?php echo e($dt->diemSo); ?>

                                                        </td>
                                                        <td>
                                                            <?php echo e($dt->diemCB2); ?>

                                                        </td>
                                                        <td>
                                                            <a
                                                                href="<?php echo e(asset('/giang-vien/ket-qua-danh-gia/nhap-diem-do-an/' . $dt->maDe . '/' . $dt->maSSV)); ?>">
                                                                <button class="btn btn-primary">
                                                                    <i class="fas fa-edit"></i> <?php echo e(__('Granding')); ?>

                                                                </button>
                                                            </a>
                                                        </td>
                                                    <?php else: ?>
                                                        <td><?php echo e($dt->diemSo); ?></td>
                                                        <td><?php echo e($dt->diemCB2); ?></td>
                                                        <td>
                                                            <a
                                                                href="<?php echo e(asset('/giang-vien/ket-qua-danh-gia/xem-ket-qua-danh-gia/' . $dt->maDe . '/' . $dt->maSSV . '/1')); ?>">
                                                                <button class="btn btn-success">
                                                                    <i class="fas fa-eye"></i> <?php echo e(__('Mark of granding officer')); ?> 1
                                                                </button>
                                                            </a>
                                                            <a
                                                                href="<?php echo e(asset('/giang-vien/ket-qua-danh-gia/xem-ket-qua-danh-gia/' . $dt->maDe . '/' . $dt->maSSV . '/2')); ?>">
                                                                <button class="btn btn-primary">
                                                                    <i class="fas fa-eye"></i> <?php echo e(__('Mark of granding officer')); ?> 2
                                                                </button>
                                                            </a>
                                                        </td>
                                                    <?php endif; ?>
                                                    <td> <a
                                                        href="<?php echo e(asset('/giang-vien/ket-qua-danh-gia/sua-ket-qua-danh-gia-do-an/' . $dt->maDe . '/' . $dt->maSSV . '/1')); ?>">
                                                        <button class="btn btn-success">
                                                            <i class="fas fa-edit"></i> <?php echo e(__('Edit')); ?>

                                                        </button>
                                                    </a></td>
                                                </tr>
                                            <?php else: ?>
                                                <tr>
                                                    <td><?php echo e($dt->HoSV); ?> <?php echo e($dt->TenSV); ?></td>
                                                    <td><?php echo e($dt->maSSV); ?></td>
                                                    <?php if($dt->trangThai == false): ?>
                                                        <td>
                                                        </td>
                                                        <td>
                                                        </td>
                                                        <td>
                                                            <a
                                                                href="<?php echo e(asset('/giang-vien/ket-qua-danh-gia/nhap-diem-do-an/' . $dt->maDe . '/' . $dt->maSSV)); ?>">
                                                                <button class="btn btn-primary">
                                                                    <i class="fas fa-edit"></i> Chấm điểm
                                                                </button>
                                                            </a>
                                                        </td>
                                                    <?php else: ?>
                                                        <td><?php echo e($dt->diemSo); ?></td>
                                                        <td><?php echo e($dt->diemCB2); ?></td>
                                                        <td>
                                                            <a
                                                                href="<?php echo e(asset('/giang-vien/ket-qua-danh-gia/xem-ket-qua-danh-gia/' . $dt->maDe . '/' . $dt->maSSV . '/1')); ?>">
                                                                <button class="btn btn-success">
                                                                    <i class="fas fa-eye"></i> <?php echo e(__('Mark of granding officer')); ?> 1
                                                                </button>
                                                            </a>
                                                            <a
                                                                href="<?php echo e(asset('/giang-vien/ket-qua-danh-gia/xem-ket-qua-danh-gia/' . $dt->maDe . '/' . $dt->maSSV . '/2')); ?>">
                                                                <button class="btn btn-primary">
                                                                    <i class="fas fa-eye"></i> <?php echo e(__('Mark of granding officer')); ?> 2
                                                                </button>
                                                            </a>
                                                        </td>
                                                    <?php endif; ?>
                                                    <td> <a
                                                        href="<?php echo e(asset('/giang-vien/ket-qua-danh-gia/sua-ket-qua-danh-gia-do-an/' . $dt->maDe . '/' . $dt->maSSV . '/1')); ?>">
                                                        <button class="btn btn-success">
                                                            <i class="fas fa-edit"></i> <?php echo e(__('Edit')); ?>

                                                        </button>
                                                    </a></td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot></tfoot>
                                </table>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('giangvien.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/giangvien/ketqua/ketquadoan.blade.php ENDPATH**/ ?>