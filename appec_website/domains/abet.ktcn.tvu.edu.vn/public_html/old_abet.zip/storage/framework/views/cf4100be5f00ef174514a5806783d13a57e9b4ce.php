
<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="<?php echo e(asset('dist/css/foldertree.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist/css/hortreebootstrap.css')); ?>">

    <div class="content-wrapper" style="min-height: 22px;">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">
                            <?php echo e(__('Curriculum')); ?><noscript></noscript>
                            <nav></nav>
                        </h1>
                    </div>
                    <!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(asset('/quan-ly')); ?>"><?php echo e(__('Home')); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo e(__('Curriculum')); ?></li>
                        </ol>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>

        
        <section class="content">

            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">
                                    
                                    <!-- Button trigger modal -->
                                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#edit_bien_soan">
                                        <i class="fas fa-clock"></i> Thời gian biên soạn đề cương
                                    </button>
                                    
                                    <!-- Modal thoi gian bien soan de cuong-->
                                    <div class="modal fade" id="edit_bien_soan" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <form action="<?php echo e(asset('/quan-ly/bien-soan-va-phan-bien-de-cuong/dieu-chinh-thoi-gian-bien-soan')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Điều chỉnh</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="from-group">
                                                        <label for="">Ngày bắt đầu:</label>
                                                        <input id="listingDateOpen" type="datetime-local" name="thoiGianBatDau" class="form-control" required>
                                                    </div>
                                                    <div class="from-group">
                                                        <label for="">Ngày kết thúc</label>
                                                        <input id="listingDateClose" type="datetime-local" name="thoiGianKetThuc" class="form-control" required>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
                                                </div>
                                            </div>
                                            </form>
                                        </div>
                                    </div>


                                    <!-- Button trigger modal -->
                                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#edit_phan_bien">
                                        <i class="fas fa-clock"></i> Thời gian phản biện đề cương
                                    </button>
                                    
                                    <!-- Modal -->
                                    <div class="modal fade" id="edit_phan_bien" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                        <form action="<?php echo e(asset('/quan-ly/bien-soan-va-phan-bien-de-cuong/dieu-chinh-thoi-gian-phan-bien')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Điều chỉnh</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="from-group">
                                                    <label for="">Ngày bắt đầu:</label>
                                                    <input id="listingDateOpen" type="datetime-local" name="thoiGianBatDau" class="form-control" required>
                                                </div>
                                                <div class="from-group">
                                                    <label for="">Ngày kết thúc</label>
                                                    <input id="listingDateClose" type="datetime-local" name="thoiGianKetThuc" class="form-control" required>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                                            </div>
                                        </div>
                                        </form>
                                        
                                        </div>
                                    </div>

                                </h3>
                                <div class="card-tools">
                                    <a href="<?php echo e(asset('/quan-ly/bien-soan-va-phan-bien-de-cuong')); ?>" class="btn btn-secondary">
                                           <i class="fas fa-arrow-left"></i>
                                     </a>
                                </div>
                            </div>
                            <!-- /.card-header -->
                        <script>
                            $("#listingDateOpen").change(function(){
                                openDate = $("#listingDateOpen").val();
                                let maxCloseDate = new Date(openDate);    
                                document.getElementById("listingDateClose").setAttribute("min", openDate);
                                document.getElementById("listingDateClose").setAttribute("value", openDate);        
                            });
                        </script>
                            
        <div class="card-body">   
            <div class="tree">                                 
            <ul>
                <?php $__currentLoopData = $XemctDaoTao; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                <li>     
                    <span>            
                        <a style="color:rgb(141, 5, 5); text-decoration:none;" data-toggle="collapse" href="#CT_<?php echo e($ct->maCT); ?>"  aria-expanded="false" aria-controls="CT_<?php echo e($ct->maCT); ?>" onclick="SaveCT('CT_'+<?php echo e($ct->maCT); ?>)">
                            <i class="collapsed">
                                <i class="fas fa-folder"> </i>
                            </i>
                            <i class="expanded">
                                <i class="far fa-folder-open"> </i>
                            </i>       
                            <?php echo e($ct->tenCT); ?> -- <?php echo e($ct->soHocKy); ?> <?php echo e(__('Semester')); ?> 
                        </a>
                    </span>
                <div id="CT_<?php echo e($ct->maCT); ?>" class="collapse">  
                <ul>                   
                <?php for($i=1;$i<=$ct->soHocKy;$i++): ?>
                    <li>                          
                            <span>
                                    <a style="color:#080808; text-decoration:none;" data-toggle="collapse" href="#HK_<?php echo e($ct->maCT.$i); ?>"  aria-expanded="false" aria-controls="HK_<?php echo e($ct->maCT.$i); ?>" onclick="SaveHK('HK_'+<?php echo e($ct->maCT.$i); ?>)">
                                    <i class="collapsed"><i class="fas fa-folder"></i></i>
                                    <i class="expanded"><i class="far fa-folder-open"></i></i>                        
                                        <b> Hoc Ky: <?php echo e($i); ?>   </b>
                                    </a>                      
                            </span>   
                            <div id="HK_<?php echo e($ct->maCT.$i); ?>" class="collapse"> 

                            <ul> 
                                <li>                          
                                    <span>
                                            <a style="color:#080808; text-decoration:none;" data-toggle="collapse" href="#BB_<?php echo e($ct->maCT.$i); ?>"  aria-expanded="false" aria-controls="BB_<?php echo e($ct->maCT.$i); ?>" onclick="SaveLHP('BB_'+<?php echo e($ct->maCT.$i); ?>)">
                                    
                                            <i class="collapsed"><i class="fas fa-folder"></i></i>
                                            <i class="expanded"><i class="far fa-folder-open"></i></i>                        
                                                <b> HỌC PHAN BB   </b>
                                            </a>                      
                                    </span>   
                                    <div id="BB_<?php echo e($ct->maCT.$i); ?>" class="collapse"> 

                                        <ul> <?php $__currentLoopData = $hocphan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($ct->maCT == $hp->maCT && $hp->phanPhoiHocKy==$i): ?>
                                                <?php $__currentLoopData = $hocphan_ten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hpt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                               
                                                    <?php if($hp->maHocPhan == $hpt->maHocPhan && $hp->maLoaiHocPhan=="BB"): ?>
                                                        <li>                                      
                                                            <i class="far fa-circle"></i>
                                                            <a href="<?php echo e(asset('/quan-ly/bien-soan-va-phan-bien-de-cuong/xem-thong-tin-hoc-phan/' . $hp->maHocPhan)); ?>" >
                                                                <?php echo e($hpt->tenHocPhan); ?>  (<?php echo e(__('Thoery')); ?>:<?php echo e($hpt->tinChiLyThuyet); ?> & <?php echo e(__('Practice')); ?>: <?php echo e($hpt->tinChiThucHanh); ?>)
                                                            </a>
                                                        </li>
                                                    <?php endif; ?>                                 
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>                
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
        
                                        </ul>

                                    </div>
                                </li>

                                <li>                          
                                    <span>
                                            <a style="color:#080808; text-decoration:none;" data-toggle="collapse" href="#TC_<?php echo e($ct->maCT.$i); ?>"  aria-expanded="false" aria-controls="TC_<?php echo e($ct->maCT.$i); ?>" onclick="SaveLHP('TC_'+<?php echo e($ct->maCT.$i); ?>)">
                                    
                                            <i class="collapsed"><i class="fas fa-folder"></i></i>
                                            <i class="expanded"><i class="far fa-folder-open"></i></i>                        
                                                <b> HỌC PHAN TC   </b>
                                            </a>                      
                                    </span>   
                                    <div id="TC_<?php echo e($ct->maCT.$i); ?>" class="collapse"> 

                                        <ul> <?php $__currentLoopData = $hocphan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($ct->maCT == $hp->maCT && $hp->phanPhoiHocKy==$i): ?>
                                                <?php $__currentLoopData = $hocphan_ten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hpt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                               
                                                    <?php if($hp->maHocPhan == $hpt->maHocPhan && $hp->maLoaiHocPhan=="TC"): ?>
                                                        <li>                                      
                                                            <i class="far fa-circle"></i>
                                                            <a href="<?php echo e(asset('/quan-ly/bien-soan-va-phan-bien-de-cuong/xem-thong-tin-hoc-phan/' . $hp->maHocPhan)); ?>" >
                                                                <?php echo e($hpt->tenHocPhan); ?>  (<?php echo e(__('Thoery')); ?>:<?php echo e($hpt->tinChiLyThuyet); ?> & <?php echo e(__('Practice')); ?>: <?php echo e($hpt->tinChiThucHanh); ?>)
                                                            </a>
                                                        </li>
                                                    <?php endif; ?>                                 
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>                
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
        
                                        </ul>

                                    </div>
                                </li>
                                
                                                    </div> 
                                                                            
                                            </li>
                                            <?php endfor; ?>
                                    </ul>
                                    </div>            
                                </li> 
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            </ul>    
                            </div>                             
                                                            
                            </div>                      
                            
                        
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
            <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    </div>
    <script src="<?php echo e(asset('dist/js/foldertree.js')); ?>"></script>
    <script>
          $(document).ready(function() {
            checkTree()
            });

        function checkTree(){
            console.log('checkTree run');
            if (localStorage.getItem("CT")) { 
                $("div[id="+localStorage.getItem("CT")+"]").removeClass("collapse");
                $("div[id="+localStorage.getItem("CT")+"]").addClass("expanded");
                if(localStorage.getItem("HK")){
                    $("div[id="+localStorage.getItem("HK")+"]").removeClass("collapse");
                    $("div[id="+localStorage.getItem("HK")+"]").addClass("expanded");
                    if(localStorage.getItem("LHP")){
                        $("div[id="+localStorage.getItem("LHP")+"]").removeClass("collapse");
                        $("div[id="+localStorage.getItem("LHP")+"]").addClass("expanded");
                    }
                }
            }
        }
        function SaveCT(maCT){
            console.log('save CT run');
            localStorage.setItem('CT', maCT); 
        }
        function SaveHK(hk){
            console.log('save HK run');
            localStorage.setItem('HK', hk); 
        }
        function SaveLHP(lhp){
            console.log('save LHP run');
            localStorage.setItem('LHP', lhp); 
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/admin/ctdaotao/xemchuongtrinhDT.blade.php ENDPATH**/ ?>