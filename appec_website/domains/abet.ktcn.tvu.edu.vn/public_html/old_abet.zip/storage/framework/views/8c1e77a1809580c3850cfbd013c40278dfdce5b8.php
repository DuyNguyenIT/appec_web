
<?php $__env->startSection('content'); ?>
<script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
<div class="content-wrapper" style="min-height: 58px;">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0 text-dark">
            Nội dung học phần<noscript></noscript>
            <nav></nav>
          </h1>
        </div>
        <!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(asset('/')); ?>">Trang chủ</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(asset('giang-vien/hoc-phan')); ?>">
              <?php echo e(\Illuminate\Support\Str::limit(html_entity_decode($hocPhan->tenHocPhan),$limit=20,$end='...')); ?>  
            </a></li>
            <li class="breadcrumb-item active">Nội dung học phần</li>
          </ol>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->
  <?php if(session('success')): ?>
  <div class="alert alert-success alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
    <h5><i class="icon fas fa-check"></i> Thông báo!</h5>
    <?php echo e(session('success')); ?>

  </div>
<?php endif; ?>
<?php if(session('warning')): ?>
  <div class="alert alert-warning alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
    <h5><i class="icon fas fa-exclamation-triangle"></i> Thông báo!</h5>
    <?php echo e(session('warning')); ?>

  </div>
<?php endif; ?>
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">
                  
              </h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                  <tr>
                    <th >Order</th>
                    <th >Chapter name</th>
                    <th >Description</th>
                    <th >Option</th>
                  </tr>
                </thead>
                <tbody>
                  
                  <?php
                      $i=1;
                  ?>
                <?php $__currentLoopData = $chuong; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($i++); ?></td>
                      <td><?php echo e($item->tenchuong); ?></td>
                      <td><?php echo html_entity_decode($item->mota); ?></td>
                      <td style='white-space: nowrap'>
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#edit_<?php echo e($item->id); ?>">
                          <li class="fas fa-edit"></li>
                        </button>
                        <a href="" class="btn btn-danger" ><i class="fas fa-trash"></i></a>
                     <a class="btn btn-success" href="<?php echo e(asset('/giang-vien/hoc-phan/chuong/muc/'.$item->id)); ?>"><i class="fas fa-list-ul"></i> item </a>
                        <!-- Modal -->
                        <div class="modal fade" id="edit_<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                          <div class="modal-dialog modal-lg" role="document">
                            <form action="<?php echo e(asset('giang-vien/hoc-phan/chuong/suasubmit')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Chỉnh sửa</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <input type="text" name="id" value="<?php echo e($item->id); ?>" hidden>
                                <div class="form-group">
                                  <label for="">Nhập tên chương:</label>

                                  <input type="text" name="tenchuong" value="<?php echo e($item->tenchuong); ?>" class="form-control">
                                </div>
                                <div class="form-group">
                                  <label for="">Nhập mô tả</label>
                                  <textarea name="mota" id="ckcontent_<?php echo e($item->id); ?>" class="form-control" cols="30" rows="10" required>
                                    <?php echo e($item->mota); ?>

                                  </textarea>
                                  <script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
                                  <script>
                                    CKEDITOR.replace( 'ckcontent_<?php echo e($item->id); ?>', {
                                        filebrowserUploadUrl: "<?php echo e(route('upload', ['_token' => csrf_token() ])); ?>",
                                        filebrowserUploadMethod: 'form'
                                    } );
                                </script>
                                </div>
                              </div>
                              <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Lưu</button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                              </div>
                            </div>
                            </form>
                            
                          </div>
                        </div>
                      </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
               
                </tbody>
                <tfoot></tfoot>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('giangvien.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abet/domains/abet.ktcn.tvu.edu.vn/public_html/resources/views/giangvien/hocphan/chuong/index.blade.php ENDPATH**/ ?>