<table id="" class="table table-bordered table-hover">
    <thead>
        <tr>
            <th rowspan="2"><?php echo e(__('No.')); ?></th>
            <th rowspan="2">mã ABET</th>
            <th rowspan="2">ABET</th>
            <th colspan="4">Đạt</th>
            <th rowspan="2" title="">Chưa đạt</th>
            <th rowspan="2">Tổng</th>
        </tr>
        <tr>
            <th>A</th>
            <th>B</th>
            <th>C</th>
            <th>D</th>
        </tr>
    </thead>
    <tbody>
        <?php
            $i = 1;
        ?>
        <?php $__currentLoopData = $bieuDo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $sum = 0;
                for ($t = 1; $t < 7; $t++) {
                    # code...
                    $sum += intval($bd[$t]);
                }
            ?>
            <tr>
                <td><?php echo e($i++); ?></td>
                <td><?php echo e($bd[0]); ?></td>
                <td><?php echo e($bd[1]); ?></td>
                <td><?php echo e($bd[2]); ?></td>
                <td><?php echo e($bd[3]); ?></td>
                <td><?php echo e($bd[4]); ?></td>
                <td><?php echo e($bd[5]); ?></td>
                <td><?php echo e($bd[6]); ?></td>
                <td><?php echo e($sum); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <tfoot>
    </tfoot>
</table><?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/layouts/thongke/thongke_abet.blade.php ENDPATH**/ ?>