<h5><b>1. <?php echo e(__('General information')); ?></b></h5>
<!-- ----------------------------------1. Thông tin chung-------------------- -->
<table class="table table-bordered">
    <thead class="thead-green" style="background-color: green">
        <tr>
            <th><?php echo e(__('Course type')); ?></th>
            <th><?php echo e(__('Number of credits')); ?></th>
            <th><?php echo e(__('Number of learning periods')); ?></th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>
                <?php
                    $daicuong = ['A1', 'A2', 'A3', 'A4', 'A5'];
                    $coso = ['B1'];
                    $chuyennganh = ['B2', 'B3'];
                ?>
                <?php if(in_array($hocPhan->maCTKhoiKT, $daicuong)): ?>
                    <ul>
                        <li><?php echo e(__('General ')); ?> <i class="far fa-check-square"></i>
                        <li><?php echo e(__('Basic ')); ?>

                        <li><?php echo e(__('Specialized ')); ?>

                    </ul>
                <?php else: ?>
                    <?php if(in_array($hocPhan->maCTKhoiKT, $coso)): ?>
                        <ul>
                            <li><?php echo e(__('General ')); ?>

                            <li><?php echo e(__('Basic ')); ?> <i class="far fa-check-square"></i>
                            <li><?php echo e(__('Specialized ')); ?>

                        </ul>
                    <?php else: ?>
                        <?php if(in_array($hocPhan->maCTKhoiKT, $chuyennganh)): ?>
                            <ul>
                                <li><?php echo e(__('General ')); ?>

                                <li><?php echo e(__('Basic ')); ?>

                                <li><?php echo e(__('Specialized ')); ?> <i class="far fa-check-square"></i>
                            </ul>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>

            </td>
            <td>
                <ul>
                    <li><?php echo e(__('Theory')); ?>: <?php echo e($hocPhan->tinChiLyThuyet); ?>

                    <li><?php echo e(__('Exercise')); ?>:
                    <li><?php echo e(__('Practice')); ?>: <?php echo e($hocPhan->tinChiThucHanh); ?>

                </ul>
            </td>
            <td>
                <ul>
                    <li><?php echo e(__('Theory')); ?>: <?php echo e($hocPhan->tinChiLyThuyet * 15); ?>

                    <li><?php echo e(__('Exercise')); ?>:
                    <li><?php echo e(__('Practice')); ?>: <?php echo e($hocPhan->tinChiThucHanh * 30); ?>

                </ul>
            </td>
        </tr>
    </tbody>
</table>
<div class="row">
    <div class="col-md-4">
        <h6><b><?php echo e(__('Learners')); ?>:</b></h6>
    </div>
    <div class="col-md-7">
        <?php echo e(__('Education level')); ?>: <?php echo e($bac->tenBac); ?> <br>
        <?php echo e(__('Specialized')); ?>: <?php echo e($nganh->tenNganh); ?> <br>
        <?php echo e(__('Major')); ?>: <?php echo e($CNganh->tenCNganh); ?><br>
        <?php echo e(__('Forms of training')); ?>: <?php echo e($he->tenHe); ?> <br>
    </div>
    <div class="col-md-1">
        <td>
        </td>
    </div>
</div>
<h6><b><?php echo e(__('Forms of training')); ?></b></h6>
<table class="table table-bordered">
    <tr>
        <td><?php echo e(__('Prerequisites')); ?></td>
        <td><i>
                <?php $__currentLoopData = $monTQ; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <?php echo e($data->hoc_phan->tenHocPhan); ?> <a title="Delete" class="btn btn-danger"
                    onclick="return confirm('Confirm?')"
                    href="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/xoa-mon-tien-quyet/'.$data->id)); ?>">
                 <i class="fa fa-trash"></i>
             </a>;
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </i></td>
        <td>
            <!-- Button trigger modal -->
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addMonTQ">
                <i class="fas fa-edit"></i>
            </button>
            <!-- Modal mn tien quyet-->
            <div class="modal fade" id="addMonTQ" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/them_mon_tien_quyet')); ?>"
                        method="post">
                        <?php echo csrf_field(); ?>
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Adding prerequisites')); ?></h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for=""><?php echo e(__('Choosing prerequisites')); ?></label>
                                    <input type="text" name="maHocPhan" value="<?php echo e($hocPhan->maHocPhan); ?>" hidden>
                                    <select name="maMonTienQuyet" id="" class="form-control">
                                        <?php $__currentLoopData = $monHoc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($data->maHocPhan); ?>"> <?php echo e($data->maHocPhan); ?> --
                                                <?php echo e($data->tenHocPhan); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?> </button>
                                <button type="button" class="btn btn-secondary"
                                    data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </td>
    </tr>
    <tr>
        <td><?php echo e(__('Other requirements')); ?></td>
        <td>
            <i>
                <?php echo $hocPhan->yeuCau; ?>

            </i>
        </td>
        <td>
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addyeuCau">
                <i class="fas fa-edit"></i>
            </button>
            <!-- Modal -->
            <div class="modal fade" id="addyeuCau" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-lg" role="document">
                    <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/sua_yeu_cau_mon_hoc')); ?>"
                        method="post">
                        <?php echo csrf_field(); ?>
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Other requirements')); ?></h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <input type="text" name="maHocPhan" value="<?php echo e($hocPhan->maHocPhan); ?>" hidden>
                                </div>
                                <div class="form-group">
                                    <textarea name="yeuCau" id="yeuCau" cols="30" rows="10" class="form-control"
                                        required>
                                <?php echo e($hocPhan->yeuCau); ?>

                    
                              </textarea>
                                    <script>
                                        CKEDITOR.replace('yeuCau', {
                                            filebrowserUploadUrl: "<?php echo e(route('upload', ['_token' => csrf_token()])); ?>",
                                            filebrowserUploadMethod: 'form'
                                        });

                                    </script>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Save</button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </td>
    </tr>
</table>
<?php /**PATH D:\2_Co Nam\1_source code\source code 31-5\resources\views/layouts/decuong/chitietnoidung/1_thongtinchung.blade.php ENDPATH**/ ?>