<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('layouts.decuong.noidung', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.no_menu_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/admin/hocphan/themdecuong.blade.php ENDPATH**/ ?>