
<?php $__env->startSection('content'); ?>
    <!-- jQuery -->
    <script src="<?php echo e(asset('plugins/jquery/jquery.min.js')); ?>"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="<?php echo e(asset('plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">Phiếu đánh giá đồ án<noscript></noscript>
                            <nav></nav>
                        </h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(asset('giang-vien')); ?>">Trang chủ</a></li>
                            <li class="breadcrumb-item "><a href="#">Tên môn</a></li>
                            <li class="breadcrumb-item "><a href="#">Đồ án</a></li>
                            <li class="breadcrumb-item active">Phiếu chấm</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <!-- /.card -->
                        <form action="<?php echo e(asset('/giang-vien/ket-qua-danh-gia/cham-diem-submit')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="maPhieuCham" hidden value=<?php echo e($gv->maPhieuCham); ?>>
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="">
                                        1. Họ và tên (thành viên chấm): <?php echo e($gv->hoGV); ?> <?php echo e($gv->tenGV); ?> <br>
                                        2. Chức danh: <br>
                                        3. Đơn vị công tác: <br>
                                        4. Tên đề tài: <?php echo e($deTai->tenDe); ?> <br>
                                        5. Học và tên sinh viên bảo vệ: <?php echo e($sv->HoSV); ?> <?php echo e($sv->TenSV); ?> <br>
                                    </h5>
                                </div>
                                <!-- /.card-header -->
                                <div class="card-body">
                                    <i>(Thành viên chấm chọn tiêu chí tương ứng với mức độ mà sinh viên đạt được)</i>
                                    <table id="example2" class="table table-bordered table-hover">
                                        <thead>
                                            <tr>
                                                <th>STT</th>
                                                <th>Tiêu chuẩn</th>
                                                <th>Chuẩn đầu ra</th>
                                                <th>Tiêu chí</th>
                                                <th>Điểm</th>
                                                <th>Chọn 
                                                    <input type="checkbox" name="" id="selectAll"></th>
                                                    <script>
                                                        $("#selectAll").click(function(e) 
                                                    {
                                                        $("input[type=checkbox]").prop('checked', $(this).prop('checked'));   
                                                        if ($("input[id=selectAll]").is(':checked'))
                                                           {                                  
                                                             var A=$( "select" );
                                                             for(t=0;t< A.length; t++)
                                                              {                                                       
                                                                $( "select")[t].value=  $( "select")[t][$( "select")[t].length-1].value; 
                                                              }
                                                           }
                                                           else
                                                           {
                                                            var A=$( "select" );
                                                              for(t=0;t< A.length; t++)
                                                              {                 
                                                                  $( "select")[t].value= 0;                                                       
                                                             }
                                                      
                                                           }                                                       
                                                       
                                                    });
    
                                                    </script>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                $i = 1;
                                                $chayTieuChuan = 0;
                                                $chayCDR_TCDG = 0;
                                                $tieuChuanHienTai = 0;
                                                $cdrHienTai = 0;
                                                $cdcheck=1;
                                            ?>
                                            <?php $__currentLoopData = $tieuchi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    
                                                    if ($cdrHienTai != $tc->maCDR3) {
                                                        //kiểm tra nếu chuẩn đầu ra thay đổi thì chuyển biến chạy về 1
                                                        $cdrHienTai = $tc->maCDR3;
                                                        $chayCDR_TCDG = 1;
                                                    } else {
                                                        //nếu không tăng biến chạy lên
                                                        $chayCDR_TCDG += 1;
                                                    }
                                                    
                                                    if ($tieuChuanHienTai != $tc->maTCDG) {
                                                        //đặt kiểm tiêu chuẩn ở dưới vì khi khác tiêu chuẩn thì biến chayCDR phải trở về 1
                                                        $tieuChuanHienTai = $tc->maTCDG;
                                                        $chayTieuChuan = 1;
                                                        $chayCDR_TCDG = 1;
                                                    } else {
                                                        $chayTieuChuan += 1;
                                                    }
                                                    
                                                    $demTCDG = $tieuchi->groupBy('tenTCDG')->count();
                                                    $demCDR_TCDG = $tieuchi
                                                        ->where('maTCDG', $tc->maTCDG)
                                                        ->groupBy('tenCDR3')
                                                        ->count();
                                                    $demTieuChi_TCDG = $tieuchi->where('maTCDG', $tc->maTCDG)->count('tenTCCD');
                                                    $demTC_CDR = $tieuchi
                                                        ->where('maTCDG', $tc->maTCDG)
                                                        ->where('maCDR3', $tc->maCDR3)
                                                        ->count('tenTCCD');
                                                ?>
                                                <?php if($chayTieuChuan == 1): ?>
                                                    <tr>
                                                        <td rowspan=<?php echo e($demTieuChi_TCDG); ?>><?php echo e($i++); ?></td>
                                                        <td rowspan=<?php echo e($demTieuChi_TCDG); ?>><?php echo e($tc->tenTCDG); ?>

                                                            <b>(<?php echo e($tc->diem); ?> điểm)</b>
                                                        </td>
                                                        <?php if($chayCDR_TCDG == 1): ?>
                                                            <td rowspan=<?php echo e($demTC_CDR); ?>><?php echo e($tc->maCDR3VB); ?>:
                                                                <?php echo e($tc->tenCDR3); ?></td>
                                                            <td><?php echo e($tc->tenTCCD); ?> <b>(<?php echo e($tc->diemTCCD); ?> điểm)</b>
                                                            </td>
                                                        <?php else: ?>
                                                            <td><?php echo e($tc->tenTCCD); ?> <b>(<?php echo e($tc->diemTCCD); ?> điểm)</b>
                                                            </td>
                                                        <?php endif; ?>
                                                        <td>
                                                            <select name="chamdiem1[]" id ="cd21<?php echo e($cdcheck); ?>">
                                                            <?php for($i=0; $i<=$tc->diemTCCD; $i=$i+0.25): ?>                                                                 
                                                                 <option value="<?php echo e($i); ?>" > <?php echo e($i); ?></option>                                            
                                           
                                                            <?php endfor; ?>
                                                        </select> 
                                                        </td>
                                                        
                                                        
                                                        <script>
                                                 
                                                            document.getElementById('cd21<?php echo e($cdcheck); ?>').onclick= function(e)
                                                            {
                                                            
                                                               
                                                                if(document.getElementById('cd21<?php echo e($cdcheck); ?>').value==0)
                                                                    document.getElementById('cd1<?php echo e($cdcheck); ?>').checked=false;
                                                                 else
                                                                   {
                                                                         document.getElementById('cd1<?php echo e($cdcheck); ?>').checked=true;
            
                                                                               }   
                                                            }   
                    
                                                           </script>
                                                    </td>
                                                    <td>
                                                        <input type="checkbox" name="chamdiem[]"
                                                            value="<?php echo e($tc->maTCCD); ?>" id= "cd1<?php echo e($cdcheck); ?>" />
                                                            <script>                                                     
                                                                document.getElementById('cd1<?php echo e($cdcheck); ?>').onchange = function(e)
                                                                {
                                                                   
                                                                   if(document.getElementById('cd1<?php echo e($cdcheck); ?>').checked)
                                                                   document.getElementById('cd21<?php echo e($cdcheck); ?>').value= <?php echo e($tc->diemTCCD); ?>;
                                                                   else
                                                                   document.getElementById('cd21<?php echo e($cdcheck); ?>').value= 0;
                                                                      
                                                                };
                                                                </script>
                                                            
                                                    </td>
                                                    </tr>
                                                <?php else: ?>
                                                    <tr>
                                                        <?php if($chayCDR_TCDG == 1): ?>
                                                            <td rowspan=<?php echo e($demTC_CDR); ?>><?php echo e($tc->maCDR3VB); ?>:
                                                                <?php echo e($tc->tenCDR3); ?></td>
                                                            <td><?php echo e($tc->tenTCCD); ?> <b>(<?php echo e($tc->diemTCCD); ?> điểm)</b>
                                                            </td>
                                                        <?php else: ?>
                                                            <td><?php echo e($tc->tenTCCD); ?> <b>(<?php echo e($tc->diemTCCD); ?> điểm)</b>
                                                            </td>
                                                        <?php endif; ?>
                                                        <td>
                                                            <select name="chamdiem1[]" id ="cd2<?php echo e($cdcheck); ?>">
                                                                <?php for($i=0; $i<=$tc->diemTCCD; $i=$i+0.25): ?>  
                                                               
                                                                     <option value="<?php echo e($i); ?>" > <?php echo e($i); ?></option>                                                           
                                                             
                                                                <?php endfor; ?>
                                                            </select>  
                                                            <script>
                                                     
                                                                document.getElementById('cd2<?php echo e($cdcheck); ?>').onchange = function(e)
                                                                {
                                                                   
                                                                    if(document.getElementById('cd2<?php echo e($cdcheck); ?>').value==0)
                                                                        document.getElementById('cd11<?php echo e($cdcheck); ?>').checked=false;
                                                                     else
                                                                       {
                                                                                    document.getElementById('cd11<?php echo e($cdcheck); ?>').checked=true;
                
                                                                                   }                                                   
                                                                };       
                        
                                                        </script>      
                                                        </td>
                                                        <td>
                                                            <input type="checkbox" name="chamdiem[]"
                                                                value="<?php echo e($tc->maTCCD); ?>" id= "cd11<?php echo e($cdcheck); ?>"/>
                                                                <script>                                                     
                                                                    document.getElementById('cd11<?php echo e($cdcheck); ?>').onchange = function(e)
                                                                    {                                                                       
                                                                       if(document.getElementById('cd11<?php echo e($cdcheck); ?>').checked)
                                                                       document.getElementById('cd2<?php echo e($cdcheck); ?>').value= <?php echo e($tc->diemTCCD); ?>;
                                                                       else
                                                                       document.getElementById('cd2<?php echo e($cdcheck); ?>').value= 0;
                                                                          
                                                                    };
                                                                    </script>

                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                                <?php
                                                $cdcheck++
                                           ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        <tfoot>
                                        </tfoot>
                                    </table>
                                    <hr>
                                    <div class="form-group">
                                        <h5><b>Ý kiến đóng góp</b></h5>
                                        <input type="text" name="yKienDongGop" class="form-control">
                                    </div>
                                    <div class="form-group">
                                        <button class="btn btn-primary" type="submit">Chấm điểm</button>
                                    </div>
                                </div>
                                <!-- /.card-body -->
                            </div>
                        </form>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('giangvien.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/giangvien/ketqua/nhapDiemDoan.blade.php ENDPATH**/ ?>