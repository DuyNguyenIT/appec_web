
<?php $__env->startSection('content'); ?>
     <!-- jQuery -->
  <script src="<?php echo e(asset('plugins/jquery/jquery.min.js')); ?>"></script>
  <!-- jQuery UI 1.11.4 -->
  <script src="<?php echo e(asset('plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>
  <!-- ChartJS -->
  <script src="<?php echo e(asset('plugins/chart.js/Chart.min.js')); ?>"></script>
    <style type="text/css">
       
      .first {
        position:absolute;
        /*position: relative;*/
        width:60px;
        left: auto;
        display: block;
        z-index: 3;
       background-color:  #28a745;
      }

      .second {
          position:absolute;
          /*position: relative;*/
          width:300px;
          left:80px;
          z-index: 3;
         background-color: #28a745;
      }
      .third {
          position:absolute;
          width:inherit;
          display:block;
          top:auto;
          background-color:#28a745;
      }
      .fourth{
          position:relative;
          width:100%;
          left:360px;
          top:0px;
          background-color:#28a745;
    
      }
      .fifth{
        top:0px;
        left: 360px;
        position: relative;
        z-index: 2;

      }
      .table-fixed {
          width:100%;
          height:720px;
          overflow:scroll;  
      }
     
    </style>
    <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark"><?php echo e($ctdt->tenCT); ?><noscript></noscript><nav></nav></h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(asset('/quan-ly')); ?>">Home</a></li>
              <li class="breadcrumb-item "><a href="<?php echo e(asset('/quan-ly/thong-ke')); ?>">Statistics</a></li>
              <li class="breadcrumb-item active"><?php echo e($ctdt->tenCT); ?></li>
            
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">
                  Satisfy Level-3 Student Outcomes (SOs) of the program 
             
                </h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="" class="table table-bordered table-hover table-responsive table-striped">
                  
                  <thead>  
                <tr>
                  <th class="first" >No.</th>
                  <th class="second" >Course Name</th>
                  <?php
                      $tongmon_dapung=[];//biến lưu tổng theo cột CDR3
                    ?>
                  <?php $__currentLoopData = $ctdt_cdr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th class="fourth"> <?php echo e($x->maCDR3VB); ?> </th>
                        <?php
                        $tongmon_dapung[$x->maCDR3]=0;
                        ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <th class="fourth">Total</th>
                </tr>
                </thead>
                 
                 <tbody>
                    <?php
                      $i=1;
                      $tongcong=0;//biến lưu tổng của cột tổng
                    ?>
                    <?php $__currentLoopData = $hp_ctdt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th class="first" ><?php echo e($i++); ?> </th>
                            <th class="second"><?php echo e($y->tenHocPhan); ?></th>
                            <?php
                            $tongcdr_cuamon=0;
                            $ktra=0;//kiểm tra xem môn học có được nhập CDR3 chưa
                            ?>
                            <?php $__currentLoopData = $hp_cdr3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $z): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              
                              <?php if($y->maHocPhan==$z->maHocPhan ): ?>
                                <?php //Nếu học phần đang xét mà có trong bảng học phần-chuẩn đầu ra 3
                                $ktra=1; // môn học đã có chuẩn đầu ra
                                break;
                                ?>
                              <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($ktra==1): ?>
                              <?php $__currentLoopData = $ctdt_cdr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php //nếu học phần có đáp ứng chuẩn đầu ra thì kiểm tra xem đáp ứng CDR3 nào
                                $dapung=0;
                                
                                ?>
                                <?php $__currentLoopData = $hp_cdr3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $z): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php if($z->maCDR3==$x->maCDR3 && $y->maHocPhan==$z->maHocPhan): ?>
                                    <?php
                                    $dapung=1; // môn học đáp ứng chuẩn đầu ra 3 tương ứng với cột CDR3
                                    $tongcdr_cuamon++;
                                    $tongmon_dapung[$x->maCDR3]++;
                                    break;
                                    ?> 
                                  <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if($dapung==1): ?>
                                  <td class="fifth">x</td>
                                <?php else: ?>
                                  <td class="fifth">&nbsp;</td>
                                <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                            <?php else: ?>
                              <?php $__currentLoopData = $ctdt_cdr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <td class="fifth">&nbsp;</td>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                          <td class="fifth"><?php echo e($tongcdr_cuamon); ?></td>
                          <?php
                            $tongcong=$tongcong+$tongcdr_cuamon;
                          ?>  
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </tbody>
                  <tfoot>
                    <tr>
                      <td class="first">&nbsp;</td> 
                      <td class="second" align="center" ><font color="white"><b>Total</b></font></td>
                      <?php $__currentLoopData = $ctdt_cdr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <td class="fifth" bgcolor="#28a745"><font color="white"><b><?php echo e($tongmon_dapung[$x->maCDR3]); ?></b></font></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <td class="fifth" bgcolor="#28a745"><font color="yellow"><b><?php echo e($tongcong); ?></b></font></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
            <!-- STACKED BAR CHART -->
            <div class="card card-success">
                <div class="card-header">
                <h3 class="card-title">Chart</h3>

                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                    <i class="fas fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove">
                    <i class="fas fa-times"></i>
                    </button>
                </div>
                </div>
                <div class="card-body">
                <div class="chart">
                    <canvas id="barChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
                </div>
                </div>
                <!-- /.card-body -->
            </div>
            <!-- /.card -->
                    
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>


    
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abet/domains/abet.ktcn.tvu.edu.vn/public_html/resources/views/admin/thongke/thongkechuongtrinhCDR3.blade.php ENDPATH**/ ?>