<?php $__env->startSection('content'); ?>
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
              <div class="container-fluid">
                <div class="row mb-2">
                  <div class="col-sm-6">
                    <h1 class="m-0 text-dark">
                      <?php echo e(__('Assessment Planning')); ?><noscript></noscript>
                      <nav></nav>
                    </h1>
                  </div>
                  <!-- /.col -->
                  <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                      <li class="breadcrumb-item">
                        <a href="<?php echo e(asset('giang-vien')); ?>"><?php echo e(__('Home')); ?></a>
                      </li>
                      <li class="breadcrumb-item">
                        <a href="<?php echo e(asset('giang-vien/quy-hoach-danh-gia')); ?>">
                          <?php echo e($hp->tenHocPhan); ?></a>
                      </li>
    
                      <li class="breadcrumb-item active">
                        <?php echo e(__('Assessment Planning')); ?>

                      </li>
                    </ol>
                  </div>
                  <!-- /.col -->
                </div>
                <!-- /.row -->
              </div>
              <!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->
            <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <h5><i class="icon fas fa-check"></i> Thông báo!</h5>
              <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>
            <?php if(session('warning')): ?>
              <div class="alert alert-warning alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h5><i class="icon fas fa-exclamation-triangle"></i> Thông báo!</h5>
                <?php echo e(session('warning')); ?>

              </div>
            <?php endif; ?>
            <section class="content">
              <div class="container-fluid">
                <div class="row">
                  <div class="col-12">
                    <div class="card">
                      <div class="card-header">
                        <h3 class="card-title">
                        <?php if($count_ct==0): ?>
                          <form action="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/chon-nhom-cong-thuc')); ?>" method="post">
                          <?php echo csrf_field(); ?>   
                          <div class="form-group">
                                <label for="">Chọn nhóm công thức:</label>
                                <select name="groupCT" id="" class="form-control">
                                  <option value="1">
                                    <?php
                                        $n=$hocphan_loai_htdg_array->where('groupCT',1)->count();
                                        $cr=0;
                                    ?>
                                    <?php $__currentLoopData = $hocphan_loai_htdg_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <?php if($cr!=0 && $cr<$n && $data->groupCT==1): ?>
                                          +
                                          <?php
                                              $cr++;
                                          ?>
                                          <?php echo e($data->loaiHTDanhGia['maLoaiHTDG']); ?>*<?php echo e($data->trongSo); ?>%
                                      <?php elseif($data->groupCT==1): ?>
                                          <?php
                                              $cr++;
                                          ?>
                                          <?php echo e($data->loaiHTDanhGia['maLoaiHTDG']); ?>*<?php echo e($data->trongSo); ?>%
                                      <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </option>
                                 <?php
                                        $n=$hocphan_loai_htdg_array->where('groupCT',2)->count();
                                        $cr=0;
                                  ?>
                                  <?php if($n>0): ?>
                                  <option value="2" >
                                    <?php $__currentLoopData = $hocphan_loai_htdg_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <?php if($cr!=0 && $cr<$n && $data->groupCT==2): ?>
                                          +
                                          <?php
                                              $cr++;
                                          ?>
                                          <?php echo e($data->loaiHTDanhGia['maLoaiHTDG']); ?>*<?php echo e($data->trongSo); ?>%
                                      <?php elseif($data->groupCT==2): ?>
                                          <?php
                                              $cr++;
                                          ?>
                                          <?php echo e($data->loaiHTDanhGia['maLoaiHTDG']); ?>*<?php echo e($data->trongSo); ?>%
                                      <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </option>
                                  <?php endif; ?>
                                </select>
                              </div>
                              <button type="submit" class="btn btn-primary"  >
                                <i class="fas fa-plus"></i> <?php echo e(__('Choose')); ?>

                              </button>
                        <?php endif; ?>
                      </form>
                        </h3>
                      </div>
                      <!-- /.card-header -->
                      <div class="card-body">
                        <table id="example2" class="table table-bordered table-hover">
                          <thead>
                            <tr>
                              <th><?php echo e(__('No.')); ?></th>
                              <th><?php echo e(__('Assessment activity')); ?></th>
                              <th><?php echo e(__('Weight')); ?> (%)</th>
                              <th><?php echo e(__('Assessment methods')); ?></th>
                              <th><?php echo e(__('Option')); ?></th>
                            </tr>
                          </thead>
                          <tbody>
                              <?php
                                  $i=1;
                              ?>
                              <?php $__currentLoopData = $qh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td><?php echo e($i++); ?></td>
                                <td>
                                  <?php if(Session::has('language') && Session::get('language')=='en'): ?>
                                       <?php echo e($x->tenLoaiDG_EN); ?>

                                  <?php else: ?>
                                  <?php echo e($x->tenLoaiDG); ?>

                                  <?php endif; ?>
                                 </td>
                                <td><?php echo e($x->trongSo); ?>%</td>
                             
                                <td>
                                  <?php if(Session::has('language') && Session::get('language')=='en'): ?>
                                      <?php echo e($x->tenLoaiHTDG_EN); ?>

                                  <?php else: ?>
                                     <?php echo e($x->tenLoaiHTDG); ?>

                                  <?php endif; ?>
                                  
                                </td>
                                <td style='white-space: nowrap'>
                                  <a href="<?php echo e(asset('giang-vien/quy-hoach-danh-gia/noi-dung-quy-hoach/'.$x->maCTBaiQH)); ?>" class="btn btn-success">
                                    <i class="fas fa-align-justify"></i> <?php echo e(__('Planning Content')); ?>               
                                </a>
                                  <a href="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/noi-dung-danh-gia/xem-noi-dung-danh-gia/'.$x->maCTBaiQH)); ?>">
                                    <button class="btn btn-success">
                                      <i class="fas fa-info-circle"></i> <?php echo e(__('Assessment content')); ?>

                                    </button>
                                  </a>
                                  <button class="btn btn-primary">
                                    <i class="fas fa-edit"></i>
                                  </button>
                                </td>
                              </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                          <tfoot></tfoot>
                        </table>
                      </div>
                      <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                  </div>
                  <!-- /.col -->
                </div>
                <!-- /.row -->
              </div>
              <!-- /.container-fluid -->
            </section>
            <!-- /.content -->
          </div>
          <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('giangvien.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/giangvien/quyhoach/quyhoachketqua.blade.php ENDPATH**/ ?>