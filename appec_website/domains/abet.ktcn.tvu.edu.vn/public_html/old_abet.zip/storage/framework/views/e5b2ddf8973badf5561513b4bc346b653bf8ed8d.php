
<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">
                            <?php echo e(__('Assessment Planning')); ?><noscript></noscript>
                            <nav></nav>
                        </h1>
                    </div>
                    <!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(asset('/giang-vien')); ?>"><?php echo e(__('Home')); ?></a></li>
                            <li class="breadcrumb-item active">
                                <?php echo e(__('Assessment Planning')); ?>

                            </li>
                        </ol>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">
                                    <?php echo e(__('Semester')); ?>: <b><?php echo e(Session::get('maHK')); ?></b>  --  <?php echo e(__('Academic year')); ?>:  <b><?php echo e(Session::get('namHoc')); ?></b>
                                    
                                </h3>
                                <div class="card-tools">
                                    <a href="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia')); ?>" class="btn btn-success"><i
                                            class="fas fa-arrow-left"></i></a>
                                </div>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <table id="example2" class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th><?php echo e(__('No.')); ?></th>
                                            <th><?php echo e(__('Course name')); ?></th>
                                            <th><?php echo e(__('Class ID')); ?></th>
                                            <th><?php echo e(__('Option')); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $i = 1;
                                        ?>
                                        <?php $__currentLoopData = $gd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($i++); ?></td>
                                                <td>
                                                    <?php if(session::has('language') && session::get('language')=='en'): ?>
                                                    <?php echo e($item->tenHocPhanEN); ?>

                                                    <?php else: ?>
                                                    <?php echo e($item->tenHocPhan); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(asset('giang-vien/hoc-phan/xem-ds-sv/' . $item->maLop)); ?>">
                                                        <?php echo e($item->maLop); ?>

                                                    </a>
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(asset('giang-vien/quy-hoach-danh-gia/quy-hoach-ket-qua/' . $item->maHocPhan . '/' . $item->maBaiQH .'/'.$item->maHK.'/'.$item->namHoc. '/' . $item->maLop)); ?>"
                                                        class="btn btn-success">
                                                        <i class="fas fa-align-justify"></i>
                                                        <?php echo e(__('Assessment Planning')); ?>

                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot></tfoot>
                                </table>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('giangvien.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\XAMPP_SERVER\htdocs\abet_07-7-2021\resources\views/giangvien/quyhoach/quyhoach.blade.php ENDPATH**/ ?>