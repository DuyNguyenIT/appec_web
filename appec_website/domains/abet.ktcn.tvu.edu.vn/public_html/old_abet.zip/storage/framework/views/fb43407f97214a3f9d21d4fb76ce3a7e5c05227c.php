
<?php $__env->startSection('content'); ?>
          <!-- Content Wrapper. Contains page content -->
          <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
              <div class="container-fluid">
                <div class="row mb-2">
                  <div class="col-sm-6">
                    <h1 class="m-0 text-dark">
                      Đồ án<noscript></noscript>
                      <nav></nav>
                    </h1>
                  </div>
                  <!-- /.col -->
                  <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                      <li class="breadcrumb-item">
                        <a href="<?php echo e(asset('giang-vien')); ?>">Trang chủ</a>
                      </li>
                      <li class="breadcrumb-item">
                        <a href="<?php echo e(asset('giang-vien/ket-qua-danh-gia')); ?>"
                          ><?php echo e($hp->tenHocPhan); ?></a
                        >
                      </li>
                      <li class="breadcrumb-item active">Đồ án</li>
                    </ol>
                  </div>
                  <!-- /.col -->
                </div>
                <!-- /.row -->
              </div>
              <!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->
    
            <section class="content">
              <div class="container-fluid">
                <div class="row">
                  <div class="col-12">
                    <div class="card">
                      <div class="card-header">
                        <h4 class="">
                          <b>Cán bộ chấm 1:</b> <?php echo e($gv->hoGV); ?> <?php echo e($gv->tenGV); ?><br />
                          <b>Cán bộ chấm 2:</b> <?php echo e($gv2->hoGV); ?> <?php echo e($gv2->tenGV); ?><br />
                        </h4>
                      </div>
                      <!-- /.card-header -->
                      <div class="card-body">
                        <table  id="example2" class="table table-bordered table-hover">
                          <thead>
                            <tr>
                              <th>STT</th>
                              <th>Tên đề tài</th>
                              <th>Sinh viên thực hiện</th>
                              <th>Mã sinh viên</th>
                              <th>Điểm CB1</th>
                              <th>Điểm CB2</th>
                              <th>Tùy chọn</th>
                            </tr>
                          </thead>
                          <tbody>
                              <?php
                                  $i=1;
                                  $chayTenDT=0;
                                  $maDe_cur=0;
                              ?>
                                <?php $__currentLoopData = $deThi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    
                                    $demTenDT=$deThi->where('maDe',$dt->maDe)->count();
                                    if($chayTenDT>$demTenDT)
                                        $chayTenDT=1;
                                    else {
                                        $chayTenDT+=1;
                                    }
                                    if($maDe_cur!==$dt->maDe){
                                        $maDe_cur=$dt->maDe;
                                        $chayTenDT=1;
                                    }
                                ?>
                                    <?php if($chayTenDT==1): ?>
                                        <tr>
                                            <td rowspan=<?php echo e($demTenDT); ?>><?php echo e($i++); ?></td>
                                            <td rowspan=<?php echo e($demTenDT); ?>><?php echo e($dt->tenDe); ?></td>
                                            
                                            <td><?php echo e($dt->HoSV); ?> <?php echo e($dt->TenSV); ?></td>
                                            <td><?php echo e($dt->maSSV); ?></td>
                                            <?php if($dt->trangThai==false): ?>
                                                 <td>
                                                  <?php echo e($dt->diemSo); ?>

                                                </td>
                                                <td>
                                                  <?php echo e($dt->diemCB2); ?>

                                                </td>
                                                <td>
                                                <a href="<?php echo e(asset('/giang-vien/ket-qua-danh-gia/nhap-diem-do-an/'.$dt->maDe.'/'.$dt->maSSV)); ?>">
                                                    <button class="btn btn-primary">
                                                    <i class="fas fa-edit"></i> Chấm điểm
                                                    </button>
                                                </a>
                                                </td>
                                            <?php else: ?>
                                                <td><?php echo e($dt->diemSo); ?></td>
                                                <td><?php echo e($dt->diemCB2); ?></td>
                                                <td>
                                                  <a href="<?php echo e(asset('/giang-vien/ket-qua-danh-gia/xem-ket-qua-danh-gia/'.$dt->maDe.'/'.$dt->maSSV.'/1')); ?>">
                                                    <button class="btn btn-success">
                                                    <i class="fas fa-eye"></i> Xem kết quả cán bộ chấm 1
                                                    </button>
                                                </a>

                                                <a href="<?php echo e(asset('/giang-vien/ket-qua-danh-gia/xem-ket-qua-danh-gia/'.$dt->maDe.'/'.$dt->maSSV.'/2')); ?>">
                                                  <button class="btn btn-primary">
                                                  <i class="fas fa-eye"></i> Xem kết quả cán bộ chấm 2
                                                  </button>
                                              </a>
                                                </td>
                                            <?php endif; ?>
                                           
                                        </tr> 
                                    <?php else: ?>
                                        <tr>
                                            <td><?php echo e($dt->HoSV); ?> <?php echo e($dt->TenSV); ?></td>
                                            <td><?php echo e($dt->maSSV); ?></td>
                                            <?php if($dt->trangThai==false): ?>
                                                 <td>

                                                </td>
                                                <td>

                                                </td>
                                                <td>
                                                  <a href="<?php echo e(asset('/giang-vien/ket-qua-danh-gia/nhap-diem-do-an/'.$dt->maDe.'/'.$dt->maSSV)); ?>">
                                                      <button class="btn btn-primary">
                                                      <i class="fas fa-edit"></i> Chấm điểm
                                                      </button>
                                                  </a>
                                                </td>
                                            <?php else: ?>
                                                <td><?php echo e($dt->diemSo); ?></td>
                                                <td><?php echo e($dt->diemCB2); ?></td>

                                                <td>
                                                  <a href="<?php echo e(asset('/giang-vien/ket-qua-danh-gia/xem-ket-qua-danh-gia/'.$dt->maDe.'/'.$dt->maSSV.'/1')); ?>">
                                                      <button class="btn btn-success">
                                                      <i class="fas fa-eye"></i> Xem kết quả cán bộ chấm 1
                                                      </button>
                                                  </a>

                                                  <a href="<?php echo e(asset('/giang-vien/ket-qua-danh-gia/xem-ket-qua-danh-gia/'.$dt->maDe.'/'.$dt->maSSV.'/2')); ?>">
                                                    <button class="btn btn-primary">
                                                    <i class="fas fa-eye"></i> Xem kết quả cán bộ chấm 2
                                                    </button>
                                                </a>
                                                </td>
                                            <?php endif; ?>
                                        </tr>
                                    <?php endif; ?>
                                    
                               
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             
                            
                          </tbody>
                          <tfoot></tfoot>
                        </table>
                      </div>
                      <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                  </div>
                  <!-- /.col -->
                </div>
                <!-- /.row -->
              </div>
              <!-- /.container-fluid -->
            </section>
            <!-- /.content -->
          </div>
          <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('giangvien.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abet/domains/abet.ktcn.tvu.edu.vn/public_html/resources/views/giangvien/ketqua/ketquadoan.blade.php ENDPATH**/ ?>