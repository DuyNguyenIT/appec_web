<table>
                  
    <thead>  
      <tr>
        <th>No.</th>
        <th>Course Name</th>
        <?php $__currentLoopData = $chuan_abet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <th> <?php echo e($x->maChuanAbetVB); ?> </th>
              <?php
              $tongmon_dapung[$x->maChuanAbet]=0;
              ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <th>Total</th>
      </tr>
    </thead>
   
   <tbody>
      <?php
        $i=1;
        $tongcong=0;
      ?>
      <?php $__currentLoopData = $hp_ctdt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
          $tongabet_cuamon=0;
          ?>
          <tr>
              <td><?php echo e($i++); ?> </td>
              <td><?php echo e($y->tenHocPhan); ?></td>
               <?php $__currentLoopData = $chuan_abet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <td>
                  <?php $__currentLoopData = $hp_kqhthp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $z): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
                      <?php if($z->maHocPhan==$y->maHocPhan && $z->maChuanAbet==$x->maChuanAbet): ?>
                        <?php
                          $tongabet_cuamon++;
                          $tongmon_dapung[$x->maChuanAbet]++;
                        ?>
                          <?php echo e($z->maCDR3VB); ?> (<?php echo e($z->maKQHTVB); ?>), 
                      <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </td>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                <td><?php echo e($tongabet_cuamon); ?></td>
                <?php
                  $tongcong=$tongcong+$tongabet_cuamon;
                ?> 
          </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </tbody>
    <tfoot>
      <tr>
        <td></td>
        <td ><b>Total</b></td>
        <?php $__currentLoopData = $chuan_abet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <td ><b><?php echo e($tongmon_dapung[$x->maChuanAbet]); ?></b></td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <td ><b><?php echo e($tongcong); ?></b></td>
  
      </tr>
    </tfoot>
  </table><?php /**PATH D:\2_Co Nam\1_source code\source code 31-5\resources\views/admin/thongke/viewExportThongKeABET.blade.php ENDPATH**/ ?>