
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">
                        Thông tin học phần <noscript></noscript>
                        <nav></nav>
                    </h1>
                </div>
                <!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(asset('/quan-ly')); ?>"><?php echo e(__('Home')); ?></a></li>
                        <li class="breadcrumb-item active">Thông tin học phần</li>
                    </ol>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#bien_soan_de_cuong">
                                    <i class="fas fa-plus"></i> Biên soạn đề cương
                                </button>
                                <!-- Modal bien soan de cuong-->
                                <div class="modal fade" id="bien_soan_de_cuong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                    <form action="<?php echo e(asset('/quan-ly/bien-soan-va-phan-bien-de-cuong/xem-thong-tin-hoc-phan/them-bien-soan-de-cuong')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">Biên soạn đề cương</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="form-group">
                                                <label for=""><?php echo e(__('Lecture')); ?></label>
                                                <select name="maGV" id="" class="form-control">
                                                    <?php $__currentLoopData = $giangvien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($gv->maGV); ?>"><?php echo e($gv->maGV); ?>--<?php echo e($gv->hoGV); ?> <?php echo e($gv->tenGV); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                                        </div>
                                    </div>
                                    </form>
                                 
                                    </div>
                                </div>

                                
                                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#phan_bien_de_cuong">
                                    <i class="fas fa-plus"></i> Phản biện đề cương
                                </button>

                                <!-- Modal phan bien de cuong-->
                                <div class="modal fade" id="phan_bien_de_cuong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                    <form action="<?php echo e(asset('/quan-ly/bien-soan-va-phan-bien-de-cuong/xem-thong-tin-hoc-phan/them-phan-bien-de-cuong')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">Phản biện đề cương</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="form-group">
                                                <label for="maGV"><?php echo e(__('Lecture')); ?></label>
                                                <select name="maGV" id="" class="form-control">
                                                    <?php $__currentLoopData = $giangvien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($gv->maGV); ?>"><?php echo e($gv->maGV); ?>--<?php echo e($gv->hoGV); ?> <?php echo e($gv->tenGV); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                                        </div>
                                    </div>
                                    </form>
                                    </div>
                                </div>
                            </h3>
                            <div class="card-tools">
                                <a href="<?php echo e(asset('/quan-ly/bien-soan-va-phan-bien-de-cuong')); ?>" class="btn btn-secondary">
                                      <i class="fas fa-arrow-left"></i>
                                </a>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th><?php echo e(__('No.')); ?></th>
                                        <th><?php echo e(__('Course ID')); ?></th>
                                        <th><?php echo e(__('Course Name')); ?></th>
                                        <th><?php echo e(__('Total Credits')); ?></th>
                                        <th><?php echo e(__('Knowledge block')); ?></th>
                                        <th>Biên soạn đề cương</th>
                                        <th>Phản biện đề cương</th>
                                        <th><?php echo e(__('Curriculum')); ?></th>
                                        <th><?php echo e(__('Option')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $i = 1;
                                    ?>
                                    <?php $__currentLoopData = $hocphan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i++); ?></td>
                                            <td><?php echo e($hp->maHocPhan); ?></td>
                                            <td>
                                                <?php if(session::has('language') && session::get('language')=='vi'): ?>
                                                <?php echo e($hp->tenHocPhan); ?> -  (<?php echo e($hp->tenHocPhanEN); ?>)
                                                <?php else: ?>
                                                <?php echo e($hp->tenHocPhanEN); ?>

                                                <?php endif; ?>
                                                
                                            </td>
                                            <td><b><?php echo e($hp->tongSoTinChi); ?></b> (<?php echo e($hp->tinChiLyThuyet); ?> <?php echo e(__('Thoery')); ?> + <?php echo e($hp->tinChiThucHanh); ?> <?php echo e(__('Practice')); ?>)</td>
                                            <td>
                                                <?php if(session::has('language') && session::get('language')=='vi'): ?>
                                                    <?php echo e($hp->ctkhoi->tenCTKhoiKT); ?>

                                                <?php else: ?>
                                                    <?php echo e($hp->ctkhoi->tenCTKhoiKTEN); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php $__currentLoopData = $bienSoan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                     <li><b><?php echo e($bs->giang_vien->hoGV); ?> <?php echo e($bs->giang_vien->tenGV); ?></b></li>
                                                     <i>
                                                        (Từ: <?php echo e(\Carbon\Carbon::parse($bs->thoiGianBatDau)->format('d/m/Y h:m:s')); ?> đến: <?php echo e(\Carbon\Carbon::parse($bs->thoiGianKetThuc)->format('d/m/Y h:m:s')); ?>)
                                                     </i>
                                                     <a title="Delete" 
                                                    onclick="return confirm('Confirm?')"
                                                    href="<?php echo e(asset('/quan-ly/bien-soan-va-phan-bien-de-cuong/xem-thong-tin-hoc-phan/xoa-bien-soan-de-cuong/'.$bs->maGV)); ?>">
                                                 <i class="fa fa-trash"></i>
                                             </a>;
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td>
                                                <?php $__currentLoopData = $phanBien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><b><?php echo e($pb->giang_vien->hoGV); ?> <?php echo e($pb->giang_vien->tenGV); ?></b></li>
                                                <i>(Từ: <?php echo e(\Carbon\Carbon::parse($pb->thoiGianBatDau)->format('d/m/Y h:m:s')); ?> đến: <?php echo e(\Carbon\Carbon::parse($pb->thoiGianKetThuc)->format('d/m/Y h:m:s')); ?>)</i>
                                                     <a title="Delete" 
                                                    onclick="return confirm('Confirm?')"
                                                    href="<?php echo e(asset('/quan-ly/bien-soan-va-phan-bien-de-cuong/xem-thong-tin-hoc-phan/xoa-phan-bien-de-cuong/'.$pb->maGV)); ?>">
                                                 <i class="fa fa-trash"></i> 
                                             </a> ;
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td>
                                                <?php $__currentLoopData = $hp->hocphan_ctdt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($item->tenCT); ?>- <b>HK <?php echo e($item->phanPhoiHocKy); ?></b> ;
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <!-- Button trigger modal -->
                                                <button type="button" class="btn btn-primary" data-toggle="modal"
                                                    data-target="#add_CT_<?php echo e($hp->maHocPhan); ?>">
                                                    <i class="fas fa-plus"></i>
                                                </button>
                                                <a href="<?php echo e(asset('quan-ly/hoc-phan/hoc-phan-ct-dao-tao/' . $hp->maHocPhan)); ?>"
                                                    class="btn btn-primary">...</a>
                                                <!-- Modal -->
                                                <div class="modal fade" id="add_CT_<?php echo e($hp->maHocPhan); ?>"
                                                    tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                                                    aria-hidden="true">
                                                    <div class="modal-dialog" role="document">
                                                        <form
                                                            action="<?php echo e(asset('quan-ly/hoc-phan/them-hoc-phan-ctdt')); ?>"
                                                            method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title" id="exampleModalLabel">
                                                                        <?php echo e(__('Add')); ?></h5>
                                                                    <button type="button" class="close"
                                                                        data-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <input type="text" name="maHocPhan"
                                                                        value="<?php echo e($hp->maHocPhan); ?>" hidden>
                                                                    <div class="form-group">
                                                                        <label for=""><?php echo e(__('Curriculum')); ?></label>
                                                                        <select name="maCT" id="" class="form-control"
                                                                            required>
                                                                            <?php $__currentLoopData = $ctdt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <option value="<?php echo e($y->maCT); ?>">
                                                                                    <?php echo e($y->tenCT); ?></option>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for=""><?php echo e(__('Semester')); ?></label>
                                                                        <input type="number" min="1" max="8"
                                                                            name="phanPhoiHocKy" class="form-control"
                                                                            required>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for=""><?php echo e(__('Course Type')); ?></label>
                                                                        <select name="maLoaiHocPhan" id=""
                                                                            class="form-control" required>
                                                                            <?php $__currentLoopData = $loaihp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $z): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <option
                                                                                    value="<?php echo e($z->maLoaiHocPhan); ?>">
                                                                                    <?php echo e($z->tenLoaiHocPhan); ?></option>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="submit"
                                                                        class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                                                    <button type="button" class="btn btn-secondary"
                                                                        data-dismiss="modal"><?php echo e(__('Cancle')); ?></button>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </td>
                                            
                                            <td >
                                                <a href=" <?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/' . $hp->maHocPhan)); ?>"
                                                    class="btn btn-success">
                                                    <i class="fas fa-align-justify"></i> <?php echo e(__('Course Syllabus')); ?>

                                                </a>
                                                <button title="Edit" class="btn btn-success" data-toggle="modal"
                                                    data-target="#edit_<?php echo e($hp->maHocPhan); ?>">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <a title="Delete" class="btn btn-danger"
                                                    onclick="return confirm('Do you want to delete <?php echo e($hp->tenHocPhan); ?>?')"
                                                    href="<?php echo e(asset('quan-ly/hoc-phan/xoa/' . $hp->maHocPhan)); ?>"><i
                                                        class="fa fa-trash"></i></a>
                                                <!-- Modal -->
                                                <div class="modal fade" id="edit_<?php echo e($hp->maHocPhan); ?>" tabindex="-1"
                                                    role="dialog" aria-labelledby="exampleModalLabel"
                                                    aria-hidden="true">
                                                    <div class="modal-dialog" role="document">
                                                        <form action="<?php echo e(asset('quan-ly/hoc-phan/sua')); ?>"
                                                            method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title" id="exampleModalLabel">
                                                                        Editing Course Information</h5>
                                                                    <button type="button" class="close"
                                                                        data-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <input type="text" name="maHocPhan"
                                                                        value="<?php echo e($hp->maHocPhan); ?>"
                                                                        class="form-control" hidden>
                                                                    <div class="form-group">
                                                                        <label for=""><?php echo e(__('Course Name')); ?></label>
                                                                        <input type="text" name="tenHocPhan"
                                                                            class="form-control"
                                                                            value="<?php echo e($hp->tenHocPhan); ?>" required>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for=""><?php echo e(__('Course Name')); ?> EN</label>
                                                                        <input type="text" name="tenHocPhanEN"
                                                                            class="form-control"
                                                                            value="<?php echo e($hp->tenHocPhanEN); ?>" required>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label
                                                                            for=""><?php echo e(__('Number of Theory Credits')); ?></label>
                                                                        <input type="number" name="tinChiLyThuyet"
                                                                            class="form-control"
                                                                            value="<?php echo e($hp->tinChiLyThuyet); ?>"
                                                                            required>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label
                                                                            for=""><?php echo e(__('Number of Practice Credits')); ?></label>
                                                                        <input type="number" name="tinChiThucHanh"
                                                                            class="form-control"
                                                                            value="<?php echo e($hp->tinChiThucHanh); ?>"
                                                                            required>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label
                                                                            for=""><?php echo e(__('Knowledge block')); ?></label>
                                                                        <select name="maCTKhoiKT" id=""
                                                                            class="form-control" required>
                                                                            <?php $__currentLoopData = $ctkhoi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php if($hp->ctkhoi->maCTKhoiKT == $x->maCTKhoiKT): ?>
                                                                                    <option
                                                                                        value="<?php echo e($x->maCTKhoiKT); ?>"
                                                                                        selected><?php echo e($x->maCTKhoiKT); ?>

                                                                                        -
                                                                                        <?php echo e($x->tenCTKhoiKT); ?>

                                                                                    </option>
                                                                                <?php else: ?>
                                                                                    <option
                                                                                        value="<?php echo e($x->maCTKhoiKT); ?>">
                                                                                        <?php echo e($x->maCTKhoiKT); ?> -
                                                                                        <?php echo e($x->tenCTKhoiKT); ?>

                                                                                    </option>
                                                                                <?php endif; ?>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label
                                                                            for=""><?php echo e(__('Course Description')); ?></label>
                                                                        <textarea name="moTaHocPhan"
                                                                            class="form-control"><?php echo e($hp->moTaHocPhan); ?></textarea>
                                                                    </div>
                                                                </div>
                                                        </form>
                                                        <div class="modal-footer">
                                                            <button type="submit"
                                                                class="btn btn-primary">Update</button>
                                                            <button type="button" class="btn btn-secondary"
                                                                data-dismiss="modal">Cancel</button>
                                                        </div>
                                                    </div>
                                                </div>
                        </div>
                        </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                        <tfoot></tfoot>
                        </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/admin/ctdaotao/xemthongtinhocphan.blade.php ENDPATH**/ ?>