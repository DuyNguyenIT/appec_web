
<?php $__env->startSection('content'); ?>
<div class="content-wrapper" style="min-height: 22px;">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">
                        Biên soạn đề cương<noscript></noscript>
                        <nav></nav>
                    </h1>
                </div>
                <!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(asset('/quan-ly')); ?>"><?php echo e(__('Home')); ?></a></li>
                        <li class="breadcrumb-item active">Biên soạn đề cương</li>
                    </ol>
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                
                            </h3>
                           
                        </div>
                        <!-- /.card-header -->
                        <!-- PTTMai thêm đồng thời có xóa <div class="card-body"> trước đó của Duy-->
                        <div class="card-body">
                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th><?php echo e(__('No.')); ?></th>
                                        <th><?php echo e(__('Course ID')); ?></th>
                                        <th><?php echo e(__('Course Name')); ?></th>
                                        <th><?php echo e(__('Total Credits')); ?></th>
                                        <th><?php echo e(__('Knowledge block')); ?></th>
                                        <th><?php echo e(__('Curriculum')); ?></th>
                                        <th><?php echo e(__('Option')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $i = 1;
                                    ?>
                                    <?php $__currentLoopData = $hocphan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i++); ?></td>
                                            <td><?php echo e($hp->maHocPhan); ?></td>
                                            <td>
                                                <?php if(session::has('language') && session::get('language')=='vi'): ?>
                                                <?php echo e($hp->tenHocPhan); ?> - (<?php echo e($hp->tenHocPhanEN); ?>)
                                                <?php else: ?>
                                                <?php echo e($hp->tenHocPhanEN); ?>

                                                <?php endif; ?>
                                                
                                            </td>
                                            <td><b><?php echo e($hp->tongSoTinChi); ?></b> (<?php echo e($hp->tinChiLyThuyet); ?> <?php echo e(__('Thoery')); ?> + <?php echo e($hp->tinChiThucHanh); ?> <?php echo e(__('Practice')); ?>)</td>
                                            <td>
                                                <?php if(session::has('language') && session::get('language')=='vi'): ?>
                                                    <?php echo e($hp->ctkhoi->tenCTKhoiKT); ?>

                                                <?php else: ?>
                                                    <?php echo e($hp->ctkhoi->tenCTKhoiKTEN); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php $__currentLoopData = $hp->hocphan_ctdt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($item->tenCT); ?>- <b>HK <?php echo e($item->phanPhoiHocKy); ?></b> ;
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td style='white-space: nowrap'>
                                                
                                                <a href="<?php echo e(asset('/giang-vien/bien-soan-de-cuong/chinh-de-cuong/'.$hp->maHocPhan)); ?>" class="btn btn-success">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                    </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                        <tfoot></tfoot>
                        </table>
                    </div>
                    <!-- hết PTTMai thêm-->
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
        </div>
    <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('giangvien.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2_Co Nam\1_source code\source code 31-5\resources\views/giangvien/biensoandecuong/dshocphan.blade.php ENDPATH**/ ?>