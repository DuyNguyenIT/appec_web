<h4>Cán bộ chấm 1: <?php echo e($gv->hoGV); ?> <?php echo e($gv->tenGV); ?></h4>
<h4>Cán bộ chấm 2: <?php echo e($gv2->hoGV); ?> <?php echo e($gv2->tenGV); ?></h4>

<table >
    <thead>
        <tr>
            <th>STT</th>
            <th>Tên đề tài</th>
            <th>Sinh viên thực hiện</th>
            <th>Mã sinh viên</th>
            <th>Điểm CB1</th>
            <th>Điểm CB2</th>
        </tr>
    </thead>
    <tbody>
        <?php
            $i = 1;
            $chayTenDT = 0;
            $maDe_cur = 0;
        ?>
        <?php $__currentLoopData = $deThi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $demTenDT = $deThi->where('maDe', $dt->maDe)->count();
                if ($chayTenDT > $demTenDT) {
                    $chayTenDT = 1;
                } else {
                    $chayTenDT += 1;
                }
                if ($maDe_cur !== $dt->maDe) {
                    $maDe_cur = $dt->maDe;
                    $chayTenDT = 1;
                }
            ?>
            <?php if($chayTenDT == 1): ?>
                <tr>
                    <td rowspan=<?php echo e($demTenDT); ?>><?php echo e($i++); ?></td>
                    <td rowspan=<?php echo e($demTenDT); ?>><?php echo e($dt->tenDe); ?></td>
                    <td><?php echo e($dt->HoSV); ?> <?php echo e($dt->TenSV); ?></td>
                    <td><?php echo e($dt->maSSV); ?></td>
                    <?php if($dt->trangThai == false): ?>
                        <td>
                            <?php echo e($dt->diemSo); ?>

                        </td>
                        <td>
                            <?php echo e($dt->diemCB2); ?>

                        </td>
                    <?php else: ?>
                        <td><?php echo e($dt->diemSo); ?></td>
                        <td><?php echo e($dt->diemCB2); ?></td>
                    <?php endif; ?>
                </tr>
            <?php else: ?>
                <tr>
                    <td><?php echo e($dt->HoSV); ?> <?php echo e($dt->TenSV); ?></td>
                    <td><?php echo e($dt->maSSV); ?></td>
                    <?php if($dt->trangThai == false): ?>
                        <td>
                        </td>
                        <td>
                        </td>
                    <?php else: ?>
                        <td><?php echo e($dt->diemSo); ?></td>
                        <td><?php echo e($dt->diemCB2); ?></td>
                    <?php endif; ?>
                </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <tfoot></tfoot>
</table><?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/giangvien/ketqua/exportViewDoAn/exportDiemDoAn.blade.php ENDPATH**/ ?>