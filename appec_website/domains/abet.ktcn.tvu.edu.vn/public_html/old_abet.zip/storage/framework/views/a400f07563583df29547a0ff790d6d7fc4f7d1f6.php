<h5><b>7. Phương thức đánh giá </b></h5>
<!----------------------------------7. Phương thức đánh giá: --------------------------->
<!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addHocPhan_loaiHTDG">
    <i class="fas fa-edit"></i>
</button>
<!-- Modal thêm hình thức đánh giá -->
<div class="modal fade" id="addHocPhan_loaiHTDG" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/them_phuong_phap_danh_gia')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Cập nhật phương thức đánh giá</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="text" name="maHocPhan" value="<?php echo e($hocPhan->maHocPhan); ?>" hidden>
                    <div class="form-group">
                        <label for="">Chọn  hình thức đánh giá</label>
                        <select name="maLoaiDG" id="" class="form-control" required>
                            <?php $__currentLoopData = $loaiDG; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->maLoaiDG); ?>"><?php echo e($data->tenLoaiDG); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Chọn loại hình thức đánh giá</label>
                        <select name="maLoaiHTDG" id="" class="form-control" required>
                            <?php $__currentLoopData = $loaiHTDG; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->maLoaiHTDG); ?>"><?php echo e($data->tenLoaiHTDG); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                   
                    <div class="form-group">
                        <label for="">Tỉ lệ</label>
                        <input type="number" min="25" name="trongSo" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="">Group</label>
                        <select name="groupCT" id="" class="form-control">
                            <option value="1">1</option>
                            <option value="2">2</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Save</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </form>
    </div>
</div>
<table class="table table-bordered">
    <thead style="background-color: green">
        <th><?php echo e(__('No.')); ?></th>
        <th><?php echo e(__('Assessment activity')); ?></th>
        <th>Loại hình thức đánh giá</th>
        <th><?php echo e(__('Weight')); ?></th>
        <th><?php echo e(__('LOs assessed')); ?></th>
    </thead>
    <tbody>
        <?php
            $i = 1;
        ?>
        <?php $__currentLoopData = $hocPhan_loaiHTDG; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($i++); ?></td>
                <td>

                    <!-- nut sua -->
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#edit_<?php echo e($data->id); ?>">
                        <i class="fas fa-edit"></i>
                    </button>

                    <a title="Delete" class="btn btn-danger"
                        onclick="return confirm('Confirm?')"
                        href="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/xoa_phuong_phap_danh_gia/'.$data->id)); ?>">
                        <i class="fa fa-trash"></i>
                    </a>

                    <?php echo e($data->loai_danh_gia['tenLoaiDG']); ?>

                </td>
                <td><?php echo e($data->loaiHTDanhGia['maLoaiHTDG']); ?>-<?php echo e($data->loaiHTDanhGia['tenLoaiHTDG']); ?></td>
                <td><?php echo e($data->trongSo); ?>%</td>
                <td>
                    <!-- Button trigger modal -->
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#add_<?php echo e($data->id); ?>">
                        <i class="fas fa-plus"></i>
                    </button>
                    <?php if($data->hp_loaihtdg_kqht): ?>
                        <?php $__currentLoopData = $data->hp_loaihtdg_kqht; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($t->maKQHTVB); ?> <a title="Delete" class=""
                            onclick="return confirm('Confirm?')"
                            href="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/xoa_hocphan_loaihtdg_kqht/'.$t->id)); ?>">
                         <i class="fa fa-trash"></i>
                     </a>;
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                
                    <!-- Modal -->
                    <div class="modal fade" id="add_<?php echo e($data->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                        <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/them_hocphan_loaihtdg_kqht')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Add')); ?> <?php echo e(__('LOs assessed')); ?></h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                </div>
                                <input type="text" name="maHP_LHTDG" value="<?php echo e($data->id); ?>" hidden>
                                <div class="modal-body">
                                    <select name="maKQHT[]" class="form-control" multiple>
                                        <?php $__currentLoopData = $kqht; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($x->maKQHT); ?>"><?php echo e($x->maKQHTVB); ?> <?php echo e($x->tenKQHT); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
                                </div>
                            </div>
                        </form>
                        </div>
                    </div>
                </td>
            </tr>

              <!-- Modal -->
            <div class="modal fade" id="edit_<?php echo e($data->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/sua_phuong_phap_danh_gia')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-content">

                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Edit')); ?></h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>

                        <div class="modal-body">

                            <div class="form-group">
                                <label for="">Chọn  hình thức đánh giá</label>
                                <select name="maLoaiDG" class="form-control" required>
                                    <?php $__currentLoopData = $loaiDG; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ldg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if( $ldg->maLoaiDG==$data->maLoaiDG): ?>
                                            <option value="<?php echo e($ldg->maLoaiDG); ?>" selected><?php echo e($ldg->tenLoaiDG); ?></option> 
                                        <?php else: ?>
                                            <option value="<?php echo e($ldg->maLoaiDG); ?>"><?php echo e($ldg->tenLoaiDG); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <input type="text" name="id" value="<?php echo e($data->id); ?>" hidden>
                                <label for="">Chọn loại hình thức đánh giá</label>
                                <select name="maLoaiHTDG" id="" class="form-control" required>
                                    <?php $__currentLoopData = $loaiHTDG; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lhtdg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($lhtdg->maLoaiHTDG==$data->maLoaiHTDG): ?>
                                            <option value="<?php echo e($lhtdg->maLoaiHTDG); ?>" selected><?php echo e($lhtdg->tenLoaiHTDG); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($lhtdg->maLoaiHTDG); ?>"><?php echo e($lhtdg->tenLoaiHTDG); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="">Tỉ lệ</label>
                                <input type="number" min="25" name="trongSo" class="form-control" value="<?php echo e($data->trongSo); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="">Group</label>
                                <select name="groupCT" id="" class="form-control">
                                    <?php if($data->groupCT==1): ?>
                                        <option value="1" selected>1</option>
                                        <option value="2">2</option>
                                    <?php else: ?>
                                        <option value="1">1</option>
                                        <option value="2" selected>2</option>
                                    <?php endif; ?>
                                </select>
                            </div>

                        </div>

                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <tr>
        <td colspan="2">Ghi chú công thức tính điểm</td>
        <td colspan="3">
            <?php
                $n = $hocPhan_loaiHTDG->where('groupCT', 1)->count();
                $cr = 0;
            ?>
            <?php $__currentLoopData = $hocPhan_loaiHTDG; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($cr != 0 && $cr < $n && $data->groupCT == 1): ?>
                    +
                    <?php
                        $cr++;
                    ?>
                    <?php echo e($data->loaiHTDanhGia['maLoaiHTDG']); ?>*<?php echo e($data->trongSo); ?>%
                <?php elseif($data->groupCT==1): ?>
                    <?php
                        $cr++;
                    ?>
                    <?php echo e($data->loaiHTDanhGia['maLoaiHTDG']); ?>*<?php echo e($data->trongSo); ?>%
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <br> hoặc <br>
            
            <?php
                $n = $hocPhan_loaiHTDG->where('groupCT', 2)->count();
                $cr = 0;
            ?>
            <?php $__currentLoopData = $hocPhan_loaiHTDG; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($cr != 0 && $cr < $n && $data->groupCT == 2): ?>
                    +
                    <?php
                        $cr++;
                    ?>
                    <?php echo e($data->loaiHTDanhGia['maLoaiHTDG']); ?>*<?php echo e($data->trongSo); ?>%
                <?php elseif($data->groupCT==2): ?>
                    <?php
                        $cr++;
                    ?>
                    <?php echo e($data->loaiHTDanhGia['maLoaiHTDG']); ?>*<?php echo e($data->trongSo); ?>%
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
    </tr>
</table>
<?php /**PATH D:\2_Co Nam\1_source code\source code 31-5\resources\views/layouts/decuong/chitietnoidung/7_phuongthucdanhgia.blade.php ENDPATH**/ ?>