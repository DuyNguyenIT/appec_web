<table id="" class="table table-bordered table-hover">
    <thead>
        <tr>
            <th>STT</th>
            <th>Xếp loại</th>
            <th>Số lượng</th>
            <th>Tỉ lệ (%)</th>
            <th>Tỉ lệ tích lũy</th>
        </tr>
    </thead>
    <tbody>
        <?php
            $tongXepHang=0;
            $tongTiLe=0;
        ?>
        <?php for($i = 0; $i < count($xepHang); $i++): ?>
            <tr>
                <td><?php echo e($i + 1); ?></td>
                <td>
                    <?php switch($i+1):
                        case (1): ?>
                            Giỏi
                        <?php break; ?>
                        <?php case (2): ?>
                            Khá
                        <?php break; ?>
                        <?php case (3): ?>
                            Trung bình
                        <?php break; ?>
                        <?php case (4): ?>
                            Yếu
                        <?php break; ?>
                        <?php case (5): ?>
                            Kém
                        <?php break; ?>
                        <?php default: ?>
                    <?php endswitch; ?>
                </td>
                <td><?php echo e($xepHang[$i]); ?></td>
                <td><?php echo e($tiLe[$i]); ?>%</td>
                <td></td>
            </tr>
            <?php
                $tongXepHang+=$xepHang[$i];
                $tongTiLe+=$tiLe[$i];
            ?>
        <?php endfor; ?>
            <tr>
                <td colspan="2"><b>Tổng</b></td>
                <td>
                    <?php echo e($tongXepHang); ?>

                </td>
                <td>
                    <?php echo e($tongTiLe); ?>%
                </td>
                <td></td>
            </tr>
    </tbody>
    <tfoot>
    </tfoot>
</table><?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/layouts/thongke/thongke_xepHang.blade.php ENDPATH**/ ?>