
<?php $__env->startSection('content'); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">
                            <?php echo e(__('Dashboard')); ?><noscript></noscript>
                            <nav></nav>
                        </h1>
                    </div>
                    <!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#"><?php echo e(__('Home')); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo e(__('Dashboard')); ?></li>
                        </ol>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <!-- ------------cột 1--------------------- -->
                    <div class="col-lg-2 col-6">
                        <!-- small box -->
                        <div class="small-box bg-gradient-info">
                            <div class="inner">
                                <h5><?php echo e(__('Education level')); ?></h5>

                                <p><?php echo e($education_level); ?></p>
                            </div>
                            <div class="icon">
                                <i class="icon ion-document"></i>
                            </div>
                            <a href="<?php echo e(asset('quan-ly/bac-dao-tao')); ?>" class="small-box-footer"><?php echo e(__('Details')); ?> <i
                                    class="fas fa-arrow-circle-right"></i>
                            </a>
                        </div>
                    </div>
                    <!-- ---------------------------------------->
                    <!-- ----------------cột 2------------------ -->
                    <div class="col-lg-2 col-6">
                        <div class="small-box bg-gradient-success">
                            <div class="inner">
                                <h5><?php echo e(__('Majors')); ?></h5>

                                <p><?php echo e($majors); ?></p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-clipboard"></i>
                            </div>
                            <a href="<?php echo e(asset('quan-ly/nganh-hoc')); ?>" class="small-box-footer"><?php echo e(__('Details')); ?> <i
                                    class="fas fa-arrow-circle-right"></i>
                            </a>
                        </div>
                    </div>
                    <!------------------------------------------- -->
                    <!-- --------------------------cột 3---------------- -->
                    <div class="col-lg-2 col-6">
                        <div class="small-box bg-gradient-warning">
                            <div class="inner">
                                <h5><?php echo e(__('Specialized')); ?></h5>
                                <p><?php echo e($specialized); ?></p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-email"></i>
                            </div>
                            <a href="<?php echo e(asset('quan-ly/chuyen-nganh')); ?>"
                                class="small-box-footer"><?php echo e(__('Details')); ?><i class="fas fa-arrow-circle-right"></i>
                            </a>
                        </div>
                    </div>
                    <!--------------------------------------------------- -->
                    <!--------------------cột 4------------------------------ -->
                    <div class="col-lg-2 col-6">
                        <div class="small-box bg-gradient-orange">
                            <div class="inner">
                                <h5><?php echo e(__('Forms of training')); ?></h5>

                                <p><?php echo e($forms_of_planning); ?></p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-checkmark-round"></i>
                            </div>
                            <a href="<?php echo e(asset('quan-ly/he')); ?>" class="small-box-footer"><?php echo e(__('Details')); ?><i
                                    class="fas fa-arrow-circle-right"></i>
                            </a>
                        </div>
                    </div>
                    <!-- ---------------------------------------------------->
                    <!--------------------cột 5------------------------------ -->
                    <div class="col-lg-2 col-6">
                        <div class="small-box bg-gradient-maroon">
                            <div class="inner">
                                <h5><?php echo e(__('Curriculum')); ?></h5>

                                <p><?php echo e($curriculums); ?></p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-pie-graph"></i>
                            </div>
                            <a href="<?php echo e(asset('quan-ly/chuong-trinh-dao-tao')); ?>"
                                class="small-box-footer"><?php echo e(__('Details')); ?><i class="fas fa-arrow-circle-right"></i>
                            </a>
                        </div>
                    </div>
                    <!-- ---------------------------------------------------->
                    <!-- ---------------------cột 6------------------------ -->
                    <div class="col-lg-2 col-6">
                        <div class="small-box bg-gradient-olive">
                            <div class="inner">
                                <h5><?php echo e(__('LV1 Students outcomes')); ?></h5>

                                <p><?php echo e($lv1_students_outcomes); ?></p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-printer"></i>
                            </div>
                            <a href="<?php echo e(asset('quan-ly/chuan-dau-ra')); ?>"
                                class="small-box-footer"><?php echo e(__('Details')); ?><i class="fas fa-arrow-circle-right"></i>
                            </a>
                        </div>
                    </div>
                    <!-- ./col -->
                    <!-- ---------------------cột 7------------------------ -->
                    <div class="col-lg-2 col-6">
                        <div class="small-box bg-gradient-dark">
                            <div class="inner">
                                <h5><?php echo e(__('Course type')); ?></h5>

                                <p><?php echo e($course_type); ?></p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-printer"></i>
                            </div>
                            <a href="<?php echo e(asset('quan-ly/loai-hoc-phan')); ?>"
                                class="small-box-footer"><?php echo e(__('Details')); ?><i class="fas fa-arrow-circle-right"></i>
                            </a>
                        </div>
                    </div>
                    <!-- ./col -->
                    <!-- ---------------------cột 8------------------------ -->
                    <div class="col-lg-2 col-6">
                        <div class="small-box bg-cyan">
                            <div class="inner">
                                <h5><?php echo e(__('Course')); ?></h5>
                                <p><?php echo e($course); ?></p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-printer"></i>
                            </div>
                            <a href="<?php echo e(asset('quan-ly/loai-hoc-phan')); ?>" class="small-box-footer">
                                <?php echo e(__('Details')); ?><i class="fas fa-arrow-circle-right"></i>
                            </a>
                        </div>
                    </div>
                    <!-- ./col -->
                    <!-- ---------------------cột 9------------------------ -->
                    <div class="col-lg-2 col-6">
                        <div class="small-box bg-gradient-indigo">
                            <div class="inner">
                                <h5><?php echo e(__('Knowledge block')); ?></h5>

                                <p><?php echo e($knowledge_block); ?></p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-printer"></i>
                            </div>
                            <a href="<?php echo e(asset('quan-ly/khoi-kien-thuc')); ?>" class="small-box-footer">
                                <?php echo e(__('Details')); ?> <i class="fas fa-arrow-circle-right"></i> </a>
                        </div>
                    </div>
                    <!-- ./col -->
                    <!-- ---------------------cột 10------------------------ -->
                    <div class="col-lg-2 col-6">
                        <div class="small-box bg-gradient-teal">
                            <div class="inner">
                                <h5><?php echo e(__('Teaching methods')); ?></h5>
                                <p><?php echo e($teaching_method); ?></p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-printer"></i>
                            </div>
                            <a href="<?php echo e(asset('quan-ly/phuong-phap-giang-day')); ?>"
                                class="small-box-footer"><?php echo e(__('Details')); ?><i class="fas fa-arrow-circle-right"></i>
                            </a>
                        </div>
                    </div>
                    <!-- ./col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
            <!-- /.card -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/admin/home.blade.php ENDPATH**/ ?>