
<?php $__env->startSection('content'); ?>
   <!-- jQuery -->
   <script src="<?php echo e(asset('plugins/jquery/jquery.min.js')); ?>"></script>
   <!-- jQuery UI 1.11.4 -->
   <script src="<?php echo e(asset('plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>
   <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
   
     <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Phiếu đánh giá thực hành<noscript></noscript><nav></nav></h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(asset('giang-vien')); ?>">Trang chủ</a></li>
              <li class="breadcrumb-item "><a href="#">Tên môn</a></li>
              <li class="breadcrumb-item "><a href="#">Thực hành</a></li>
              <li class="breadcrumb-item active">Phiếu chấm</li>

            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->

      
    </div>
    <!-- /.content-header -->

    <section class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <!-- /.card -->
             
                <input type="text" name="maPhieuCham" hidden value=<?php echo e($gv->maPhieuCham); ?>>
                <div class="card">
                  <div class="card-header">
                    <h5 class="">
                        1. Giảng viên chấm: <?php echo e($gv->hoGV); ?> <?php echo e($gv->tenGV); ?> <br>
                        2. Chức danh: <br>
                        3. Đơn vị công tác: <br>
                        4. Đề thi: <?php echo e($dethi->tenDe); ?> <br>
                        5. Học và tên sinh viên: <?php echo e($sv->HoSV); ?> <?php echo e($sv->TenSV); ?> <br>
                    </h5>
                  </div>
                  <!-- /.card-header -->
                  <div class="card-body">
                      
                    <table id="example2" class="table table-bordered table-hover">
                      <thead>
                      <tr>
                        <th>STT</th>
                        <th>Câu hỏi</th>
                        <th>Phương án</th>
                        <th>Điểm chấm </th>
                      
                      </tr>
                    </thead>
                     <tbody>
                       <?php
                           $i=1;
                          $chayCauHoi=0;
                          $chayCDR_PATL=0;
                          $cauHoiHienTai=0;
                          $cdrHienTai=0;
                       ?>
                      
                       <?php $__currentLoopData = $noidung; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                          
  
                          if ($cdrHienTai!=$tc->maCDR3) { //kiểm tra nếu chuẩn đầu ra thay đổi thì chuyển biến chạy về 1
                            $cdrHienTai=$tc->maCDR3;
                            $chayCDR_PATL=1;
                          }
                          else {  //nếu không tăng biến chạy lên
                            $chayCDR_PATL+=1;
                          }
  
                          if ($cauHoiHienTai!=$tc->maCauHoi) {  //đặt kiểm tiêu chuẩn ở dưới vì khi khác tiêu chuẩn thì biến chayCDR phải trở về 1
                            $cauHoiHienTai=$tc->maCauHoi;
                            $chayCauHoi=1;
                            $chayCDR_PATL=1;
                          }
                          else {
                            $chayCauHoi+=1;
                          }
                         
                          $demTCDG=$noidung->groupBy("noiDungCauHoi")->count();
                          $demCDR_TCDG=$noidung->where('maCauHoi',$tc->maCauHoi)->groupBy("tenCDR3")->count();
                          $demPA_CauHoi=$noidung->where('maCauHoi',$tc->maCauHoi)->count('maPATL');
                          $diemCauHoi=$noidung->where('maCauHoi',$tc->maCauHoi)->sum('diemPA');
                          $demTC_CDR=$noidung->where('maPATL',$tc->maPATL)->where('maCDR3',$tc->maCDR3)->count('noiDungPA');
                          
                        ?> 
                      
                     
                       <?php if($chayCauHoi==1): ?>
                          <tr>
                            <td rowspan=<?php echo e($demPA_CauHoi); ?>><?php echo e($i++); ?></td>
                            <td rowspan=<?php echo e($demPA_CauHoi); ?>><?php echo $tc->noiDungCauHoi; ?> <b>( <?php echo e($diemCauHoi); ?>  điểm)</b></td>
                            <?php if($chayCDR_PATL==1): ?>
                             
                              <td><?php echo $tc->noiDungPA; ?> <b>(<?php echo e($tc->diemPA); ?> điểm)</b></td>
                              
                            <?php else: ?>
                              <td><?php echo $tc->noiDungPA; ?> <b>(<?php echo e($tc->diemPA); ?> điểm)</b></td>
                             
                            <?php endif; ?>
                            <td>
                                <?php echo e($tc->diemDG); ?> điểm
                              </td>
                          </tr>
                       <?php else: ?>
                          <tr>
                            
                            <?php if($chayCDR_PATL==1): ?>
                              
                              <td><?php echo $tc->noiDungPA; ?> <b>(<?php echo e($tc->diemPA); ?> điểm)</b></td>
                            <?php else: ?>
                              <td><?php echo $tc->noiDungPA; ?> <b>(<?php echo e($tc->diemPA); ?> điểm)</b></td>
                            <?php endif; ?>
                            <td>
                              <?php echo e($tc->diemDG); ?> điểm
                            </td>
                          </tr>
                       <?php endif; ?>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                    
                      <tfoot>
                     
                      </tfoot>
                    </table>
                    <hr>
                    <div class="form-group">
                      <h5><b>Ý kiến đóng góp:</b> <?php echo e($pc->yKienDongGop); ?></h5>
                    </div>
                  </div>
                  <!-- /.card-body --> 
                </div>
            </div>
            <!-- /.col -->
          </div>
          <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
      </section>
      <!-- /.content -->
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('giangvien.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abet/domains/abet.ktcn.tvu.edu.vn/public_html/resources/views/giangvien/ketqua/tuluan/xemketquachamtuluan.blade.php ENDPATH**/ ?>