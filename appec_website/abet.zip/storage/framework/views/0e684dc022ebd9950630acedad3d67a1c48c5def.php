
<?php $__env->startSection('content'); ?>
<div class="content-wrapper" style="min-height: 96px;">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0 text-dark">
            Items<noscript></noscript>
            <nav></nav>
          </h1>
        </div>
        <!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item">
              <a href="<?php echo e(asset('/giang-vien/hoc-phan')); ?>">
                <?php echo e(\Illuminate\Support\Str::limit(html_entity_decode($hocphan->tenHocPhan),$limit=20,$end='...')); ?>  
              </a>
            </li>
            <li class="breadcrumb-item ">
              <a href="<?php echo e(asset('/giang-vien/hoc-phan/chuong/'.Session::get('maHocPhan_chuong'))); ?>">
                <?php echo e(\Illuminate\Support\Str::limit(html_entity_decode($chuong->tenchuong),$limit=20,$end='...')); ?>  
              </a>
            </li>
            <li class="breadcrumb-item active">
              
              Item

             
            </li>
          </ol>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->
  
  <!-- Main content -->

  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title"></h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                  <tr>
                    <th>Order</th>
                    <th>Item name</th>
                    <th>Option</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                      $i=1;
                  ?>
                  <?php $__currentLoopData = $muc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($data->tenMuc); ?></td>
                    <td>
                      <a href="<?php echo e(asset('/giang-vien/hoc-phan/chuong/muc/cau-hoi-tu-luan/'.$data->id)); ?>" class="btn btn-primary">Câu hỏi tự luận</a>
                      <a href="<?php echo e(asset('/giang-vien/hoc-phan/chuong/muc/cau-hoi-trac-nghiem/'.$data->id)); ?>" class="btn btn-success">Câu hỏi trắc nghiệm</a>
                      <a href="<?php echo e(asset('/giang-vien/hoc-phan/chuong/muc/cau-hoi-thuc-hanh/'.$data->id)); ?>" class="btn btn-info">Câu hỏi thực hành</a>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                  
                  
                </tbody>
                <tfoot></tfoot>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('giangvien.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abet/domains/abet.ktcn.tvu.edu.vn/public_html/resources/views/giangvien/hocphan/chuong/muc/index.blade.php ENDPATH**/ ?>