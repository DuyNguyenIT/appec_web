<?php $__env->startSection('content'); ?>
<div class="content-wrapper" style="min-height: 22px;">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">
              Course Management<noscript></noscript>
              <nav></nav>
              
            </h1>
          </div>
          <!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(asset('/quan-ly')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Course</li>
            </ol>
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          <h5><i class="icon fas fa-check"></i> Message!</h5>
          <?php echo e(session('success')); ?>

        </div>
      <?php endif; ?>
      <?php if(session('warning')): ?>
        <div class="alert alert-warning alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
          <h5><i class="icon fas fa-exclamation-triangle"></i> Notification!</h5>
          <?php echo e(session('warning')); ?>

        </div>
      <?php endif; ?>
    <!-- Main content -->

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">
                  <!-- <a href="themhocphan.html">-->
                     <!-- <button type="button" class="btn btn-primary">
                        <i class="fas fa-plus"></i>-->
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                          <i class="fas fa-plus"></i>Add
                      </button>
                  <!-- </a>-->

                </h3>
                <!-- PTTMai thêm -->
                <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog modal-lg" role="document">
                    <form action="<?php echo e(asset('quan-ly/hoc-phan/them')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel">Adding a new course</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">
                          <div class="form-group">
                            <label for="">Course ID</label>
                            <input type="text" name="maHocPhan" class="form-control" required>
                          </div>
                          <div class="form-group">
                            <label for="">Course Name</label>
                            <input type="text" name="tenHocPhan" class="form-control" required>
                          </div>
                          <!-- <div class="form-group">
                            <label for="">Tổng tín chỉ</label>
                            <input type="number" name="tongSoTinChi" class="form-control">
                          </div>-->
                          <div class="form-group">
                            <label for="">Number of Theory Credits</label>
                            <input type="number" name="tinChiLyThuyet" class="form-control" required>
                          </div>
                          <div class="form-group">
                            <label for="">Number of Practice Credits</label>
                            <input type="number" name="tinChiThucHanh" class="form-control" required>
                          </div>
                          <div class="form-group">
                            <label for="">Knowledge block</label>
                            <select name="maCTKhoiKT" id="" class="form-control" required>
                              <?php $__currentLoopData = $ctkhoi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($x->maCTKhoiKT); ?>"><?php echo e($x->maCTKhoiKT); ?> - <?php echo e($x->tenCTKhoiKT); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </div>
                          <div class="form-group">
                            <label for="">Curriculum</label>
                            <select name="maCT" id="" class="form-control" required>
                              <?php $__currentLoopData = $ctdt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($y->maCT); ?>" > <?php echo e($y->tenCT); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </div>
                          <div class="form-group">
                            <label for="">Ph�n ph&#7889;i h&#7885;c k�</label>
                            <input type="number" min="1" max="4" name="phanPhoiHocKy" class="form-control"  required>
                          </div>
                          <div class="form-group">
                            <label for="">Course Type</label>
                            <select name="maLoaiHocPhan" id="" class="form-control" required>
                              <?php $__currentLoopData = $loaihp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $z): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($z->maLoaiHocPhan); ?>"> <?php echo e($z->tenLoaiHocPhan); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </div>
                          <div class="form-group">
                            <label for="">Course Description</label>
                            <textarea name="moTaHocPhan" class="form-control"></textarea>
                          </div>
                        </div>
                        <div class="modal-footer">
                          <button type="submit" class="btn btn-primary">Save</button>
                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        </div>
                      </div>
                  </form>
                    
                  </div>
                </div>
                <!-- hết PTTMai thêm -->
              </div>
              <!-- /.card-header -->
              <!-- PTTMai thêm đồng thời có xóa <div class="card-body"> trước đó của Duy-->
              <div class="card-body">
                <table id="example2" class="table table-bordered table-hover">
                  <thead>
                    <tr>
                      <th>No.</th>
                      <th>Course ID</th>
                      <th>Course Name</th>
                      <th>Total Credits</th>
                      <th>Number of Theory Credits</th>
                      <th>Number of Practice Credits</th>
                      <th>Knowledge block</th>
                      <th>Management Functions</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                        $i=1;
                    ?>
                    <?php $__currentLoopData = $hocphan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($i++); ?></td>
                          <td><?php echo e($hp->maHocPhan); ?></td>
                          <td><?php echo e($hp->tenHocPhan); ?></td>
                          <td><?php echo e($hp->tongSoTinChi); ?></td>
                          <td><?php echo e($hp->tinChiLyThuyet); ?></td>
                          <td><?php echo e($hp->tinChiThucHanh); ?></td>
                          <td><?php echo e($hp->ctkhoi->tenCTKhoiKT); ?></td>
                          <td style='white-space: nowrap'> 
                            <a href=" <?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/'.$hp->maHocPhan)); ?>" class="btn btn-success">
                              <i class="fas fa-align-justify"></i> Course Syllabus
                            </a>
  
                              <button title="Edit" class="btn btn-success" data-toggle="modal" data-target="#edit_<?php echo e($hp->maHocPhan); ?>">
                                <i class="fas fa-edit"></i> 
                              </button>
                            <a title="Delete" class="btn btn-danger" onclick="return confirm('Do you want to delete <?php echo e($hp->tenHocPhan); ?>?')" href="<?php echo e(asset('quan-ly/hoc-phan/xoa/'.$hp->maHocPhan)); ?>"><i class="fa fa-trash"></i></a>
                              <!-- Modal -->
                            <div class="modal fade" id="edit_<?php echo e($hp->maHocPhan); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                              <div class="modal-dialog" role="document">
                                <form action="<?php echo e(asset('quan-ly/hoc-phan/sua')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Editing Course Information</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                    </button>
                                  </div>
                                  <div class="modal-body">
                                    <input type="text" name="maHocPhan" value="<?php echo e($hp->maHocPhan); ?>" class="form-control" hidden>
                                    <div class="form-group">
                                      <label for="">Course Name</label>
                                      <input type="text" name="tenHocPhan" class="form-control" value="<?php echo e($hp->tenHocPhan); ?>" required>
                                    </div>
                                    <div class="form-group">
                                      <label for="">Number of Theory Credits</label>
                                      <input type="number" name="tinChiLyThuyet" class="form-control" value="<?php echo e($hp->tinChiLyThuyet); ?>" required>
                                    </div>
                                    <div class="form-group">
                                      <label for="">Number of Practice Credits</label>
                                      <input type="number" name="tinChiThucHanh" class="form-control" value="<?php echo e($hp->tinChiThucHanh); ?>" required>
                                    </div>
                                    <div class="form-group">
                                      <label for="">Knowledge block</label>
                                      <select name="maCTKhoiKT" id="" class="form-control" required>
                                        <?php $__currentLoopData = $ctkhoi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <?php if($hp->ctkhoi->maCTKhoiKT==$x->maCTKhoiKT): ?>
                                          <option value="<?php echo e($x->maCTKhoiKT); ?>" selected><?php echo e($x->maCTKhoiKT); ?> - <?php echo e($x->tenCTKhoiKT); ?></option>
                                          <?php else: ?>
                                          <option value="<?php echo e($x->maCTKhoiKT); ?>"><?php echo e($x->maCTKhoiKT); ?> - <?php echo e($x->tenCTKhoiKT); ?></option>
                                          <?php endif; ?>
                                          
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </select>
                                    </div>
                                    <div class="form-group">
                                      <label for="">Course Description</label>
                                      <textarea name="moTaHocPhan" class="form-control" ><?php echo e($hp->moTaHocPhan); ?></textarea>
                                    </div>
                                  </div>
                              </form>
                               
                              <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Update</button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                  </div>
                                </div>
                              </div>
                            </div>
                            
                          </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                    
                   
                  </tbody>
                  <tfoot></tfoot>
                </table>
              </div>
              <!-- hết PTTMai thêm-->

              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abet/domains/abet.ktcn.tvu.edu.vn/public_html/resources/views/admin/hocphan/hocphan.blade.php ENDPATH**/ ?>