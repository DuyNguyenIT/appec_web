
<?php $__env->startSection('content'); ?>
<div class="content-wrapper" style="min-height: 96px;">
        <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
              <div class="col-sm-6">
                <h1 class="m-0 text-dark">
                  Câu hỏi trắc nghiệm<noscript></noscript>
                  <nav></nav>
                </h1>
              </div>
              <!-- /.col -->
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                  <li class="breadcrumb-item"><a href="<?php echo e(asset('/')); ?>">Trang chủ</a></li>
                  <li class="breadcrumb-item">
                      Tên học phần
                  </li>
                  <li class="breadcrumb-item ">
                   
                Tên chương                      
                  </li><li class="breadcrumb-item"><a href="#">    
                  Tên mục
                 </li>
                  <li class="breadcrumb-item active">Câu hỏi trắc nghiệm</li>
                  <li class="breadcrumb-item active">Thêm CH trắc nghiệm</li>


                </ol>
              </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->
          </div>
          <!-- /.container-fluid -->

          <section class="content">
            <div class="container-fluid">
              <div class="row">
                <div class="col-12">
                  <div class="card">
                    <div class="card-header">

                    </div>

                    <div class="card-body">

                    </div>
                   </div>
                </div>
              </div>
            </div>
          </section>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('giangvien.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/giangvien/hocphan/chuong/muc/cauhoi/them_trac_nghiem.blade.php ENDPATH**/ ?>