
<?php $__env->startSection('content'); ?>
<script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
<div class="content-wrapper" style="min-height: 96px;">
        <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
              <div class="col-sm-6">
                <h1 class="m-0 text-dark">
                  <?php echo e(__('Edit')); ?> <?php echo e(__('Multiple choices question')); ?><noscript></noscript>
                  <nav></nav>
                </h1>
              </div>
              <!-- /.col -->
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                  <li class="breadcrumb-item"><a href="<?php echo e(asset('/giang-vien')); ?>"><?php echo e(__('Home')); ?></a></li>
                  <li class="breadcrumb-item">Tên học phần</li>
                  <li class="breadcrumb-item ">Tên chương</li>
                  <li class="breadcrumb-item"> Tên mục</li>
                  <li class="breadcrumb-item ">Câu hỏi trắc nghiệm</li>
                  <li class="breadcrumb-item active">Sửa CH trắc nghiệm</li>
                </ol>
              </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->
          </div>
          <!-- /.container-fluid -->

          <section class="content">
            <div class="container-fluid">
              <div class="row">
                <div class="col-12">
                  <div class="card">
                    <div class="card-header">
                      <h3 class="d-flex justify-content-between">
                        <?php echo e(__('Edit')); ?> <?php echo e(__('Multiple choices question')); ?>

                        <a href="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/noi-dung-danh-gia/ngan-hang-cau-hoi-trac-nghiem/'.Session::get('maMuc'))); ?>" class="btn btn-secondary"><i class="fas fa-arrow-left"></i></a>

                      </h3>
                    </div>
                    <div class="card-body">
                      <div class="custom-control custom-switch">
                        <input type="checkbox" class="custom-control-input" id="customSwitch1">
                        <label class="custom-control-label" for="customSwitch1">CKeditor</label>
                      </div>
                      <form action="<?php echo e(asset('giang-vien/quy-hoach-danh-gia/noi-dung-danh-gia/ngan-hang-cau-hoi-trac-nghiem/sua-cau-hoi-submit')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                        <div class="form-group">
                          <label for=""><?php echo e(__('Question content')); ?>:</label>
                          <input type="text" name="maCauHoi" value="<?php echo e($cauhoi->maCauHoi); ?>" hidden>
                          <textarea type="text" name="noiDungCauHoi" id="noiDungCauHoi" class="form-control"><?php echo e($cauhoi->noiDungCauHoi); ?></textarea>
                        </div>
                        <div class="form-group">
                          <label for="">Lựa chọn A</label>
                          <input type="text" name="maPhuongAn[]" value="<?php echo e($cauhoi->phuong_an_trac_nghiem[0]->id); ?>" hidden>
                          <textarea type="text" name="phuongAn[]" id="phuongAn1" class="form-control">
                            <?php echo e($cauhoi->phuong_an_trac_nghiem[0]->noiDungPA); ?>

                          </textarea>
                        </div>
                        <div class="form-group">
                          <label for="">Lựa chọn B</label>
                          <input type="text" name="maPhuongAn[]" value="<?php echo e($cauhoi->phuong_an_trac_nghiem[1]->id); ?>" hidden>
                          <textarea type="text" name="phuongAn[]" id="phuongAn2" class="form-control">
                            <?php echo e($cauhoi->phuong_an_trac_nghiem[1]->noiDungPA); ?>

                          </textarea>
                        </div>
                        <div class="form-group">
                          <label for="">Lựa chọn C</label>
                          <input type="text" name="maPhuongAn[]" value="<?php echo e($cauhoi->phuong_an_trac_nghiem[2]->id); ?>" hidden>
                          <textarea type="text" name="phuongAn[]" id="phuongAn3" class="form-control">
                            <?php echo e($cauhoi->phuong_an_trac_nghiem[2]->noiDungPA); ?>

                          </textarea>
                        </div>
                        <div class="form-group">
                          <label for="">Lựa chọn D</label>
                          <input type="text" name="maPhuongAn[]" value="<?php echo e($cauhoi->phuong_an_trac_nghiem[3]->id); ?>" hidden>
                          <textarea type="text" name="phuongAn[]" id="phuongAn4" class="form-control">
                            <?php echo e($cauhoi->phuong_an_trac_nghiem[3]->noiDungPA); ?>

                          </textarea>
                        </div>
                        <div class="form-group">
                            <label for=""><?php echo e(__('Answer')); ?></label><br>
                            <?php
                                $leter=['A','B','C','D']
                            ?>
                            <?php for($i = 0; $i < count($cauhoi->phuong_an_trac_nghiem); $i++): ?>
                                <?php echo e($leter[$i]); ?>

                                <?php if($cauhoi->phuong_an_trac_nghiem[$i]->isCorrect==1): ?>
                                    <input type="radio" name="choice" value="<?php echo e($i); ?>" checked>
                                <?php else: ?>
                                    <input type="radio" name="choice" value="<?php echo e($i); ?>">
                                <?php endif; ?>
                            <?php endfor; ?>
                        </div>
                        <div class="form-group">
                          <label for=""><?php echo e(__('Studying results')); ?>:</label>
                          <select name="maKQHT" id="" class="form-control">
                            <?php $__currentLoopData = $kqht; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($data->maKQHT==$cauhoi->maKQHT): ?>
                                    <option value="<?php echo e($data->maKQHT); ?>" selected><?php echo e($data->maKQHTVB); ?>--<?php echo e($data->tenKQHT); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($data->maKQHT); ?>"><?php echo e($data->maKQHTVB); ?>--<?php echo e($data->tenKQHT); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                        <div class="form-group">
                          <label for=""><?php echo e(__('Students outcomes')); ?> 3 (CDIOs):</label>
                          <select name="maCDR3" id="" class="form-control">
                            <?php $__currentLoopData = $cdr3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($cauhoi->phuong_an_trac_nghiem[0]->maCDR3==$data->maCDR3): ?>
                                    <option value="<?php echo e($data->maCDR3); ?>" selected><?php echo e($data->maCDR3VB); ?> - <?php echo e($data->tenCDR3); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($data->maCDR3); ?>"><?php echo e($data->maCDR3VB); ?> - <?php echo e($data->tenCDR3); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                        <div class="form-group">
                          <label for="">Abet:</label>
                          <select name="maChuanAbet" id="" class="form-control">
                            <?php $__currentLoopData = $abet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($cauhoi->phuong_an_trac_nghiem[0]->maChuanAbet==$data->maChuanAbet): ?>
                                    <option value="<?php echo e($data->maChuanAbet); ?>" selected><?php echo e($data->maChuanAbetVB); ?> - <?php echo e($data->tenChuanAbet); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($data->maChuanAbet); ?>"><?php echo e($data->maChuanAbetVB); ?> - <?php echo e($data->tenChuanAbet); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>

                        <div class="form-group">
                          <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                          <button type="reset" class="btn btn-info"><?php echo e(__('Reset')); ?></button>
                        </div>
                      </form>
                    </div>
                   </div>
                </div>
              </div>
            </div>
          </section>

    </div>
</div>
<script>
  $("#customSwitch1").change(function() {
    if(this.checked) {
      CKEDITOR.replace( 'noiDungCauHoi', {
        filebrowserUploadUrl: "<?php echo e(route('upload', ['_token' => csrf_token() ])); ?>",
        filebrowserUploadMethod: 'form'
      } );
      for (let index = 1; index <= 4; index++) {
        var name="phuongAn"+index;
        CKEDITOR.replace( name, {
          filebrowserUploadUrl: "<?php echo e(route('upload', ['_token' => csrf_token() ])); ?>",
          filebrowserUploadMethod: 'form'
        } );
      }
    }
    else{
      if(CKEDITOR.instances["noiDungCauHoi"]){
         CKEDITOR.instances["noiDungCauHoi"].destroy();
      }
      for (let index = 1; index <= 4; index++) {
        var name="phuongAn"+index;
        console.log(name);
        if(CKEDITOR.instances[name]){
          CKEDITOR.instances[name].destroy();
        }
      }
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('giangvien.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/giangvien/quyhoach/cauhoitracnghiem/sua_trac_nghiem.blade.php ENDPATH**/ ?>