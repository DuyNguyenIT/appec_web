
<?php $__env->startSection('content'); ?>
<script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
<div class="content-wrapper" style="min-height: 96px;">

    <!-- Content Header (Page header) -->
<div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0 text-dark">
            Câu hỏi trắc nghiệm<noscript></noscript>
            <nav></nav>
          </h1>
        </div>
        <!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(asset('/')); ?>">Trang chủ</a></li>
            <li class="breadcrumb-item">
              <a href="<?php echo e(asset('/giang-vien/hoc-phan')); ?>">
                <?php echo e(\Illuminate\Support\Str::limit(html_entity_decode($hocphan->tenHocPhan),$limit=20,$end='...')); ?>  
              </a>
            </li>
            <li class="breadcrumb-item ">
              <a href="<?php echo e(asset('/giang-vien/hoc-phan/chuong/'.Session::get('maHocPhan_chuong'))); ?>">
                <?php echo e(\Illuminate\Support\Str::limit(html_entity_decode($chuong->tenchuong),$limit=20,$end='...')); ?>  
              </a>
            </li><li class="breadcrumb-item"><a href="#">    
              <a href="<?php echo e(asset('/giang-vien/hoc-phan/chuong/muc/'.Session::get('maMuc'))); ?>">
              <?php echo e(\Illuminate\Support\Str::limit(html_entity_decode($muc->tenMuc),$limit=20,$end='...')); ?>  
            </a></a></li>
            <li class="breadcrumb-item active">Câu hỏi trắc nghiệm</li>
          </ol>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->
   <!-- Main content -->

   <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addCHTN">
                  <i class="fas fa-plus"></i>
                </button>

                <!-- Modal -->
                <div class="modal fade" id="addCHTN" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog modal-lg" role="document">
                    <form action="<?php echo e(asset('/giang-vien/hoc-phan/chuong/muc/cau-hoi-trac-nghiem/them')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Adding a new multiple choice question</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <div class="form-group">
                          <label for="">Adding content of multiple choice question:</label>
                          <textarea name="noiDungCauHoi" id="ndch" cols="30" rows="10" class="form-control" required></textarea>
                          <script>
                            CKEDITOR.replace( 'ndch', {
                                filebrowserUploadUrl: "<?php echo e(route('uploadgv', ['_token' => csrf_token() ])); ?>",
                                filebrowserUploadMethod: 'form'
                            } );
                        </script>
                        </div>
                        <div class="form-group">
                          <div class="row">
                            <div class="col-md-10">
                              <label for="">Adding a new answer contents (A):</label>
                              <textarea name="phuongAn[]" id="pa1" cols="30" rows="10" class="form-control" required></textarea>
                              <script>
                                CKEDITOR.replace( 'pa1', {
                                    filebrowserUploadUrl: "<?php echo e(route('uploadgv', ['_token' => csrf_token() ])); ?>",
                                    filebrowserUploadMethod: 'form'
                                } );
                            </script>
                            </div>
                            <div class="col-md-2">
                              <label for="">Check if correct answer </label>
                              <input type="radio" name="choice" class="form-control" value="0" checked>
                              <label for="">Point</label>
                              <input type="text" name="diemPA[]" class="form-control" required>
                            </div>
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="row">
                            <div class="col-md-10">
                              <label for="">Adding a new answer contents (B):</label>
                              <textarea name="phuongAn[]" id="pa2" cols="30" rows="10" class="form-control" required></textarea>
                              <script>
                                CKEDITOR.replace( 'pa2', {
                                    filebrowserUploadUrl: "<?php echo e(route('uploadgv', ['_token' => csrf_token() ])); ?>",
                                    filebrowserUploadMethod: 'form'
                                } );
                            </script>
                            </div>
                            <div class="col-md-2">
                              <label for="">Check if correct answer</label>
                              <input type="radio" name="choice" class="form-control" value="1">
                              <label for="">Point</label>
                              <input type="text" name="diemPA[]" class="form-control" required>
                            </div>
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="row">
                            <div class="col-md-10">
                              <label for="">Adding a new answer contents (C):</label>
                              <textarea name="phuongAn[]" id="pa3" cols="30" rows="10" class="form-control" required></textarea>
                              <script>
                                CKEDITOR.replace( 'pa3', {
                                    filebrowserUploadUrl: "<?php echo e(route('uploadgv', ['_token' => csrf_token() ])); ?>",
                                    filebrowserUploadMethod: 'form'
                                } );
                            </script>
                            </div>
                            <div class="col-md-2">
                              <label for="">Check if correct answer</label>
                              <input type="radio" name="choice" class="form-control" value="2">
                              <label for="">Point</label>
                              <input type="text" name="diemPA[]" class="form-control" required>
                            </div>
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="row">
                            <div class="col-md-10">
                              <label for="">Adding a new answer contents (D):</label>
                              <textarea name="phuongAn[]" id="pa4" cols="30" rows="10" class="form-control" required></textarea>
                              <script>
                                CKEDITOR.replace( 'pa4', {
                                    filebrowserUploadUrl: "<?php echo e(route('uploadgv', ['_token' => csrf_token() ])); ?>",
                                    filebrowserUploadMethod: 'form'
                                } );
                            </script>
                            </div>
                            <div class="col-md-2">
                              <label for="">Check if correct answer</label>
                              <input type="radio" name="choice" class="form-control" value="3">
                              <label for="">Point</label>
                              <input type="text" name="diemPA[]" class="form-control" required>
                            </div>
                          </div>
                        </div>
                        <div class="form-group">
                          <label for="">Chuẩn đầu ra 3:</label>
                          <select name="maCDR3" id="" class="form-control">
                            <?php $__currentLoopData = $cdr3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->maCDR3); ?>"><?php echo e($data->maCDR3VB); ?> - <?php echo e($data->tenCDR3); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                        <div class="form-group">
                          <label for="">Kết quả học tập:</label>
                          <select name="maKQHT" id="" class="form-control">
                            <?php $__currentLoopData = $kqht; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->maKQHT); ?>"><?php echo e($data->tenKQHT); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                      </div>
                    </div>
                    </form>
                    
                  </div>
                </div>
              </h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                  <tr>
                    <th>Order</th>
                    <th>Question content</th>
                    <th>Option</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                      $index=1;
                  ?>
                <?php $__currentLoopData = $cauHoi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($index++); ?></td>
                      <td>
                        <?php
                            $letter=['A','B','C','D'];
                        ?>
                        <?php echo $data->noiDungCauHoi; ?>

                        <div class="row">
                           <?php for($i = 0; $i < count($data->phuong_an_trac_nghiem); $i++): ?>
                              <?php if($data->phuong_an_trac_nghiem[$i]->isCorrect==true): ?>
                                <div class="col-md-1"> <?php echo e($letter[$i]); ?>. </div>
                                <div class="col-md-11"> <b><?php echo $data->phuong_an_trac_nghiem[$i]->noiDungPA; ?></b></div>
                              <?php else: ?>
                                <div class="col-md-1"> <?php echo e($letter[$i]); ?>. </div>
                                <div class="col-md-11"> <?php echo $data->phuong_an_trac_nghiem[$i]->noiDungPA; ?>   </div>
                              
                              <?php endif; ?>
                            
                            <?php endfor; ?>  
                        </div>
                      
                       
                      </td>
                      <td>
                          <!-- Button trigger modal -->
                          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#editCHTN_<?php echo e($data->maCauHoi); ?>">
                            <i class="fas fa-edit"></i>
                          </button>

                              <!-- Modal -->
                              <div class="modal fade" id="editCHTN_<?php echo e($data->maCauHoi); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-lg" role="document">
                                  <form action="<?php echo e(asset('/giang-vien/hoc-phan/chuong/muc/cau-hoi-trac-nghiem/sua')); ?>" method="post">
                                  <?php echo csrf_field(); ?>
                                  <input type="text" name="maCauHoi" value="<?php echo e($data->maCauHoi); ?>">
                                  <div class="modal-content">
                                    <div class="modal-header">
                                      
                                      <h5 class="modal-title" id="exampleModalLabel">Editing a multiple choice question</h5>
                                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                      </button>
                                    </div>
                                    <div class="modal-body">
                                      <div class="form-group">
                                        <label for="">Editing content of multiple choice question:</label>
                                        <textarea name="noiDungCauHoi" id="edit_ndch_<?php echo e($data->maCauHoi); ?>" cols="30" rows="10" class="form-control" required>
                                            <?php echo e($data->noiDungCauHoi); ?>

                                        </textarea>
                                        <script>
                                          CKEDITOR.replace( 'edit_ndch_<?php echo e($data->maCauHoi); ?>', {
                                              filebrowserUploadUrl: "<?php echo e(route('uploadgv', ['_token' => csrf_token() ])); ?>",
                                              filebrowserUploadMethod: 'form'
                                          } );
                                      </script>
                                      </div>
                                      
                                      <div class="form-group">
                                        <input type="text" name="maPhuongAn[]"  value="<?php echo e($data->phuong_an_trac_nghiem[0]->id); ?>" hidden>
                                        <div class="row">
                                          <div class="col-md-10">
                                            <label for="">Adding a new answer contents (A):</label>
                                            <textarea name="phuongAn[]" id="pa1_<?php echo e($data->maCauHoi); ?>" cols="30" rows="10" class="form-control" required>
                                              <?php echo e($data->phuong_an_trac_nghiem[0]->noiDungPA); ?>

                                            </textarea>
                                            <script>
                                              CKEDITOR.replace( 'pa1_<?php echo e($data->maCauHoi); ?>', {
                                                  filebrowserUploadUrl: "<?php echo e(route('uploadgv', ['_token' => csrf_token() ])); ?>",
                                                  filebrowserUploadMethod: 'form'
                                              } );
                                          </script>
                                          </div>
                                          <div class="col-md-2">
                                            <label for="">Check if correct answer </label>
                                            <?php if($data->phuong_an_trac_nghiem[0]->isCorrect==true ): ?>
                                            <input type="radio" name="choice" class="form-control" value="0" checked>
                                            <?php else: ?>
                                            <input type="radio" name="choice" class="form-control" value="0">
                                            <?php endif; ?>
                                            <label for="">Point</label>
                                            <input type="text" name="diemPA[]" class="form-control" required value="<?php echo e($data->phuong_an_trac_nghiem[0]->diemPA); ?>">
                                          </div>
                                        </div>
                                      </div>
                                      
                                      <div class="form-group">
                                        <input type="text" name="maPhuongAn[]"  value="<?php echo e($data->phuong_an_trac_nghiem[1]->id); ?>" hidden>
                                        <div class="row">
                                          <div class="col-md-10">
                                            <label for="">Adding a new answer contents (B):</label>
                                            <textarea name="phuongAn[]" id="pa2_<?php echo e($data->maCauHoi); ?>" cols="30" rows="10" class="form-control" required>
                                              <?php echo e($data->phuong_an_trac_nghiem[1]->noiDungPA); ?>

                                            </textarea>
                                            <script>
                                              CKEDITOR.replace( 'pa2_<?php echo e($data->maCauHoi); ?>', {
                                                  filebrowserUploadUrl: "<?php echo e(route('uploadgv', ['_token' => csrf_token() ])); ?>",
                                                  filebrowserUploadMethod: 'form'
                                              } );
                                          </script>
                                          </div>
                                          <div class="col-md-2">
                                            <label for="">Check if correct answer</label>
                                            <?php if($data->phuong_an_trac_nghiem[1]->isCorrect==true ): ?>
                                            <input type="radio" name="choice" class="form-control" value="1" checked>
                                            <?php else: ?>
                                            <input type="radio" name="choice" class="form-control" value="1">
                                            <?php endif; ?>
                                            <label for="">Point</label>
                                            <input type="text" name="diemPA[]" class="form-control" required value="<?php echo e($data->phuong_an_trac_nghiem[1]->diemPA); ?>">
                                          </div>
                                        </div>
                                      </div>
                                      
                                      <div class="form-group">
                                        <input type="text" name="maPhuongAn[]"  value="<?php echo e($data->phuong_an_trac_nghiem[2]->id); ?>" hidden>
                                        <div class="row">
                                          <div class="col-md-10">
                                            <label for="">Adding a new answer contents (C):</label>
                                            <textarea name="phuongAn[]" id="pa3_<?php echo e($data->maCauHoi); ?>" cols="30" rows="10" class="form-control" required>
                                              <?php echo e($data->phuong_an_trac_nghiem[2]->noiDungPA); ?>

                                            </textarea>
                                            <script>
                                              CKEDITOR.replace( 'pa3_<?php echo e($data->maCauHoi); ?>', {
                                                  filebrowserUploadUrl: "<?php echo e(route('uploadgv', ['_token' => csrf_token() ])); ?>",
                                                  filebrowserUploadMethod: 'form'
                                              } );
                                          </script>
                                          </div>
                                          <div class="col-md-2">
                                            <label for="">Check if correct answer</label>
                                            <?php if($data->phuong_an_trac_nghiem[2]->isCorrect==true ): ?>
                                            <input type="radio" name="choice" class="form-control" value="2" checked>
                                            <?php else: ?>
                                            <input type="radio" name="choice" class="form-control" value="2">
                                            <?php endif; ?>
                                            <label for="">Point</label>
                                            <input type="text" name="diemPA[]" class="form-control" required value="<?php echo e($data->phuong_an_trac_nghiem[2]->diemPA); ?>">
                                          </div>
                                        </div>
                                      </div>
                                      
                                      <div class="form-group">
                                        <input type="text" name="maPhuongAn[]"  value="<?php echo e($data->phuong_an_trac_nghiem[3]->id); ?>" hidden>
                                        <div class="row">
                                          <div class="col-md-10">
                                            <label for="">Adding a new answer contents (D):</label>
                                            <textarea name="phuongAn[]" id="pa4_<?php echo e($data->maCauHoi); ?>" cols="30" rows="10" class="form-control" required>
                                              <?php echo e($data->phuong_an_trac_nghiem[3]->noiDungPA); ?>

                                            </textarea>
                                            <script>
                                              CKEDITOR.replace( 'pa4_<?php echo e($data->maCauHoi); ?>', {
                                                  filebrowserUploadUrl: "<?php echo e(route('uploadgv', ['_token' => csrf_token() ])); ?>",
                                                  filebrowserUploadMethod: 'form'
                                              } );
                                          </script>
                                          </div>
                                          <div class="col-md-2">
                                            <label for="">Check if correct answer</label>
                                            <?php if($data->phuong_an_trac_nghiem[3]->isCorrect==true ): ?>
                                            <input type="radio" name="choice" class="form-control" value="3" checked>
                                            <?php else: ?>
                                            <input type="radio" name="choice" class="form-control" value="3">
                                            <?php endif; ?>
                                            
                                            <label for="">Point</label>
                                            <input type="text" name="diemPA[]" class="form-control" required value="<?php echo e($data->phuong_an_trac_nghiem[3]->diemPA); ?>">
                                          </div>
                                        </div>
                                      </div>
                                      
                                      <div class="form-group">
                                        <label for="">Chuẩn đầu ra 3:</label>
                                        <select name="maCDR3" id="" class="form-control">
                                          <?php $__currentLoopData = $cdr3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <?php if($data->maCDR3==$x->maCDR3): ?>
                                              <option value="<?php echo e($x->maCDR3); ?>" selected><?php echo e($x->maCDR3VB); ?> - <?php echo e($x->tenCDR3); ?></option>
                                                  
                                              <?php else: ?>
                                              <option value="<?php echo e($x->maCDR3); ?>"><?php echo e($x->maCDR3VB); ?> - <?php echo e($x->tenCDR3); ?></option>
                                                  
                                              <?php endif; ?>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                      </div>
                                      
                                      <div class="form-group">
                                        <label for="">Kết quả học tập:</label>
                                        <select name="maKQHT" id="" class="form-control">
                                          <?php $__currentLoopData = $kqht; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($data->maKQHT==$x->maKQHT): ?>
                                              <option value="<?php echo e($x->maKQHT); ?>" selected><?php echo e($x->tenKQHT); ?></option>
                                                
                                            <?php else: ?>
                                              <option value="<?php echo e($x->maKQHT); ?>"><?php echo e($x->tenKQHT); ?></option>
                                                
                                            <?php endif; ?>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                      </div>
                                    </div>
                                    <div class="modal-footer">
                                      <button type="submit" class="btn btn-primary">Save</button>
                                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                    </div>
                                  </div>
                                </form>
                                
                              </div>
                            </div>
                      </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot></tfoot>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('giangvien.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abet/domains/abet.ktcn.tvu.edu.vn/public_html/resources/views/giangvien/hocphan/chuong/muc/cauhoi/index_tracnghiem.blade.php ENDPATH**/ ?>