  


<?php $__env->startSection('content'); ?>
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
          <div class="container-fluid">
            <div class="row mb-2">
              <div class="col-sm-6">
                <h1 class="m-0 text-dark">
                  Education level Management<noscript></noscript>
                  <nav></nav>
                </h1>
              </div>
              <!-- /.col -->
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                  <li class="breadcrumb-item"><a href="#">Home</a></li>
                  <li class="breadcrumb-item active">Education level</li>
                </ol>
              </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->
          </div>
          <!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
          <div class="container-fluid">
            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                      <i class="fas fa-plus"></i>Add
                    </button>

                    <!-- Modal -->
                    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <form action="/quan-ly/bac-dao-tao/them" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLabel">Adding a new education level</h5>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                  <label for="">Education level ID</label>
                                  <input type="text" name="maBac" class="form-control" required>
                                </div>
                                <div class="form-group">
                                  <label for="">Education level Name</label>
                                  <input type="text" name="tenBac" class="form-control" required>
                                </div>
                            </div>
                            <div class="modal-footer">
                              <button type="submit" class="btn btn-primary">Save</button>

                              <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            </div>
                          </div>
                        </form>
                        
                      </div>
                    </div>
                  </div>

                  <!-- /.card-header -->
                  <div class="card-body">
                    <table id="example2" class="table table-bordered table-hover" >
                      <thead>
                        <tr>
                          <th>No.</th>
                          <th>Education level ID</th>
                          <th>Education level Name</th>
                          <th>Management Functions</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                            $i=1;
                        ?>
                        <?php $__currentLoopData = $bdt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td><?php echo e($i++); ?></td>
                              <td><?php echo e($item->maBac); ?></td>
                              <td><?php echo e($item->tenBac); ?></td>
                              <td>
                                  
                                    <button title="Edit" type="button" class="btn btn-primary" data-toggle="modal" data-target="#edit_<?php echo e($item->maBac); ?>">
                                        <i class="fas fa-edit"></i>
                                    </button>

                                    <!-- Modal edit-->
                                    <div class="modal fade" id="edit_<?php echo e($item->maBac); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                      <div class="modal-dialog" role="document">
                                        
                                        <form action="<?php echo e(asset('quan-ly/bac-dao-tao/sua')); ?>" method="post" enctype="multipart/form-data">
                                          <?php echo csrf_field(); ?>
                                          <div class="modal-content">
                                            <div class="modal-header">
                                              <h5 class="modal-title" id="exampleModalLabel">Editing Education level Information</h5>
                                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                              </button>
                                            </div>
                                            <div class="modal-body">
                                              <div class="form-group">
                                              <input type="text" class="form-control" hidden name="maBac" value="<?php echo e($item->maBac); ?>">
                                              </div>
                                              <div class="form-group">
                                                <label for="">Education level Name</label>
                                                <input type="text" name="tenBac" class="form-control" value="<?php echo e($item->tenBac); ?>" required>
                                              </div>
                                            </div>
                                            <div class="modal-footer">
                                              <button type="submit" class="btn btn-primary">Update</button>
                                              <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                            </div>
                                          </div>
                                        </form>
                                      
                                      </div>
                                    </div>
                                    <!-- end Modal edit-->

                                  <a title="Delete" class="btn btn-danger" onclick="return confirm('Do you want to delete <?php echo e($item->tenBac); ?>?')" href="<?php echo e(asset('quan-ly/bac-dao-tao/xoa/'.$item->maBac)); ?>"><i class="fa fa-trash"></i></a>
                              </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                      <tfoot></tfoot>
                    </table>
                  </div>
                  <!-- /.card-body -->
                </div>
                <!-- /.card -->
              </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->
          </div>
          <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
      </div>
      <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abet/domains/abet.ktcn.tvu.edu.vn/public_html/resources/views/admin/bacdaotao.blade.php ENDPATH**/ ?>