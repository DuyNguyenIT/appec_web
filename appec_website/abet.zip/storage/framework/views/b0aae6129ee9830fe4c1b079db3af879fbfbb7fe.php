<?php $__env->startSection('content'); ?>
    <!-- jQuery -->
    <script src="<?php echo e(asset('plugins/jquery/jquery.min.js')); ?>"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="<?php echo e(asset('plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <!-- ChartJS -->
    <script src="<?php echo e(asset('plugins/chart.js/Chart.min.js')); ?>"></script>

    <div class="content-wrapper" style="min-height: 96px;">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">
                            Thêm tiêu chí đánh giá<noscript></noscript>
                            <nav></nav>
                        </h1>
                    </div>
                    <!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Trang chủ</a></li>
                            <li class="breadcrumb-item active">Đồ án</li>
                            <li class="breadcrumb-item active">Nội dung đánh giá</li>
                            <li class="breadcrumb-item active">Nhóm tiêu chí đánh giá</li>
                        </ol>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <form action="<?php echo e(asset('giang-vien/quy-hoach-danh-gia/noi-dung-danh-gia/them-tieu-chi-submit')); ?>"
                            method="post">
                            <?php echo csrf_field(); ?>
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title"></h3>
                                    <div class="card-tools">
                                        <a href="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/noi-dung-danh-gia/xem-tieu-chi-danh-gia/'.session::get('maCTBaiQH'))); ?>"
                                            class="btn btn-secondary"><i class="fas fa-arrow-left"></i></a>
                                    </div>
                                    <input type="text" name="maCTBaiQH" value="<?php echo e($maCTBaiQH); ?>" hidden>
                                </div>
                                <!-- /.card-header -->
                                <div class="card-body">
                                    <div class="form-group">
                                        <label for=""><?php echo e(__('Student Outcomes')); ?>:</label>
                                        <select name="maCDR3" id="" class="form-control">
                                            <?php $__currentLoopData = $cdr3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($x->maCDR3); ?>"><?php echo e($x->maCDR3VB); ?>:
                                                    <?php echo e($x->tenCDR3); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <hr>
                                    <div class="fomr-group">
                                        <label for=""><?php echo e(__('Studying results')); ?></label>
                                        <select name="maKQHT" id="" class="form-control">
                                            <?php $__currentLoopData = $kqht; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($y->maKQHT); ?>">
                                                    <?php echo e($y->maKQHTVB); ?>--<?php echo e($y->tenKQHT); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    
                                    <div class="fomr-group">
                                        <label for=""><?php echo e(__("ABET's SO")); ?></label>
                                        <select name="maChuanAbet" id="" class="form-control">
                                            <?php $__currentLoopData = $chuanAbet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($abet->maChuanAbet); ?>">
                                                    <?php echo e($abet->maChuanAbetVB); ?>--<?php echo e($abet->tenChuanAbet); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <hr>
                                    <div class="form-group">
                                        <label for=""><?php echo e(__('Planning Content')); ?>:</label>
                                        <select name="maNoiDungQH" id="maNoiDungQH" class="form-control">
                                            <?php $__currentLoopData = $ndqh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $z): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($z->maNoiDungQH); ?>"><?php echo e($z->tenNoiDungQH); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for=""><?php echo e(__('Standard')); ?> (Theo thứ tự của phiếu chấm):</label>
                                        <div class="row">
                                            <div class="col-md-9">
                                                <select name="maTCDG" id="tenTCDG" class="form-control">
                                                    <?php $__currentLoopData = $tieuchuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($tc->maTCDG); ?>"><?php echo e($tc->tenTCDG); ?> -
                                                            <?php echo e($tc->diem); ?> <?php echo e(__('mark')); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="col-md-3">
                                                <button type="button" href="" class="btn btn-primary" data-toggle="modal"
                                                    data-target="#themTieuChuan">
                                                    <?php echo e(__('Add')); ?> <?php echo e(__('Standard')); ?>

                                                </button>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="">Chọn số tiêu chí cần nhập:</label>
                                        <select name="" id="soTC" class="form-control">
                                            <option value="1">1</option>
                                            <option value="2">2</option>
                                            <option value="3">3</option>
                                            <option value="4">4</option>
                                            <option value="6">6</option>
                                            <option value="8">8</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <table class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>Tiêu chí</th>
                                                    <th>Nội dung tiêu chí</th>
                                                    <th>Điểm tiêu chí</th>
                                                </tr>
                                            </thead>
                                            <tbody id="tbl-content">
                                                <?php for($i = 1; $i <= 1; $i++): ?>
                                                    <tr>
                                                        <td><?php echo e($i); ?></td>
                                                        <td>
                                                            <input type='text' name="tenTCCD[]" class='form-control'>
                                                        </td>
                                                        <td>
                                                            <input type='text' name="diemTCCD[]" class='form-control'>
                                                        </td>
                                                    </tr>
                                                <?php endfor; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="form-group">
                                        <button class="btn btn-primary" type="submit"> <?php echo e(__('Save')); ?></button>
                                    </div>
                                </div>
                                <!-- /.card-body -->
                            </div>
                        </form>

                        <form action="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/noi-dung-danh-gia/them-tieu-chuan')); ?>"
                            method="post">
                            <?php echo csrf_field(); ?>
                            <!-- Modal -->
                            <div class="modal fade" id="themTieuChuan" tabindex="-1" role="dialog"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Add')); ?></h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <input type="text" hidden name="maNoiDungQH" id="maNoiDungQH"
                                            value="<?php echo e($ndqh[0]->maNoiDungQH); ?>">
                                        <div class="modal-body">
                                            <div class="form-group">
                                                <label for=""> Nhập tên tiêu chuẩn:</label>
                                                <input type="text" class="form-control" name="tenTCDG">
                                            </div>
                                            <div class="form-group">
                                                <label for=""><?php echo e(__('mark')); ?>:</label>
                                                <input type="number" max="10" min="0" class="form-control" name="diemTCDG">
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-primary">Lưu</button>
                                            <button type="button" class="btn btn-secondary"
                                                data-dismiss="modal">Hủy</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <!-- /.card -->

                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <script>
        $('#soTC').on('change', function() {
            var soTC = this.value;
            var html = "";
            $('#tbl-content').empty();
            for (let index = 1; index <= soTC; index++) {
                html += "<tr>" +
                    "<td>" + index + "</td>" +
                    "<td>" +
                    "<input type='text' name='tenTCCD[]' class='form-control'>" +
                    "</td>" +
                    "<td>" +
                    "<input type='text' name='diemTCCD[]' class='form-control'>" +
                    "</td>" +
                    "</tr>";
            }
            $('#tbl-content').append(html);
        });
        $('#maNoiDungQH').on('change', function() {
            var maNoiDungQH = this.value;
            $('input[id=maNoiDungQH]').val(this.value);
            $.ajax({
                type: 'GET',
                url: '/giang-vien/quy-hoach-danh-gia/get-tieu-chuan-by-NDQH/' + maNoiDungQH,
                success: function(data) {
                    $('#tenTCDG').empty();
                    $('#tenTCDG').append(data);
                }
            })
        })

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('giangvien.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/giangvien/quyhoach/themtieuchi.blade.php ENDPATH**/ ?>