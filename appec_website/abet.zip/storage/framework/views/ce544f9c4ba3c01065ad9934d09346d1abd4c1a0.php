
<?php $__env->startSection('content'); ?>

<div class="content-wrapper" style="min-height: 22px;">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0 text-dark">
            Curriculum<noscript></noscript>
            <nav></nav>
          </h1>
        </div>
        <!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(asset('/quan-ly')); ?>">Home</a></li>
            <li class="breadcrumb-item active">Curriculum</li>
          </ol>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->
  <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <h5><i class="icon fas fa-check"></i> Thông báo!</h5>
      <?php echo e(session('success')); ?>

    </div>
  <?php endif; ?>
  <?php if(session('warning')): ?>
    <div class="alert alert-warning alert-dismissible">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
      <h5><i class="icon fas fa-exclamation-triangle"></i> Thông báo!</h5>
      <?php echo e(session('warning')); ?>

    </div>
  <?php endif; ?>
  <!-- Main content -->

  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">
                 <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                  <i class="fas fa-plus"></i>
              </button>
              <a href="<?php echo e(asset('quan-ly/chuong-trinh-dao-tao/excel')); ?>">Xuất excel</a>
                <!-- Modal -->
                <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <form action="<?php echo e(asset('quan-ly/chuong-trinh-dao-tao/them')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel">Adding a new curriculum</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">
                          <div class="form-group">
                            <label for="">Curriculum name:</label>
                            <input type="text" name="tenCT" class="form-control" required>
                          </div>
                          <div class="form-group">
                            <label for="">Education level</label>
                            <select name="maBac" id="" class="form-control" required>
                              <?php $__currentLoopData = $bac; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($x->maBac); ?>"><?php echo e($x->tenBac); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </div>
                          <div class="form-group">
                            <label for="">Specialized</label>
                            <select name="maCNganh" id="" class="form-control" required>
                              <?php $__currentLoopData = $chuyennganh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($y->maCNganh); ?>"><?php echo e($y->tenCNganh); ?></option>  
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </div>
                          <div class="form-group">
                              <label for="">Forms of training</label>
                              <select name="maHe" id="" class="form-control" required>
                                <?php $__currentLoopData = $he; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $z): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($z->maHe); ?>"><?php echo e($z->tenHe); ?></option>  
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                          </div>
                        </div>
                        <div class="modal-footer">
                          <button type="submit" class="btn btn-primary">Save</button>
                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancle</button>
                        </div>
                      </div>
                  </form>
                    
                  </div>
                </div>


                
              </h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                  <tr>
                    <th>No.</th>
                    <th>Curriculum name</th>
                    <th>Education level</th>
                    <th>Specialized</th>
                    <th>Forms of training</th>
                    <th>Option</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                      $i=1;
                  ?>
                  <?php $__currentLoopData = $ctdaotao; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($ct->tenCT); ?></td>
                        <td><?php echo e($ct->bac->tenBac); ?></td>
                        <td><?php echo e($ct->cnganh->tenCNganh); ?></td>
                        <td><?php echo e($ct->he->tenHe); ?></td>
                        <td>
                          
                            <button class="btn btn-success" data-toggle="modal" data-target="#edit_<?php echo e($ct->maCT); ?>">
                              <i class="fas fa-edit"></i> 
                            </button>
                          <a class="btn btn-danger" onclick="return confirm('Bạn có muốn xóa <?php echo e($ct->tenCT); ?>?')" href="<?php echo e(asset('quan-ly/chuong-trinh-dao-tao/xoa/'.$ct->maCT)); ?>"><i class="fa fa-trash"></i></a>
                            <!-- Modal -->
                          <div class="modal fade" id="edit_<?php echo e($ct->maCT); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                              <form action="<?php echo e(asset('quan-ly/chuong-trinh-dao-tao/sua')); ?>" method="post">
                              <?php echo csrf_field(); ?>
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h5 class="modal-title" id="exampleModalLabel">Editing the curriculum</h5>
                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                  </button>
                                </div>
                                <div class="modal-body">
                                  <input type="text" name="maCT" value="<?php echo e($ct->maCT); ?>" class="form-control" hidden>
                                  <div class="form-group">
                                    <label for="">Curriculum name</label>
                                    <input type="text" name="tenCT" class="form-control" value="<?php echo e($ct->tenCT); ?>" required>
                                  </div>
                                  <div class="form-group">
                                    <label for="">Education level</label>
                                    <select name="maBac" id="" class="form-control" required>
                                      <?php $__currentLoopData = $bac; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($ct->maBac==$x->maBac): ?>
                                        <option value="<?php echo e($x->maBac); ?>" selected><?php echo e($x->tenBac); ?></option>
                                        <?php else: ?>
                                        <option value="<?php echo e($x->maBac); ?>"><?php echo e($x->tenBac); ?></option>
                                        <?php endif; ?>
                                         
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                  </div>
                                  <div class="form-group">
                                    <label for="">Specialized</label>
                                    <select name="maCNganh" id="" class="form-control" required>
                                      <?php $__currentLoopData = $chuyennganh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($ct->maCNganh==$y->maCNganh): ?>
                                          <option value="<?php echo e($y->maCNganh); ?>" selected><?php echo e($y->tenCNganh); ?></option>  
                                            
                                        <?php else: ?>
                                          <option value="<?php echo e($y->maCNganh); ?>"><?php echo e($y->tenCNganh); ?></option>  
                                            
                                        <?php endif; ?>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                  </div>
                                  <div class="form-group">
                                      <label for="">Forms of training</label>
                                      <select name="maHe" id="" class="form-control" required>
                                        <?php $__currentLoopData = $he; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $z): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <?php if($ct->maHe==$z->maHe): ?>
                                            <option value="<?php echo e($z->maHe); ?>" selected><?php echo e($z->tenHe); ?></option>  
                                          <?php else: ?>
                                            <option value="<?php echo e($z->maHe); ?>"><?php echo e($z->tenHe); ?></option>   
                                          <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </select>
                                  </div>
                                </div>
                            </form>
                             
                            <div class="modal-footer">
                              <button type="submit" class="btn btn-primary">Update</button>
                              <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                </div>
                              </div>
                            </div>
                          </div>
                          
                        </td>
                      </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                  
                 
                </tbody>
                <tfoot></tfoot>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abet/domains/abet.ktcn.tvu.edu.vn/public_html/resources/views/admin/chuongtrinhDT.blade.php ENDPATH**/ ?>