<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">Nhóm tiêu chí đánh giá<noscript></noscript>
                            <nav></nav>
                        </h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(asset('/')); ?>">Trang chủ</a></li>
                            <li class="breadcrumb-item "><a href="quyhoachKQHT.html">Đồ án</a></li>
                            <li class="breadcrumb-item "><a
                                    href="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/noi-dung-danh-gia/xem-noi-dung-danh-gia/' . Session::get('maCTBaiQH'))); ?>">Nội
                                    dung đánh giá</a></li>
                            <li class="breadcrumb-item active">Nhóm tiêu chí đánh giá</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">
                                    <a href="<?php echo e(asset('giang-vien/quy-hoach-danh-gia/noi-dung-danh-gia/them-tieu-chi-danh-gia/' . Session::get('maCTBaiQH'))); ?>"
                                        class="btn btn-primary">
                                        <i class="fas fa-plus"></i> 
                                    </a>
                                    
                                </h3>
                                <div class="card-tools">
                                    <a href="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/quy-hoach-ket-qua/' . Session::get('maHocPhan') . '/' . Session::get('maBaiQH') . '/' . Session::get('maHK') . '/' . Session::get('namHoc') . '/' . Session::get('maLop'))); ?>"
                                        class="btn btn-secondary"><i class="fas fa-arrow-left"></i></a>
                                </div>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <table id="example2" class="table table-bordered table-hover" >
                                    <thead>
                                        <tr>
                                            <th>STT</th>
                                            <th>Tiêu chuẩn</th>
                                            <th colspan="2">Chuẩn đầu ra - ABET</th>
                                            <th>Tiêu chí</th>
                                            <th>Điểm</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $i = 1;
                                            $chayTieuChuan = 0;
                                            $chayCDR_TCDG = 0;
                                            $tieuChuanHienTai = 0;
                                            $cdrHienTai = 0;
                                        ?>
                                        <?php $__currentLoopData = $tieuchi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                
                                                if ($cdrHienTai != $tc->maCDR3) {
                                                    //kiểm tra nếu chuẩn đầu ra thay đổi thì chuyển biến chạy về 1
                                                    $cdrHienTai = $tc->maCDR3;
                                                    $chayCDR_TCDG = 1;
                                                } else {
                                                    //nếu không tăng biến chạy lên
                                                    $chayCDR_TCDG += 1;
                                                }
                                                if ($tieuChuanHienTai != $tc->maTCDG) {
                                                    //đặt kiểm tiêu chuẩn ở dưới vì khi khác tiêu chuẩn thì biến chayCDR phải trở về 1
                                                    $tieuChuanHienTai = $tc->maTCDG;
                                                    $chayTieuChuan = 1;
                                                    $chayCDR_TCDG = 1;
                                                } else {
                                                    $chayTieuChuan += 1;
                                                }
                                                
                                                $demTCDG = $tieuchi->groupBy('tenTCDG')->count();
                                                $demCDR_TCDG = $tieuchi
                                                    ->where('maTCDG', $tc->maTCDG)
                                                    ->groupBy('tenCDR3')
                                                    ->count();
                                                $demTieuChi_TCDG = $tieuchi->where('maTCDG', $tc->maTCDG)->count('tenTCCD');
                                                $demTC_CDR = $tieuchi
                                                    ->where('maTCDG', $tc->maTCDG)
                                                    ->where('maCDR3', $tc->maCDR3)
                                                    ->count('tenTCCD');
                                            ?>
                                            <?php if($chayTieuChuan == 1): ?>
                                                <tr>
                                                    <td rowspan=<?php echo e($demTieuChi_TCDG); ?>><?php echo e($i++); ?></td>
                                                    <td rowspan=<?php echo e($demTieuChi_TCDG); ?>><b><?php echo e($tc->tenTCDG); ?></b></td>
                                                    <?php if($chayCDR_TCDG == 1): ?>
                                                        <td rowspan=<?php echo e($demTC_CDR); ?>><?php echo e($tc->maCDR3VB); ?>:
                                                            <?php echo e($tc->tenCDR3); ?>; <br> <?php echo e($tc->maChuanAbetVB); ?>-- <?php echo e($tc->tenChuanAbet); ?></td>
                                                        <td rowspan=<?php echo e($demTC_CDR); ?>>
                                                            <!-- Button trigger modal -->
                                                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#edit_abet_<?php echo e($tc->maTCDG); ?>__<?php echo e($tc->maCDR3); ?>">
                                                                <i class="fas fa-edit"></i> ABET's SO
                                                            </button>
                                                            
                                                            <!-- Modal -->
                                                            <div class="modal fade" id="edit_abet_<?php echo e($tc->maTCDG); ?>__<?php echo e($tc->maCDR3); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                                <div class="modal-dialog" role="document">
                                                                    <form action="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/noi-dung-danh-gia/sua-chuan-abet')); ?>" method="post">
                                                                    <?php echo csrf_field(); ?>
                                                                    <div class="modal-content">
                                                                        <div class="modal-header">
                                                                        <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Edit')); ?> </h5>
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                        </div>
                                                                        <div class="modal-body">
                                                                            <input type="text" name="maTCDG" value="<?php echo e($tc->maTCDG); ?>" hidden>
                                                                            <input type="text" name="maCDR3" value="<?php echo e($tc->maCDR3); ?>" hidden>
                                                                            <div class="form-group">
                                                                                <label ><?php echo e(__('SOs')); ?></label>
                                                                                <select name="maChuanAbet" id="" class="form-control">
                                                                                    <?php $__currentLoopData = $ABET; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <?php if($tc->maChuanAbet==$abet->maChuanAbet): ?>
                                                                                            <option value="<?php echo e($abet->maChuanAbet); ?>" selected><?php echo e($abet->maChuanAbetVB); ?>-- <?php echo e($abet->tenChuanAbet); ?></option>
                                                                                        <?php else: ?>
                                                                                            <option value="<?php echo e($abet->maChuanAbet); ?>" ><?php echo e($abet->maChuanAbetVB); ?>-- <?php echo e($abet->tenChuanAbet); ?></option>
                                                                                        <?php endif; ?>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                        <div class="modal-footer">
                                                                        <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
                                                                        </div>
                                                                    </div>
                                                                    </form>
                                                               
                                                                </div>
                                                            </div>

                                                        
                                                        </td>
                                                        <td><?php echo e($chayCDR_TCDG); ?>. <?php echo e($tc->tenTCCD); ?></td>
                                                        <td><?php echo e($tc->diemTCCD); ?> điểm</td>
                                                    <?php else: ?>
                                                        <td><?php echo e($chayCDR_TCDG); ?>. <?php echo e($tc->tenTCCD); ?></td>
                                                        <td><?php echo e($tc->diemTCCD); ?> điểm</td>
                                                    <?php endif; ?>
                                                </tr>
                                            <?php else: ?>
                                                <tr>
                                                    <?php if($chayCDR_TCDG == 1): ?>
                                                        <td rowspan=<?php echo e($demTC_CDR); ?>><?php echo e($tc->maCDR3VB); ?>:
                                                            <?php echo e($tc->tenCDR3); ?>; <br> <?php echo e($tc->maChuanAbetVB); ?>-- <?php echo e($tc->tenChuanAbet); ?></td>
                                                        <td rowspan=<?php echo e($demTC_CDR); ?>>
                                                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#edit_abet_<?php echo e($tc->maTCDG); ?>_<?php echo e($tc->maCDR3); ?>">
                                                                <i class="fas fa-edit"></i> ABET's SO
                                                            </button>
                                                            
                                                            <!-- Modal -->
                                                            <div class="modal fade" id="edit_abet_<?php echo e($tc->maTCDG); ?>_<?php echo e($tc->maCDR3); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                                <div class="modal-dialog" role="document">
                                                                    <form action="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/noi-dung-danh-gia/sua-chuan-abet')); ?>" method="post">
                                                                        <?php echo csrf_field(); ?>
                                                                        <div class="modal-content">
                                                                            <div class="modal-header">
                                                                            <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Edit')); ?> </h5>
                                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                                <span aria-hidden="true">&times;</span>
                                                                            </button>
                                                                            </div>
                                                                            <div class="modal-body">
                                                                                <input type="text" name="maTCDG" value="<?php echo e($tc->maTCDG); ?>" hidden>
                                                                                <input type="text" name="maCDR3" value="<?php echo e($tc->maCDR3); ?>" hidden>

                                                                                <div class="form-group">
                                                                                    <label ><?php echo e(__('SOs')); ?></label>
                                                                                    <select name="maChuanAbet" id="" class="form-control">
                                                                                        <?php $__currentLoopData = $ABET; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                            <?php if($tc->maChuanAbet==$abet->maChuanAbet): ?>
                                                                                                <option value="<?php echo e($abet->maChuanAbet); ?>" selected><?php echo e($abet->maChuanAbetVB); ?>-- <?php echo e($abet->tenChuanAbet); ?></option>
                                                                                            <?php else: ?>
                                                                                                <option value="<?php echo e($abet->maChuanAbet); ?>" ><?php echo e($abet->maChuanAbetVB); ?>-- <?php echo e($abet->tenChuanAbet); ?></option>
                                                                                            <?php endif; ?>
                                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                    </select>
                                                                                </div>
                                                                            </div>
                                                                            <div class="modal-footer">
                                                                            <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
                                                                            
                                                                            </div>
                                                                        </div>
                                                                    </form>
                                                               
                                                                </div>
                                                            </div>

                                                        
                                                        </td>
                                                        <td><?php echo e($chayCDR_TCDG); ?>. <?php echo e($tc->tenTCCD); ?></td>
                                                        <td><?php echo e($tc->diemTCCD); ?> điểm</td>
                                                    <?php else: ?>
                                                        <td><?php echo e($chayCDR_TCDG); ?>. <?php echo e($tc->tenTCCD); ?></td>
                                                        <td><?php echo e($tc->diemTCCD); ?> điểm</td>
                                                    <?php endif; ?>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('giangvien.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/giangvien/quyhoach/xemtieuchi.blade.php ENDPATH**/ ?>