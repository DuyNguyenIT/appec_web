<?php $__env->startSection('content'); ?>
<div class="content-wrapper" style="min-height: 22px;">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">
              <?php echo e(__('Course syllabus')); ?> <noscript></noscript>
              <nav></nav>
              
            </h1>
          </div>
          <!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#"><?php echo e(__('Home')); ?></a></li>
              <li class="breadcrumb-item active"><a href="<?php echo e(asset('quan-ly/hoc-phan')); ?>"><?php echo e(__('Course')); ?></a></li>
              <li class="breadcrumb-item active"><?php echo e(__('Course syllabus')); ?></li>
            </ol>
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
          <h5><i class="icon fas fa-check"></i> Th�ng b�o</h5>
          <?php echo e(session('success')); ?>

        </div>
      <?php endif; ?>
      <?php if(session('warning')): ?>
        <div class="alert alert-warning alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
          <h5><i class="icon fas fa-exclamation-triangle"></i> Th�ng b�o</h5>
          <?php echo e(session('warning')); ?>

        </div>
      <?php endif; ?>
    <!-- Main content -->

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3  style="text-align: center">
                  COURSE SYLLABUS <br>
                Course : <?php echo e($hocPhan->tenHocPhan); ?> <br>
                Course code: <?php echo e($hocPhan->maHocPhan); ?>

                </h3>
              </div>
              <a class="btn btn-primary" href="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/in-de-cuong-mon-hoc/'.$hocPhan->maHocPhan)); ?>">IN ĐỀ CƯƠNG</a>
              <!-- /.card-header -->
              <div class="card-body">
              <h5><b>1. General information</b></h5>    <!-- ----------------------------------1. Thông tin chung-------------------- -->
              <table class="table table-bordered">
                <thead class="thead-green" style="background-color: green">
                  <tr>
                    <th>Course type</th>
                    <th>Number of credits</th>
                    <th>Number of learning periods</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>
                      <?php
                          $daicuong = array("A1", "A2", "A3", "A4","A5");
                          $coso = array('B1' );
                          $chuyennganh = array('B2','B3');
                      ?>
                      <?php if(in_array($hocPhan->maCTKhoiKT,$daicuong)): ?>
                        <ul>
                          <li>General   <i class="far fa-check-square"></i>
                          <li>Basic   
                          <li>Specialized 
                        </ul>
                      <?php else: ?>
                          <?php if(in_array($hocPhan->maCTKhoiKT,$coso)): ?>
                            <ul>
                              <li>General   
                              <li>Basic    <i class="far fa-check-square"></i>
                              <li>Specialized 
                            </ul>
                          <?php else: ?>
                            <?php if(in_array($hocPhan->maCTKhoiKT,$chuyennganh)): ?>
                                <ul>
                                <li>General   
                                <li>Basic   
                                <li>Specialized  <i class="far fa-check-square"></i>
                              </ul>
                            <?php endif; ?>
                          <?php endif; ?>
                      <?php endif; ?>
                   
                      
                    </td>
                    <td>
                      <ul>
                        <li><?php echo e(__('Theory')); ?>: <?php echo e($hocPhan->tinChiLyThuyet); ?>

                        <li><?php echo e(__('Exercise')); ?>: 
                        <li><?php echo e(__('Practice')); ?>: <?php echo e($hocPhan->tinChiThucHanh); ?>

                      </ul>
                    </td>
                    <td>
                      <ul>
                        <li><?php echo e(__('Theory')); ?>: <?php echo e($hocPhan->tinChiLyThuyet *15); ?>

                        <li><?php echo e(__('Exercise')); ?>: 
                        <li><?php echo e(__('Practice')); ?>: <?php echo e($hocPhan->tinChiThucHanh *30); ?>

                      </ul>
                    </td>
                  </tr>
                </tbody>
              </table>
              <div class="row">
                <div class="col-md-4">
                  <h6><b><?php echo e(__('Learners')); ?>:</b></h6> 
                </div>
                <div class="col-md-7">
                  <?php echo e(__('Education level')); ?>: <?php echo e($bac->tenBac); ?> <br>
                  <?php echo e(__('Specialized')); ?>: <?php echo e($nganh->tenNganh); ?> <br>
                  <?php echo e(__('Major')); ?>: <?php echo e($CNganh->tenCNganh); ?><br>
                  <?php echo e(__('Forms of training')); ?>: <?php echo e($he->tenHe); ?> <br>
                </div>
                <div class="col-md-1">
                  <td>
                  </td>
                </div>
              </div>
             <h6><b><?php echo e(__('Forms of training')); ?></b></h6>
             <table class="table table-bordered">
               <tr>
                 <td><?php echo e(__('Prerequisites')); ?></td>
                 <td><i>
                  <?php $__currentLoopData = $monTQ; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php echo e($data->hoc_phan->tenHocPhan); ?>;
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                </i></td>
                 <td>
                 <!-- Button trigger modal -->
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addMonTQ">
                  <i class="fas fa-edit"></i>
                </button>

                <!-- Modal -->
                <div class="modal fade" id="addMonTQ" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/them_mon_tien_quyet')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Thêm môn tiên quyết</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">

                        <div class="form-group">
                          <label for="">Chọn môn tiên quyết</label>
                          <input type="text" name="maHocPhan" value="<?php echo e($hocPhan->maHocPhan); ?>" hidden>
                          <select name="maMonTienQuyet" id="" class="form-control">
                              <?php $__currentLoopData = $monHoc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($data->maHocPhan); ?>"> <?php echo e($data->maHocPhan); ?> -- <?php echo e($data->tenHocPhan); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save </button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                      </div>
                    </div>
                    
                    </form>
                    
                  </div>
                </div>
                </td>
               </tr>
               <tr>
                 <td><?php echo e(__('Other requirements')); ?></td>
                 <td>
                   <i>
                     <?php echo $hocPhan->yeuCau; ?>

                   </i>
                 </td>
                 <td>
                  
                  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addyeuCau">
                    <i class="fas fa-edit"></i>
                  </button>
    
                  <!-- Modal -->
                  <div class="modal fade" id="addyeuCau" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg" role="document">
                      <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/sua_yeu_cau_mon_hoc')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Other requirements')); ?></h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">
                          <div class="form-group">
                            <input type="text" name="maHocPhan" value="<?php echo e($hocPhan->maHocPhan); ?>" hidden>
                          </div>
                          <div class="form-group">
                              <textarea name="yeuCau" id="yeuCau" cols="30" rows="10" class="form-control" required>
                              
                                <?php echo e($hocPhan->yeuCau); ?>

                    
                              </textarea>
                                <script>
                                  CKEDITOR.replace( 'yeuCau', {
                                      filebrowserUploadUrl: "<?php echo e(route('upload', ['_token' => csrf_token() ])); ?>",
                                      filebrowserUploadMethod: 'form'
                                  } );
                              </script>
                          
                          </div>
                        </div>
                        <div class="modal-footer">
                          <button type="submit" class="btn btn-primary">Save</button>
                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        </div>
                      </div>
                      
                      </form>
                   
                    </div>
                  </div>

                </td>
               </tr>
             </table>
             <h5><b>2.<?php echo e(__('Learning resources')); ?></b></h5>    <!-----------------------------------2. Tài liệu tham khảo--------------------------->
             <table class="table table-bordered">
               <tr>
                 <td><?php echo e(__('Books ')); ?></td>
                 <td style="text-align: justify">
                  <?php if($tailieu): ?>
                       <?php echo $tailieu->giaoTrinh; ?>

                  <?php endif; ?>
                
                 </td>
                 <td>
                  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addgiaoTrinh">
                    <i class="fas fa-edit"></i>
                  </button>
    
                  <!-- Modal -->
                  <div class="modal fade" id="addgiaoTrinh" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg" role="document">
                      <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/sua_giao_trinh')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                       <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Books ')); ?></h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">
                          <div class="form-group">
                            <input type="text" name="maHocPhan" value="<?php echo e($hocPhan->maHocPhan); ?>" hidden>
                          </div>
                          <div class="form-group">
                              <textarea name="giaoTrinh" id="giaoTrinh" cols="30" rows="10" class="form-control" required>
                                <?php if($tailieu): ?>
                                    <?php echo e($tailieu->giaoTrinh); ?>

                              <?php endif; ?>  
                              </textarea>
                                <script>
                                  CKEDITOR.replace( 'giaoTrinh', {
                                      filebrowserUploadUrl: "<?php echo e(route('upload', ['_token' => csrf_token() ])); ?>",
                                      filebrowserUploadMethod: 'form'
                                  } );
                              </script>
                          
                          </div>
                        </div>
                        <div class="modal-footer">
                          <button type="submit" class="btn btn-primary">Save</button>
                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        </div>
                      </div>
                    </form>
                   
                    </div>
                  </div>
                 </td>
               </tr>
               <tr>
                 <td><?php echo e(__('References')); ?></td>
                 <td>
                   <?php if($tailieu): ?>
                        <?php echo $tailieu->thamKhaoThem; ?>

                   <?php endif; ?>
                
                 </td>
                 <td>
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addthamKhaoThem">
                      <i class="fas fa-edit"></i>
                    </button>
      
                    <!--///////////////////////////// Modal thêm tài liệu tham khảo thêm-->
                    <div class="modal fade" id="addthamKhaoThem" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog modal-lg" role="document">
                        <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/sua_tai_lieu_tham_khao_them')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('References')); ?></h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
                            <div class="form-group">
                              <input type="text" name="maHocPhan" value="<?php echo e($hocPhan->maHocPhan); ?>" hidden>
                            </div>
                            <div class="form-group">
                                <textarea name="thamKhaoThem" id="thamKhaoThem" cols="30" rows="10" class="form-control" required>
                                  <?php if($tailieu): ?>
                                      <?php echo e($tailieu->thamKhaoThem); ?>

                                <?php endif; ?>  
                                </textarea>
                                  <script>
                                    CKEDITOR.replace( 'thamKhaoThem', {
                                        filebrowserUploadUrl: "<?php echo e(route('upload', ['_token' => csrf_token() ])); ?>",
                                        filebrowserUploadMethod: 'form'
                                    } );
                                </script>
                            
                            </div>
                          </div>
                          <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">Save</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                          </div>
                        </div>
                        </form>
                       
                      </div>
                    </div>
                </td>
               </tr>
               <tr>
                  <td><?php echo e(__('Other learning materials ')); ?></td>
                  <td>
                    <?php if($tailieu): ?>
                         <?php echo $tailieu->taiLieuKhac; ?>

                    <?php endif; ?>  
                  </td>
                  <td>
                        <!-- Button trigger modal -->
              <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addtaiLieuKhac">
                <i class="fas fa-edit"></i>
              </button>

              <!--//////////////////////// Modal thêm các loại tài liệu khác -->
              <div class="modal fade" id="addtaiLieuKhac" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg" role="document">
                  <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/sua_tai_lieu_khac')); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Other learning materials ')); ?></h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                      <div class="form-group">
                        <input type="text" name="maHocPhan" value="<?php echo e($hocPhan->maHocPhan); ?>" hidden>
                      </div>
                      <div class="form-group">
                          <textarea name="taiLieuKhac" id="taiLieuKhac" cols="30" rows="10" class="form-control" required>
                            <?php if($tailieu): ?>
                                  <?php echo e($tailieu->taiLieuKhac); ?>

                            <?php endif; ?>  
                          </textarea>
                            <script>
                              CKEDITOR.replace( 'taiLieuKhac', {
                                  filebrowserUploadUrl: "<?php echo e(route('upload', ['_token' => csrf_token() ])); ?>",
                                  filebrowserUploadMethod: 'form'
                              } );
                          </script>
                      
                      </div>
                    </div>
                    <div class="modal-footer">
                      <button type="submit" class="btn btn-primary">Save</button>
                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    </div>
                  </div>
                  </form>
                 
                </div>
              </div>
                  </td>
               </tr>
             </table>
             <h5><b>3.<?php echo e(__('Course description')); ?></b></h5>    <!-----------------------------------3. Mô tả môn học--------------------------->
             <!-- Button trigger modal -->
      
              <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addMoTa">
                <i class="fas fa-edit"></i>
              </button> <br>

              <?php echo $hocPhan->moTaHocPhan; ?>

              <!-- /////////////////////Modal thêm mô tả học phần-->

              <div class="modal fade" id="addMoTa" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg" role="document">
                  <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/sua_mo_ta_mon_hoc')); ?>" method="post">
                  <?php echo csrf_field(); ?>
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Course description')); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <div class="form-group">
                          <input type="text" name="maHocPhan" value="<?php echo e($hocPhan->maHocPhan); ?>" hidden>
                        </div>
                        <div class="form-group">
                            <textarea name="moTaHocPhan" id="moTa" cols="30" rows="10" class="form-control" required>
                              <?php echo e($hocPhan->moTaHocPhan); ?>

                            </textarea>
                              <script>
                                CKEDITOR.replace( 'moTa', {
                                    filebrowserUploadUrl: "<?php echo e(route('upload', ['_token' => csrf_token() ])); ?>",
                                    filebrowserUploadMethod: 'form'
                                } );
                            </script>
                        
                        </div>
                      </div>
                      <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
           

             <h5><b>4.<?php echo e(__('Course learning outcomes ')); ?></b></h5>    <!-----------------------------------4. chuẩn đầu ra của môn học--------------------------->
              <table class="table table-bordered">
                <thead>
                    <th colspan="2"></th>
                    <th style="background-color: green"><?php echo e(__('Satisfy LOs of the program')); ?></th> 
                    <th style="background-color: green"><?php echo e(__('Satisfy Abet')); ?></th> 
                    <th style="background-color: green">Option</th>                     
                </thead>
                <tbody>
                   <?php $__currentLoopData = $CDR1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cdr1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td colspan="3"><b><?php echo e(__('Topic')); ?> <?php echo e($cdr1->maCDR1VB); ?>: <?php echo e($cdr1->tenCDR1); ?>:</b> 
                          <!-- Button trigger modal -->
                          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#chuDe_<?php echo e($cdr1->maCDR1VB); ?>">
                            <i class="fas fa-edit"></i>
                          </button>

                          <!-- /////////////////// Modal them noi dung mon hoc-->
                          <div class="modal fade" id="chuDe_<?php echo e($cdr1->maCDR1VB); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                              <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/them_chuan_dau_ra_mon_hoc')); ?>" method="post">
                              <?php echo csrf_field(); ?>
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Topic')); ?> <?php echo e($cdr1->maCDR1VB); ?>: <?php echo e($cdr1->tenCDR1); ?></h5>
                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                  </button>
                                </div>
                                <div class="modal-body">
                                  <div class="form-group">
                                    <input type="text" name="maHocPhan" value="<?php echo e($hocPhan->maHocPhan); ?>" hidden>
                                  </div>
                                  <div class="form-group">
                                      <label for=""> <?php echo e(_('Studying results ID')); ?>:</label>
                                      <input type="text" name="maKQHTVB" placeholder="L1,L2,..." class="form-control">
                                  </div>
                                  <div class="form-group">
                                    <label for=""> <?php echo e(__('studying results content')); ?>:</label>
                                    <input type="text" name="tenKQHT" placeholder="Ph�n t�ch, kh�i ni&#7879;m, m� t&#7843;,..." class="form-control">
                                  </div>
                                  <div class="form-group">
                                    <label for=""> <?php echo e(__('Level-3 outcome')); ?>:</label>
                                    <select name="maCDR3[]" id="" class="form-control" multiple>
                                      <?php $__currentLoopData = $cdr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <?php if($t->maCDR1==$cdr1->maCDR1): ?>
                                              <option value="<?php echo e($t->maCDR3); ?>"> <?php echo e($t->maCDR3VB); ?> - <?php echo e($t->tenCDR3); ?></option>
                                          <?php endif; ?>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                  </div>

                                  <div class="form-group">
                                    <select name="maChuanAbet" id="" class="form-control">
                                      <?php $__currentLoopData = $chuan_abet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($abet->maChuanAbet); ?>"><?php echo e($abet->maChuanAbetVB); ?>--<?php echo e($abet->tenChuanAbet); ?></option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      
                                    </select>
                                  </div>
                                </div>
                                <div class="modal-footer">
                                  <button type="submit" class="btn btn-primary">Save</button>
                                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                </div>
                              </div>
                              </form>
                              
                            </div>
                          </div>
                        </td>
                      </tr>
                      <?php
                            $cur_rs=0;
                            $bienchay=0;
                      ?>
                      <?php $__currentLoopData = $kqht; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($x->maCDR1==$cdr1->maCDR1): ?>
                          
                            <?php
                                $rs=$kqht->where('maCDR1',$cdr1->maCDR1)->where('maKQHT',$x->maKQHT)->count(); 
                                
                                if($bienchay>=$rs || $rs>$cur_rs){
                                  $cur_rs=$rs;  
                                  $bienchay=1;
                                }
                                else {
                                   $bienchay+=1;
                                }
                            ?>
                       
                            <?php if($bienchay==1): ?>
                              <tr>
                                <td rowspan=<?php echo e($rs); ?>><?php echo e($x->maKQHTVB); ?></td>
                                <td rowspan=<?php echo e($rs); ?>><?php echo e($x->tenKQHT); ?></td>
                                <td><?php echo e($x->maCDR3VB); ?></td>
                                <td><?php echo e($x->maChuanAbetVB); ?></td>
                                <td>
                                  
                                  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#editKQHT_HP_<?php echo e($x->id); ?>">
                                    <i class="fas fa-edit"></i>
                                  </button>
                                </td>
                              </tr>   
                            <?php else: ?>
                              <tr>
                                <td><?php echo e($x->maCDR3VB); ?></td>
                                <td><?php echo e($x->maChuanAbetVB); ?></td>
                                <td>
                                  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#editKQHT_HP_<?php echo e($x->id); ?>">
                                    <i class="fas fa-edit"></i>
                                  </button>
                                </td>
                              </tr>
                            <?php endif; ?>
                          <!-- Modal editing outcome-->
                          <div class="modal fade" id="editKQHT_HP_<?php echo e($x->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                           <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/sua_chuan_dau_ra_mon_hoc')); ?>" method="post">
                          <?php echo csrf_field(); ?>
                          <div class="modal-dialog" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Editing outcomes</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <div class="form-group">
                                  <input type="text" name="id" value="<?php echo e($x->id); ?>" hidden>
                                </div>
                                <div class="form-group">
                                  <input type="text" name="maKQHT" value="<?php echo e($x->maKQHT); ?>" hidden>
                                </div>
                                <div class="form-group">
                                  <input type="text" name="maHocPhan" value="<?php echo e($hocPhan->maHocPhan); ?>" hidden>
                                </div>
                                <div class="form-group">
                                    <label for=""> <?php echo e(_('Studying results ID')); ?>:</label>
                                    <input type="text" name="maKQHTVB" placeholder="L1,L2,..." class="form-control" value="<?php echo e($x->maKQHTVB); ?>">
                                </div>
                                <div class="form-group">
                                  <label for=""> <?php echo e(__('studying results content')); ?>:</label>
                                  <input type="text" name="tenKQHT" placeholder="Ph�n t�ch, kh�i ni&#7879;m, m� t&#7843;,..." class="form-control" value="<?php echo e($x->tenKQHT); ?>">
                                </div>
                                <div class="form-group">
                                  <label for=""> <?php echo e(__('Level-3 outcome')); ?>:</label>
                                  <select name="maCDR3" id="" class="form-control">
                                    <?php $__currentLoopData = $cdr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <?php if($t->maCDR1==$cdr1->maCDR1): ?>
                                            <?php if($t->maCDR3==$x->maCDR3): ?>
                                              <option value="<?php echo e($t->maCDR3); ?>" selected> <?php echo e($t->maCDR3VB); ?> - <?php echo e($t->tenCDR3); ?> </option>
                                            <?php else: ?>
                                              <option value="<?php echo e($t->maCDR3); ?>"> <?php echo e($t->maCDR3VB); ?> - <?php echo e($t->tenCDR3); ?></option> 
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                                </div>

                                <div class="form-group">
                                  <label for="">ABET outcomes:</label>
                                  <select name="maChuanAbet" id="" class="form-control">
                                    <?php $__currentLoopData = $chuan_abet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <option value="<?php echo e($abet->maChuanAbet); ?>"><?php echo e($abet->maChuanAbetVB); ?>--<?php echo e($abet->tenChuanAbet); ?></option>
                                         
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                                </div>
                              </div>
                              <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Save</button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                              </div>
                            </div>
                          </div>
                        </form>
                          
                          </div>
                            <?php endif; ?>
                 
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>

             <h5><b>5. Nội dung môn học: </b></h5>    <!-----------------------------------5.Nội dung môn học: --------------------------->
              <table class="table table-bordered">
                <thead style="background-color: green">
                  <tr>
                    <th rowspan="2">Nội dung
                      <!-- Button trigger modal -->
                      <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addChuong">
                        <i class="fas fa-edit"></i>
                      </button>

                      <!-- Modal thêm nội dung môn học-->
                      <div class="modal fade" id="addChuong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                          <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/them_noi_dung_mon_hoc')); ?>" method="post">
                          <?php echo csrf_field(); ?>
                            <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLabel">Thêm nội dung</h5>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="modal-body">
                              <input type="text" name="maHocPhan" value="<?php echo e($hocPhan->maHocPhan); ?>" hidden>
                              <div class="form-group">
                                <label for="">Tên chương:</label>
                                <input type="text" name="tenchuong" class="form-control" required>
                              </div>
                              <div class="form-group">
                                <label for="">Số tiết lý thuyết:</label>
                                <input type="number" min="0" name="soTietLT" class="form-control" required>
                              </div>
                              <div class="form-group">
                                <label for="">Số tiết thực hành:</label>
                                <input type="number" min="0" name="soTietTH" class="form-control" required>
                              </div>
                              <div class="form-group">
                                <label for="">Số tiết khác:</label>
                                <input type="number" min="0" name="khác" class="form-control" required>
                              </div>
                              <div class="form-group">
                                <label for="">Chọn kết quả học tập:</label>
                                <select name="maKQHT[]" id="" class="form-control" multiple required>
                                  <?php $__currentLoopData = $getKQHT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($data->maKQHT); ?>"><?php echo e($data->maKQHTVB); ?> -- <?php echo e($data->tenKQHT); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                              </div>
                            </div>
                            <div class="modal-footer">
                              <button type="submit" class="btn btn-primary">Save</button>
                              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            </div>
                          </div>
                          </form>
                        
                        </div>
                      </div>

                    </th>
                    <th rowspan="2">Chuẩn đầu ra học phần lý thuyết</th>
                    <th colspan="3"> Số tiết</th>
                  </tr>
                  <tr>
                    <th>Lý thuyết</th>
                    <th>Thực hành</th>
                    <th>Khác</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $noidung; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><b><?php echo e($data->tenchuong); ?></b>
                      
                    <!-- Button thêm mục -->
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addMuc_<?php echo e($data->id); ?>">
                      <i class="fas fa-plus"></i>Adding item
                    </button>


                    <!-- Modal thêm mục -->
                    <div class="modal fade" id="addMuc_<?php echo e($data->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/them_noi_dung_muc_chuong')); ?>" method="POST">
                          <?php echo csrf_field(); ?>
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLabel">Adding a new item</h5>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="modal-body">
                              <input type="text" name="id_chuong" value="<?php echo e($data->id); ?>" hidden>

                              <div class="form-group">
                                <label for="" >Item ID:</label>
                                <input type="text" name="maMucVB" class="form-control" >
                              </div>

                              <div class="form-group">
                                <label for="" >Item name:</label>
                                <input type="text" name="tenMuc" class="form-control" >
                              </div>

                            </div>
                            <div class="modal-footer">
                              <button type="submit" class="btn btn-primary">Save</button>
                              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            </div>
                          </div>
                        </form>
                          
                      </div>
                    </div>

                    
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addMucDoKyNangUIT_<?php echo e($data->id); ?>">
                      <i class="fas fa-plus"></i>Adding level of skill
                    </button>
                    <div class="modal fade" id="addMucDoKyNangUIT_<?php echo e($data->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/them_muc_do_ky_nang_uti')); ?>" method="POST">
                          <?php echo csrf_field(); ?>
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLabel">Adding level of skill</h5>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="modal-body">
                              <input type="text" name="id_chuong" value="<?php echo e($data->id); ?>" hidden>

                              <div class="form-group">
                                <label for="" >Choosing topic:</label>
                                <select name="maCDR1" id="" class="form-control">
                                 <?php $__currentLoopData = $CDR1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cdr1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option value="<?php echo e($cdr1->maCDR1); ?>"><?php echo e($cdr1->tenCDR1); ?></option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                              </div>

                              <div class="form-group">
                                <label for="" >Result assiment:</label>
                                <select name="maKQHT[]" id="" class="form-control" multiple>
                                  <?php $__currentLoopData = $getKQHT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($x->maKQHT); ?>"><?php echo e($x->maKQHTVB); ?>-- <?php echo e($x->tenKQHT); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                              </div>

                              <div class="form-group">
                                <label for="" >Choosing U - I - T:</label>
                                <select name="ky_nang" id="" class="form-control">
                                  <option value="U">U</option>
                                  <option value="I">I</option>
                                  <option value="T">T</option>
                                </select>
                              </div>

                            </div>
                            <div class="modal-footer">
                              <button type="submit" class="btn btn-primary">Save</button>
                              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            </div>
                          </div>
                        </form>
                          
                      </div>
                    </div>
                  </td>
                    <td>
                      <?php $__currentLoopData = $data->chuong_kqht; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php echo e($item->maKQHTVB); ?>;
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td>
                      <?php echo e($data->soTietLT); ?>

                    </td>
                    <td><?php echo e($data->soTietTH); ?></td>
                    <td><?php echo e($data->soTietKhac); ?></td>
                  </tr>
                  <?php $__currentLoopData = $data->muc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td>
                          <?php echo e($m->maMucVB); ?>

                          <?php echo e($m->tenMuc); ?>

                        </td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                      </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <?php $__currentLoopData = $CDR1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                      <td><b>Topic: <?php echo e($x->tenCDR1); ?></b></td>
                      <td colspan="4">
                        <?php $__currentLoopData = $mudokynangUIT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($uit->maCDR1==$x->maCDR1 && $uit->id_chuong==$data->id): ?>
                              <?php echo e($uit->maKQHTVB); ?>(<?php echo e($uit->ky_nang); ?>);
                          <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                      </td>    
                  </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
               
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
              </table>
             <h5><b>6. Phương pháp giảng dạy </b></h5>    <!----------------------------------6. Phương pháp giảng dạy: --------------------------->
             <!-- Button trigger modal -->
              <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#ppgiangday">
                <i class="fas fa-edit"></i>
              </button>

              <!-- Modal thêm phương pháp giảng dạy-->
              <div class="modal fade" id="ppgiangday" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                  <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/them_phuong_phap_giang_day')); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel">Thêm phương pháp giảng dạy</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                      <div class="form-group">
                        <input type="text" name="maHocPhan" value="<?php echo e($hocPhan->maHocPhan); ?>" hidden>
                      </div>
                      <div class="form-group">
                        <label for="">Chọn phương pháp giảng dạy:</label>
                        <select name="maPP" id="" class="form-control">
                          <?php $__currentLoopData = $ppGiangDay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($data->maPP); ?>"><?php echo e($data->tenPP); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                      <div class="form-group">
                        <label for="">Diễn giải:</label>
                        <input type="text" name="dienGiai" class="form-control">
                      </div>
                    </div>
                    <div class="modal-footer">
                      <button type="submit" class="btn btn-primary">Lưu</button>
                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                    </div>
                  </div>
                  </form>
                 
                </div>
              </div>
             <table class="table table-bordered">
               <thead style="background-color: green">
                   <tr>
                     <th>Mã số</th>
                     <th>Phương pháp/ kỹ thuật giảng dạy</th>
                     <th>Diễn giải</th>
                   </tr>
               </thead>
               <tbody>
                 <?php
                     $i=1;
                 ?>
                 <?php $__currentLoopData = $hocPhan_ppGiangDay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                  <td>M <?php echo e($i++); ?></td>
                  <td><?php echo e($data->ppGiangDay->tenPP); ?> </td>
                  <td><?php echo e($data->dienGiai); ?></td>
                </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                 
               </tbody>
             </table>
             <h5><b>7. Phương thức đánh giá </b></h5>    <!----------------------------------7. Phương thức đánh giá: --------------------------->
            
             <!-- Button trigger modal -->
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addHocPhan_loaiHTDG">
              <i class="fas fa-edit"></i>
            </button>

            <!-- Modal thêm hình thức đánh giá -->
            <div class="modal fade" id="addHocPhan_loaiHTDG" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/them_phuong_phap_danh_gia')); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel">Cập nhật phương thức đánh giá</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                      <input type="text" name="maHocPhan" value="<?php echo e($hocPhan->maHocPhan); ?>" hidden>
                      <div class="form-group">
                        <label for="">Chọn hình thức đánh giá</label>
                        <select name="maLoaiHTDG" id="" class="form-control" required>
                          <?php $__currentLoopData = $loaiHTDG; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($data->maLoaiHTDG); ?>"><?php echo e($data->tenLoaiHTDG); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                      <div class="form-group">
                        <label for="">Chọn loại hình thức đánh giá</label>
                        <select name="maLoaiDG" id="" class="form-control" required>
                          <?php $__currentLoopData = $loaiDG; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($data->maLoaiDG); ?>"><?php echo e($data->tenLoaiDG); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                      <div class="form-group">
                        <label for="">Tỉ lệ</label>
                        <input type="number" min="25" name="trongSo" class="form-control" required>
                      </div>
                      <div class="form-group">
                        <label for="">Group</label>
                        <select name="groupCT" id="" class="form-control">
                          <option value="1">1</option>
                          <option value="2">2</option>
                        </select>
                      </div>
                    </div>
                    <div class="modal-footer">
                      <button type="submit" class="btn btn-primary">Save</button>
                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
             <table class="table table-bordered">
              <thead style="background-color: green">
                <th>STT</th>
                <th>Hình thức đánh giá</th>
                <th>Loại hình thức đánh giá</th>
                <th>Tỉ lệ</th>
              </thead>
              <tbody> 
                <?php
                    $i=1;
                ?>
                <?php $__currentLoopData = $hocPhan_loaiHTDG; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($i++); ?></td>
                      <td><?php echo e($data->loai_danh_gia['tenLoaiDG']); ?></td>
                      <td><?php echo e($data->loaiHTDanhGia['maLoaiHTDG']); ?>-<?php echo e($data->loaiHTDanhGia['tenLoaiHTDG']); ?></td>
                      <td><?php echo e($data->trongSo); ?>%</td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              <tr>
                <td colspan="2">Ghi chú công thức tính điểm</td>
                <td colspan="2">
                  <?php
                      $n=$hocPhan_loaiHTDG->where('groupCT',1)->count();
                      $cr=0;
                  ?>
                  <?php $__currentLoopData = $hocPhan_loaiHTDG; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($cr!=0 && $cr<$n && $data->groupCT==1): ?>
                      +
                      <?php
                          $cr++;
                      ?>
                      <?php echo e($data->loaiHTDanhGia['maLoaiHTDG']); ?>*<?php echo e($data->trongSo); ?>%
                  <?php elseif($data->groupCT==1): ?>
                      <?php
                          $cr++;
                      ?>
                      <?php echo e($data->loaiHTDanhGia['maLoaiHTDG']); ?>*<?php echo e($data->trongSo); ?>%
                  <?php endif; ?>
                   
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <br>  hoặc <br>
                  
                  <?php
                  $n=$hocPhan_loaiHTDG->where('groupCT',2)->count();
                  $cr=0;
              ?>
              <?php $__currentLoopData = $hocPhan_loaiHTDG; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($cr!=0 && $cr<$n && $data->groupCT==2): ?>
                  +
                  <?php
                      $cr++;
                  ?>
                  <?php echo e($data->loaiHTDanhGia['maLoaiHTDG']); ?>*<?php echo e($data->trongSo); ?>%
              <?php elseif($data->groupCT==2): ?>
                  <?php
                      $cr++;
                  ?>
                  <?php echo e($data->loaiHTDanhGia['maLoaiHTDG']); ?>*<?php echo e($data->trongSo); ?>%
              <?php endif; ?>
               
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
              </tr>
            </table>


             <h5><b>8. Course requirements and expectations: </b></h5>    <!----------------------------------8. Các quy định chung --------------------------->
             <h6><b>8.1 Requirements on attendance</b></h6>
            <ul>
              <li>Students are responsible for attending all classes. In case of absence due to force majeure circumstances, there must be sufficient and reasonable evidence.</li>
              <li>Students who do not attend more than 20% of the class sections, whether for reason or not, are deemed not to have completed the course and must re-enroll in the following semester.</li>
            </ul>
            <h6><b>8.2 Requirements and expectations on student behaviors </b></h6>
            <ul>
              <li>Students must show their respects for teachers and other learners.</li>
              <li>Students must be on time. Students who are late more than five minutes will not be allowed to attend the class.</li>
              <li>Students should not make noise and interfere with others in the learning process.</li>
              <li>Students should not eat, chew gum, and use devices such as cell phones, music players during class hours.</li>
              <li>Laptops and tablets can only be used in class for the purpose of learning. </li>
              <li>Students who violate the above principles will be asked to leave the class and considered absent from the class. </li>
            </ul>
            <h6><b>8.3 Requirements on learning issues</b></h6>
            <p>Issues related to applying for score reservation, scoring complaints, scoring, exam disciplines are done according to the Learning Regulation of Tra Vinh University.</p>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.no_menu_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abet/domains/abet.ktcn.tvu.edu.vn/public_html/resources/views/admin/hocphan/themdecuong.blade.php ENDPATH**/ ?>