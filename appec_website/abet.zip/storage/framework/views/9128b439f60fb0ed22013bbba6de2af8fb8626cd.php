<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">Nội dung quy hoạch<noscript></noscript>
                            <nav></nav>
                        </h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(asset('giang-vien')); ?>">Trang chủ</a></li>
                            <li class="breadcrumb-item "><a href="#">Đồ án</a></li>
                            <li class="breadcrumb-item "><a href="#">Nội dung đánh giá</a></li>
                            <li class="breadcrumb-item active">Nội dung quy hoạch</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">
                                    <button type="button" class="btn btn-primary" data-toggle="modal"
                                        data-target="#exampleModal">
                                        <i class="fas fa-plus"></i>
                                    </button>
                                    <!-- Modal add -->
                                    <div class="modal fade bd-example-modal-lg" id="exampleModal" tabindex="-1"
                                        role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-lg" role="document">
                                            <form
                                                action="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/noi-dung-quy-hoach/them-noi-dung-quy-hoach-submit')); ?>"
                                                method="POST">
                                                <?php echo csrf_field(); ?>
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Add')); ?>

                                                        </h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <input type="text" name="maCTBaiQH" value="<?php echo e($maCTBaiQH); ?>"
                                                            hidden>
                                                        <div class="form-group">
                                                            <label for="">Chọn kết quả học tập</label>
                                                            <select name="maKQHT" id="" class="form-control">
                                                                <?php
                                                                    $i = 1;
                                                                ?>
                                                                <?php $__currentLoopData = $ketQuaHT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kqht): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($i == 1): ?>
                                                                        <option value="<?php echo e($kqht->maKQHT); ?>" selected>
                                                                            <?php echo e($kqht->maKQHTVB); ?>--<?php echo e($kqht->tenKQHT); ?>

                                                                        </option>
                                                                    <?php else: ?>
                                                                        <option value="<?php echo e($kqht->maKQHT); ?>">
                                                                            <?php echo e($kqht->maKQHTVB); ?>--<?php echo e($kqht->tenKQHT); ?>

                                                                        </option>
                                                                    <?php endif; ?>
                                                                    <?php
                                                                        $i++;
                                                                    ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="">Chọn mức độ đánh giá</label>
                                                            <select name="maMucDoDG" id="" class="form-control">
                                                                <?php
                                                                    $i = 1;
                                                                ?>
                                                                <?php $__currentLoopData = $mucDoDG; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($i == 1): ?>
                                                                        <option value="<?php echo e($md->maMucDoDG); ?>" selected>
                                                                            <?php echo e($md->tenMucDoDG); ?></option>
                                                                    <?php else: ?>
                                                                        <option value="<?php echo e($md->maMucDoDG); ?>">
                                                                            <?php echo e($md->tenMucDoDG); ?></option>
                                                                    <?php endif; ?>
                                                                    <?php
                                                                        $i++;
                                                                    ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="hocphan" style="font-size:20px">Nhập tên nội dung
                                                                quy hoạch</label>
                                                            <!-- Button trigger modal -->
                                                            <input type="text" name="tenNoiDungQH" class="form-control"
                                                                id="" placeholder="Nhập tên nội dung quy hoạch...">
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </h3>
                                <div class="card-tools">
                                    <a href="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/quy-hoach-ket-qua/' . Session::get('maHocPhan') . '/' . Session::get('maBaiQH') . '/' . Session::get('maHK') . '/' . Session::get('namHoc') . '/' . Session::get('maLop'))); ?>"
                                        class="btn btn-secondary"><i class="fas fa-arrow-left"></i></a>
                                </div>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <table id="example2" class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th><?php echo e(__('No.')); ?></th>
                                            <th>Tên nội dung quy hoạch</th>
                                            <th><?php echo e(__('Option')); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $i = 1;
                                        ?>
                                        <?php $__currentLoopData = $noiDungQH; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($i++); ?></td>
                                                <td><?php echo e($nd->tenNoiDungQH); ?></td>
                                                <td>
                                                    <div class="btn-group">
                                                        <!-- Button edit modal -->
                                                        <button type="button" class="btn btn-primary" data-toggle="modal"
                                                            data-target="#edit_<?php echo e($nd->maNoiDungQH); ?>">
                                                            <i class="fas fa-edit"></i>
                                                        </button>
                                                        <a class="btn btn-danger" onclick=" return confirm('Confirm?')"
                                                            href="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/noi-dung-quy-hoach/xoa-noi-dung-quy-hoach/' . $nd->maNoiDungQH)); ?>">
                                                            <i class="fas fa-trash"></i>
                                                        </a>
                                                    </div>
                                                    <!-- Modal edit-->
                                                    <div class="modal fade" id="edit_<?php echo e($nd->maNoiDungQH); ?>"
                                                        tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                                                        aria-hidden="true">
                                                        <div class="modal-dialog" role="document">
                                                            <form
                                                                action="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/noi-dung-quy-hoach/sua-noi-dung-quy-hoach-submit')); ?>"
                                                                method="post">
                                                                <?php echo csrf_field(); ?>
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title" id="exampleModalLabel">
                                                                            <?php echo e(__('Edit')); ?></h5>
                                                                        <button type="button" class="close"
                                                                            data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <input type="text" name="maNoiDungQH"
                                                                            value="<?php echo e($nd->maNoiDungQH); ?>" hidden>
                                                                        <div class="form-group">
                                                                            <label for="">Tên nội dung quy hoạch</label>
                                                                            <input type="text" name="tenNoiDungQH"
                                                                                class="form-control"
                                                                                value="<?php echo e($nd->tenNoiDungQH); ?>" required>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="sumbit"
                                                                            class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                                                        <button type="button" class="btn btn-secondary"
                                                                            data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                                                                    </div>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot>
                                    </tfoot>
                                </table>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('giangvien.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/giangvien/quyhoach/noidungquyhoach.blade.php ENDPATH**/ ?>