
<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">
                            Essay Exam<noscript></noscript>
                            <nav></nav>
                        </h1>
                    </div>
                    
                    <!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(asset('/giang-vien')); ?>"><?php echo e(__('Home')); ?></a>
                            </li>
                            <li class="breadcrumb-item">
                                <a href="#">Essay</a>
                            </li>
                            <li class="breadcrumb-item"><a href="#">Assessment Content</a></li>
                            <li class="breadcrumb-item active">Xem nội dung đánh giá</li>
                        </ol>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class=""></h3>
                                
                                <!-- Button trigger modal -->
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-primary" data-toggle="modal"
                                    data-target="#exampleModal">
                                    <i class="fas fa-plus"></i><?php echo e(__('Adding a new Exam')); ?>

                                </button>
                                <!-- Modal -->
                                <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog"
                                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <form
                                            action="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/noi-dung-danh-gia/them-de-thi-tu-luan-submit')); ?>"
                                            method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e(_('Adding a new exame')); ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="form-group">
                                                        <label for=""><?php echo e(__('Exame ID')); ?></label>
                                                        <input type="text" class="form-control" name="maDeVB" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for=""><?php echo e(__('Title')); ?></label>
                                                        <input type="text" class="form-control" name="tenDe" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for=""><?php echo e(__('Duration')); ?> (<?php echo e(__('minutes')); ?>)</label>
                                                        <input type="number" class="form-control" name="thoiGian" min="30"
                                                            max="180">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for=""><?php echo e(__('The number of question')); ?></label>
                                                        <input type="number" class="form-control" name="soCauHoi" min="1"
                                                            required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for=""><?php echo e(__('Note')); ?></label>
                                                        <input type="text" class="form-control" name="ghiChu">
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                                    <button type="button" class="btn btn-secondary"
                                                        data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>

                            </div>
                            
                            <!-- /.card-header -->
                            <div class="card-body">
                                <table id="example2" class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th><?php echo e(__('No.')); ?></th>
                                            <th><?php echo e(__('Exame ID')); ?></th>
                                            <th><?php echo e(__('Title')); ?></th>
                                            <th><?php echo e(__('Duration')); ?></th>
                                            <th><?php echo e(__('The number of question')); ?></th>
                                            <th><?php echo e(__('Note')); ?></th>
                                            <th><?php echo e(__('Option')); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $i = 1;
                                        ?>
                                        <?php $__currentLoopData = $dethi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($i++); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($data->maDeVB); ?>

                                                </td>
                                                <td><?php echo e($data->tenDe); ?></td>
                                                <td><?php echo e($data->thoiGian); ?> phút</td>
                                                <td><?php echo e($data->soCauHoi); ?></td>
                                                <td><?php echo e($data->ghiChu); ?></td>
                                                <td>
                                                    <div class="btn-group">
                                                        <a href="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/noi-dung-danh-gia/xem-noi-dung-danh-gia/cau-truc-de-tu-luan/' . $data->maDe)); ?>"
                                                            class="btn btn-primary"><i class="fas fa-cogs"></i></a></a>
                                                        <button class="btn btn-danger"><i class="fas fa-trash"></i></button>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot></tfoot>
                                </table>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('giangvien.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/giangvien/quyhoach/noidungdanhgia/tuluan/xemnddanhgiatuluan.blade.php ENDPATH**/ ?>