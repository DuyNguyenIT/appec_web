<h5><b>5. Nội dung môn học: </b></h5>
<!-----------------------------------5.Nội dung môn học: --------------------------->
<table class="table table-bordered">
    <thead style="background-color: green">
        <tr>
            <th rowspan="2"> <?php echo e(__('Course contents')); ?>

                <!-- Button trigger modal -->
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addChuong">
                    <i class="fas fa-plus"></i>
                </button>
                <!-- Modal thêm nội dung môn học-->
                <div class="modal fade" id="addChuong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/them_noi_dung_mon_hoc')); ?>"
                            method="post">
                            <?php echo csrf_field(); ?>
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Add')); ?>/h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <input type="text" name="maHocPhan" value="<?php echo e($hocPhan->maHocPhan); ?>" hidden>
                                    <div class="form-group">
                                        <label for=""><?php echo e(__('Chapter name')); ?>:</label>
                                        <input type="text" name="tenchuong" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Số tiết lý thuyết:</label>
                                        <input type="number" min="0" name="soTietLT" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Số tiết thực hành:</label>
                                        <input type="number" min="0" name="soTietTH" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Số tiết khác:</label>
                                        <input type="number" min="0" name="khác" class="form-control" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="">Chọn kết quả học tập:</label>
                                        <select name="maKQHT[]" id="" class="form-control" multiple required>
                                            <?php $__currentLoopData = $getKQHT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($data->maKQHT); ?>"><?php echo e($data->maKQHTVB); ?> --
                                                    <?php echo e($data->tenKQHT); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary">Save</button>
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </th>
            <th rowspan="2">Chuẩn đầu ra học phần lý thuyết</th>
            <th colspan="3"> <?php echo e(__('Number of learning periods')); ?></th>
        </tr>
        <tr>
            <th><?php echo e(__('Theory')); ?></th>
            <th><?php echo e(__('Practice')); ?></th>
            <th><?php echo e(__('Others')); ?></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $noidung; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><b><?php echo e($data->tenchuong); ?></b>
                    <!-- Button thêm mục -->
                    <button type="button" class="btn btn-primary" data-toggle="modal"
                        data-target="#addMuc_<?php echo e($data->id); ?>">
                        <i class="fas fa-plus"></i>Adding item
                    </button>

                    <!-- Modal thêm mục -->
                    <div class="modal fade" id="addMuc_<?php echo e($data->id); ?>" tabindex="-1" role="dialog"
                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/them_noi_dung_muc_chuong')); ?>"
                                method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Adding a new item</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="text" name="id_chuong" value="<?php echo e($data->id); ?>" hidden>
                                        <div class="form-group">
                                            <label for="">Item ID:</label>
                                            <input type="text" name="maMucVB" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="">Item name:</label>
                                            <input type="text" name="tenMuc" class="form-control">
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                        <button type="button" class="btn btn-secondary"
                                            data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <button type="button" class="btn btn-primary" data-toggle="modal"
                        data-target="#addMucDoKyNangUIT_<?php echo e($data->id); ?>">
                        <i class="fas fa-plus"></i>Adding level of skill
                    </button>
                    <div class="modal fade" id="addMucDoKyNangUIT_<?php echo e($data->id); ?>" tabindex="-1" role="dialog"
                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/them_muc_do_ky_nang_uti')); ?>"
                                method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Adding level of skill</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="text" name="id_chuong" value="<?php echo e($data->id); ?>" hidden>
                                        <div class="form-group">
                                            <label for="">Choosing topic:</label>
                                            <select name="maCDR1" id="" class="form-control">
                                                <?php $__currentLoopData = $CDR1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cdr1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($cdr1->maCDR1); ?>"><?php echo e($cdr1->tenCDR1); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="">Result assiment:</label>
                                            <select name="maKQHT[]" id="" class="form-control" multiple>
                                                <?php $__currentLoopData = $getKQHT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($x->maKQHT); ?>"><?php echo e($x->maKQHTVB); ?>--
                                                        <?php echo e($x->tenKQHT); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="">Choosing U - I - T:</label>
                                            <select name="ky_nang" id="" class="form-control">
                                                <option value="U">U</option>
                                                <option value="I">I</option>
                                                <option value="T">T</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                        <button type="button" class="btn btn-secondary"
                                            data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </td>
                <td>
                    <?php $__currentLoopData = $data->chuong_kqht; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($item->maKQHTVB); ?>;
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <?php echo e($data->soTietLT); ?>

                </td>
                <td><?php echo e($data->soTietTH); ?></td>
                <td><?php echo e($data->soTietKhac); ?></td>
            </tr>
            <?php $__currentLoopData = $data->muc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($m->maMucVB); ?>

                        <?php echo e($m->tenMuc); ?>

                    </td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $CDR1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><b><?php echo e(__('Topic')); ?>: <?php echo e($x->tenCDR1); ?></b></td>
                    <td colspan="4">
                        <?php $__currentLoopData = $mudokynangUIT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($uit->maCDR1 == $x->maCDR1 && $uit->id_chuong == $data->id): ?>
                                <?php echo e($uit->maKQHTVB); ?>(<?php echo e($uit->ky_nang); ?>);
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/admin/hocphan/noidungdecuong/5_noidungmonhoc.blade.php ENDPATH**/ ?>