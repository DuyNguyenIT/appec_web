
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">
                            <?php echo e(__('Students list')); ?><noscript></noscript>
                            <nav></nav>
                        </h1>
                    </div>
                    <!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(asset('/giao-vu')); ?>"><?php echo e(__('Home')); ?></a></li>
                            <li class="breadcrumb-item">
                                <?php echo e($hocphan->tenHocPhan); ?>  - <?php echo e($maHK); ?> - Nam
                            </li>
                            <li class="breadcrumb-item active"><?php echo e(__('Students list')); ?></li>
                        </ol>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <!-- /.content-header -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">
                                    <?php echo e(__('Course')); ?>: <?php echo e($hocphan->tenHocPhan); ?> 
                                    <br><?php echo e(__('Semester')); ?>: <?php echo e($maHK); ?>

                                </h3>
                                <div class="card-tools">
                                    <a href="<?php echo e(asset('/giao-vu/hoc-phan-giang-day')); ?>" class="btn btn-secondary"><i
                                            class="fas fa-arrow-left"></i></a>
                                </div>
                            </div>
                            <div class="card-header">
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-primary" data-toggle="modal"
                                    data-target="#importExcel">
                                    <?php echo e(__('Import excel')); ?>

                                </button>
                                <a href="<?php echo e(asset('/giao-vu/hoc-phan-giang-day/tai-file-mau')); ?>"><?php echo e(__('Template file excel')); ?></a>
                                <!-- Modal -->
                                <div class="modal fade" id="importExcel" tabindex="-1" role="dialog"
                                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <form
                                            action="<?php echo e(asset('/giao-vu/hoc-phan-giang-day/cap-nhat-ds-sinh-vien-bang-excel')); ?>"
                                            enctype="multipart/form-data" method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Import excel')); ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="form-group">
                                                        <input type="file" name="file" id="" class="form-control">
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                                    <button type="button" class="btn btn-secondary"
                                                        data-dismiss="modal"><?php echo e(__('Close')); ?></button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <table id="example2" class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th><?php echo e(__('No.')); ?></th>
                                            <th><?php echo e(__('Student ID')); ?></th>
                                            <th><?php echo e(__('Student name')); ?></th>
                                            <th><?php echo e(__('Class')); ?></th>
                                            <th><?php echo e(__('Option')); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $i = 1;
                                        ?>
                                        <?php $__currentLoopData = $dssv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($i++); ?></td>
                                                <td><?php echo e($sv->maSSV); ?></td>
                                                <td><?php echo e($sv->sinhvien->HoSV); ?> <?php echo e($sv->sinhvien->TenSV); ?></td>
                                                <td><?php echo e($sv->sinhvien->maLop); ?></td>
                                                <td>
                                                    
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot></tfoot>
                                </table>
                            </div>
                            <!-- /.card-body -->
                        </div>
                        <!-- /.card -->
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('giaovu.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/giaovu/hocphan/danhsachSV.blade.php ENDPATH**/ ?>