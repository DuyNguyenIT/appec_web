<h5><b>6. Phương pháp giảng dạy </b></h5>
<!----------------------------------6. Phương pháp giảng dạy: --------------------------->
<!-- Button trigger modal -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#ppgiangday">
    <i class="fas fa-edit"></i>
</button>
<!-- Modal thêm phương pháp giảng dạy-->
<div class="modal fade" id="ppgiangday" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/them_phuong_phap_giang_day')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Thêm phương pháp giảng dạy</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <input type="text" name="maHocPhan" value="<?php echo e($hocPhan->maHocPhan); ?>" hidden>
                    </div>
                    <div class="form-group">
                        <label for="">Chọn phương pháp giảng dạy:</label>
                        <select name="maPP" id="" class="form-control">
                            <?php $__currentLoopData = $ppGiangDay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->maPP); ?>"><?php echo e($data->tenPP); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Diễn giải:</label>
                        <input type="text" name="dienGiai" class="form-control">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Lưu</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Hủy</button>
                </div>
            </div>
        </form>
    </div>
</div>
<table class="table table-bordered">
    <thead style="background-color: green">
        <tr>
            <th>Mã số</th>
            <th>Phương pháp/ kỹ thuật giảng dạy</th>
            <th>Diễn giải</th>
        </tr>
    </thead>
    <tbody>
        <?php
            $i = 1;
        ?>
        <?php $__currentLoopData = $hocPhan_ppGiangDay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>M <?php echo e($i++); ?></td>
                <td><?php echo e($data->ppGiangDay->tenPP); ?> </td>
                <td><?php echo e($data->dienGiai); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
</table>
<?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/admin/hocphan/noidungdecuong/6_phuongphapgiangday.blade.php ENDPATH**/ ?>