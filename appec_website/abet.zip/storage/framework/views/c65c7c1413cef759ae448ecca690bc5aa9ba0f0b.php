
<?php $__env->startSection('content'); ?>
    <!-- jQuery -->
    <script src="<?php echo e(asset('plugins/jquery/jquery.min.js')); ?>"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="<?php echo e(asset('plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
    <div class="content-wrapper" style="min-height: 96px;">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">
                            Cấu trúc đề thi<noscript></noscript>
                            <nav></nav>
                        </h1>
                    </div>
                    <!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(asset('gian-vien')); ?>">Trang chủ</a></li>
                            <li class="breadcrumb-item "><a href="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia')); ?>">Nội dung
                                    đánh giá</a></li>
                            <li class="breadcrumb-item "><a href="#"></a> Thực hành</li>
                            <li class="breadcrumb-item active">Cấu trúc đề thi</li>
                        </ol>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                           
                            <div class="card-header">
                                <div class="row">
                                    <div class="col-md-5">
                                        <b>Trường: </b>Đại học Trà Vinh <br>
                                        <b>Lớp:</b>......................... <br>
                                        <b>Họ và tên:</b>...................
                                    </div>
                                    <div class="col-md-2"></div>
                                    <div class="col-md-5">
                                        KHOA KỸ THUẬT VÀ CÔNG NGHỆ <br>
                                        <b><?php echo e($dethi->tenDe); ?></b><br>
                                        <b>Học phần:</b> <?php echo e($hocphan->tenHocPhan); ?> <br>
                                        <b>Thời gian thi:</b> <?php echo e($dethi->thoiGian); ?> phút <br>
                                        <b>Mã đề:</b> <?php echo e($dethi->maDeVB); ?>

                                    </div>
                                </div>
                                <h3 class="card-title"></h3>
                                <i> <?php echo e($dethi->ghiChu); ?></i>
                            </div>
                            <div class="card-tools">
                                
                                <a href="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/noi-dung-danh-gia/xem-noi-dung-danh-gia/' . Session::get('maCTBaiQH'))); ?>"
                                class="btn btn-secondary"><i class="fas fa-arrow-left"></i></a>
                            </div>
                            <div class="card-body">
                                <?php
                                    $i = 1;
                                ?>
                                <?php $__currentLoopData = $noidung; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a title="Delete" class="btn btn-danger"
                                onclick="return confirm('Do you want to delete this question?')"
                                href="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/noi-dung-danh-gia/xem-noi-dung-danh-gia/xoa-cau-hoi-de-thuc-hanh/' . $dethi->maDe . '/' . $data->maCauHoi)); ?>"><i
                                    class="fa fa-trash"></i></a>
                                    <b>Câu </b> <?php echo e($i++); ?> <b>(<?php echo e($data->diem); ?>điểm)</b>
                                   
                                    <?php echo $data->noiDungCauHoi; ?>

                                    <div class="card" style="background-color: rgb(166, 243, 239); display:float">
                                        <div class="card-header">
                                            <div class="card-title">
                                                Phương án trả lời:
                                            </div>
                                            <div class="card-tools">
                                                <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                                                  <i class="fas fa-minus"></i>
                                                </button>
                                                <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                                                  <i class="fas fa-times"></i>
                                                </button>
                                              </div>
                                        </div>
                                        
                                        <div class="card-body">
                                            <?php for($k = 0; $k < count($data->phuongAn); $k++): ?>
                                            [<?php echo e($k + 1); ?>] (<?php echo e($data->phuongAn[$k]->diemPA); ?>

                                            điểm)(ABET:<?php echo e($data->phuongAn[$k]->maChuanAbetVB); ?>)(CDR3:<?php echo e($data->phuongAn[$k]->maCDR3VB); ?>):
                                            <button type="button" class="btn btn-success" data-toggle="modal"
                                                data-target="#editPA_<?php echo e($data->phuongAn[$k]->id); ?>">
                                                <li class="fas fa-edit"></li>
                                            </button>
                                            <?php echo $data->phuongAn[$k]->noiDungPA; ?>

                                            <!-- Modal -->
                                            <div class="modal fade" id="editPA_<?php echo e($data->phuongAn[$k]->id); ?>"
                                                tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                                                aria-hidden="true">
                                                <div class="modal-dialog modal-lg" role="document">
                                                    <form
                                                        action="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/noi-dung-danh-gia/xem-noi-dung-danh-gia/sua-phuong-an-thuc-hanh')); ?>"
                                                        method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">Chỉnh sửa
                                                                    phương án</h5>
                                                                <button type="button" class="close" data-dismiss="modal"
                                                                    aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="form-group">
                                                                    <input type="text" name="id"
                                                                        value="<?php echo e($data->phuongAn[$k]->id); ?>" hidden>
                                                                </div>
                                                                <div class="form-group">
                                                                    <textarea name="noiDungPA"
                                                                        id="edit_PA_<?php echo e($data->phuongAn[$k]->id); ?>"
                                                                        cols="30" rows="10">
                                              <?php echo $data->phuongAn[$k]->noiDungPA; ?>

                                              </textarea>
                                                                    <script>
                                                                        CKEDITOR.replace("edit_PA_" +
                                                                            <?php echo e($data->phuongAn[$k]->id); ?>, {
                                                                                filebrowserUploadUrl: "<?php echo e(route('upload', ['_token' => csrf_token()])); ?>",
                                                                                filebrowserUploadMethod: 'form'
                                                                            });

                                                                    </script>
                                                                </div>
                                                                <div class="from-group">
                                                                    <label for="">chọn chuẩn đầu ra abet:</label>
                                                                    <select name="maChuanAbet" id="" class="form-control">
                                                                        <?php $__currentLoopData = $abet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php if($data->phuongAn[$k]->maChuanAbet == $ab->maChuanAbet): ?>
                                                                                <option value="<?php echo e($ab->maChuanAbet); ?>"
                                                                                    selected>
                                                                                    <?php echo e($ab->maChuanAbetVB); ?>--<?php echo e($ab->tenChuanAbet); ?>

                                                                                </option>
                                                                            <?php else: ?>
                                                                                <option value="<?php echo e($ab->maChuanAbet); ?>">
                                                                                    <?php echo e($ab->maChuanAbetVB); ?>--<?php echo e($ab->tenChuanAbet); ?>

                                                                                </option>
                                                                            <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="">Điểm phương án</label>
                                                                    <input type="text" name="diemPA"
                                                                        value="<?php echo e($data->phuongAn[$k]->diemPA); ?>"
                                                                        class="form-control">
                                                                </div>
                                                                <div class="from-group">
                                                                    <label for="">chọn chuẩn đầu ra 3:</label>
                                                                    <select name="maCDR3" id="" class="form-control">
                                                                        <?php $__currentLoopData = $cdr3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php if($data->phuongAn[$k]->maCDR3 == $cd->maCDR3): ?>
                                                                                <option value="<?php echo e($cd->maCDR3); ?>"
                                                                                    selected>
                                                                                    <?php echo e($cd->maCDR3VB); ?>--<?php echo e($cd->tenCDR3); ?>

                                                                                </option>
                                                                            <?php else: ?>
                                                                                <option value="<?php echo e($cd->maCDR3); ?>">
                                                                                    <?php echo e($cd->maCDR3VB); ?>--<?php echo e($cd->tenCDR3); ?>

                                                                                </option>
                                                                            <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="submit" class="btn btn-primary">Save</button>
                                                                <button type="button" class="btn btn-secondary"
                                                                    data-dismiss="modal">Cancel</button>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        <?php endfor; ?>
                                        </div>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="card-footer">
                                <?php if($dem_cau_hoi < $dethi->soCauHoi): ?>
                                    <span style="color: red">*Hiện có: <?php echo e($dem_cau_hoi); ?>/<?php echo e($dethi->soCauHoi); ?> Câu
                                        hỏi</span>
                                <?php else: ?>
                                    <span style="color: green">Đã đủ: <?php echo e($dem_cau_hoi); ?>/<?php echo e($dethi->soCauHoi); ?> Câu
                                        hỏi</span>
                                <?php endif; ?>
                            </div>
                        </div>

                  <!-- /.card -->
                        <div class="card card-info card-outline">
                            <div class="card-body">
                                <h5 class="card-title">
                                    <h3><?php echo e(__('Questions list')); ?></h3>
                                </h5>
                                <p class="card-text">
                                    <!-- /.card-header -->
                                <div class="card-body" style="background-color: whitesmoke">
                                    <form
                                        action="<?php echo e(asset('/giang-vien/quy-hoach-danh-gia/noi-dung-danh-gia/xem-noi-dung-danh-gia/them-cau-hoi-de-thuc-hanh')); ?>"
                                        method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="text" name="maDe" value="<?php echo e($dethi->maDe); ?>" hidden>
                                        <div class="form-group">
                                            <label for=""><?php echo e(__('SOs')); ?>:</label>
                                            <select name="maCDR3" id="" class="form-control" required>
                                                <?php $__currentLoopData = $cdr3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($data->maCDR3); ?>">
                                                        <?php echo e($data->maCDR3VB); ?>--<?php echo e($data->tenCDR3); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for=""><?php echo e(__("ABET's SO")); ?>:</label>
                                            <select name="maChuanAbet" id="" class="form-control">
                                                <?php $__currentLoopData = $abet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($ab->maChuanAbet); ?>">
                                                        <?php echo e($ab->maChuanAbetVB); ?>--<?php echo e($ab->tenChuanAbet); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for=""><?php echo e(__('Chapter')); ?></label>
                                            <select name="maChuong" id="chuong" class="form-control">
                                                <option value="-1"><?php echo e(__('All')); ?></option>
                                                <?php $__currentLoopData = $chuong; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($chg->id); ?>"><?php echo e($chg->tenchuong); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for=""><?php echo e(__('Items')); ?></label>
                                            <select name="maMuc" id="muc" class="form-control">
                                                <option value="-1"><?php echo e(__('All')); ?></option>
                                                <?php $__currentLoopData = $muc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($m->id); ?>"><?php echo e($m->maMucVB); ?>: <?php echo e($m->tenMuc); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>  <?php echo e(__('Questions list')); ?></label>
                                            <table id="example2" class="table table-bordered table-hover">
                                                <thead>
                                                    <tr>
                                                        <th><?php echo e(__('No.')); ?></th>
                                                        <th><?php echo e(__('Question')); ?></th>
                                                        <th><?php echo e(__('Choise')); ?></th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                        $i = 1;
                                                    ?>
                                                    <?php $__currentLoopData = $cauhoi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($i++); ?></td>
                                                            <td><?php echo $item->noiDungCauHoi; ?></td>
                                                            <td>
                                                                <input type="radio" id="ch_<?php echo e($item->maCauHoi); ?>"
                                                                    name="maCauHoi" value="<?php echo e($item->maCauHoi); ?>">
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                                <tfoot></tfoot>
                                            </table>
                                        </div>
                                        <div class="form-group">
                                            <div class="form-group">
                                                <label for="">Chọn số ý trả lời:</label>
                                                <select name="" id="soTC" class="form-control">
                                                    <option value="1">1</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="4">4</option>
                                                    <option value="5">5</option>
                                                    <option value="6">6</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div id="tbl-content">
                                                <div class='form-group'>"
                                                    <label for=''>Nhập nội dung ý:</label>
                                                    <textarea name='phuongAn[]' id='ckcontent_1' cols='30' rows='10'
                                                        class='form-control' required></textarea>
                                                    <label for=''>Nhập điểm</label>
                                                    <input type='text' name='diem[]' class='form-control'>
                                                </div>
                                                <script>
                                                    CKEDITOR.replace('ckcontent_1', {
                                                        filebrowserUploadUrl: "<?php echo e(route('uploadgv', ['_token' => csrf_token()])); ?>",
                                                        filebrowserUploadMethod: 'form'
                                                    });

                                                </script>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <button class="btn btn-primary" type="submit"><?php echo e(__("Save")); ?></button>
                                            <button class="btn btn-info" type="reset"><?php echo e(__('Cancel')); ?></button>
                                        </div>
                                    </form>
                                </div>
                                <!-- /.card-body -->
                                </p>
                            </div>
                        </div><!-- /.card -->

                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <script>
        //số ý
        $('#soTC').on('change', function() {
            var soTC = this.value;
            console.log(soTC);
            var html = "";
            $('#tbl-content').empty();
            for (let index = 1; index <= soTC; index++) {
                html += "<div class='form-group'>" +
                    "<label for=''>Nhập nội dung ý:</label>" +
                    "<textarea name='phuongAn[]' id='ckcontent_" + index +
                    "' cols='30' rows='10' class='form-control' required></textarea>" +
                    "<label for=''>Nhập điểm</label>" +
                    "<input type='text' name='diem[]' class='form-control'>" +
                    "</div>";
            }
            console.log(html);
            $('#tbl-content').append(html);
            for (let index = 1; index <= soTC; index++) {
                CKEDITOR.replace('ckcontent_' + index, {
                    filebrowserUploadUrl: "<?php echo e(route('uploadgv', ['_token' => csrf_token()])); ?>",
                    filebrowserUploadMethod: 'form'
                });
            }
        });
        //function chuong
        $('#chuong').change(function() {
            $('select[id="from_box"]').empty();
            var ajaxurl = '/giang-vien/hoc-phan/chuong/muc/get-muc-by-machuong/' + $(this).val();
            $.ajax({
                type: 'get',
                url: ajaxurl,
                success: function(rsp) {
                    var option = "<option value='-1'>All</option>";
                    rsp.forEach(element => {
                        option += "<option value='" + element['id'] + "'>" + element[
                            'maMucVB'] + "--" + element['tenMuc'] + "</option>";
                    });
                    $('#muc').empty();
                    $('#muc').append(option);
                },
                error: function(rsp) {
                    console.log(rsp);
                }
            });
        })
        //function muc
        $('#muc').change(function() {
            var muc_url = '/giang-vien/hoc-phan/chuong/muc/get-cau-hoi-thuc-hanh-by-mamuc/' + $(this).val();
            $.ajax({
                type: 'get',
                url: muc_url,
                success: function(rsp) {
                    
                    var table_content = "";
                    var $i=1;
                    rsp.forEach(element => {
                        table_content+= "<tr><td>"+$i+"</td>"+
                            "<td>"+element['noiDungCauHoi']+"</td>"+
                            "<td>"+
                               "   <input type='radio' id='ch_"+element['maCauHoi']+"'"+                             
                                    "name='maCauHoi' value='"+element['maCauHoi']+"'>"+
                            "</td></tr>" ; 
                        $i+=1;  
                    });
                    console.log(table_content);
                    $('table[id="example2"]').children('tbody').empty();
                    $('table[id="example2"]').children('tbody').append(table_content);
                   
                    
                },
                error: function(rsp) {
                    console.log(rsp);
                }
            });
        })

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('giangvien.no_menu_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/giangvien/quyhoach/noidungdanhgia/thuchanh/cautrucde.blade.php ENDPATH**/ ?>