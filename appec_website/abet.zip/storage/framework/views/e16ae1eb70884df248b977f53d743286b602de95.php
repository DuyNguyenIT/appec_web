<h5><b>4.<?php echo e(__('Course learning outcomes')); ?></b></h5>
<!-----------------------------------4. chuẩn đầu ra của môn học--------------------------->
<table class="table table-bordered">
    <thead>
        <th colspan="2"></th>
        <th style="background-color: green"><?php echo e(__('Satisfy LOs of the program')); ?></th>
        <th style="background-color: green"><?php echo e(__('Satisfy Abet')); ?></th>
        <th style="background-color: green"><?php echo e(__('Option')); ?></th>
    </thead>
    <tbody>
        <?php $__currentLoopData = $CDR1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cdr1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td colspan="3">
                    <!-- Button trigger modal -->
                    <button type="button" class="btn btn-primary" data-toggle="modal"
                        data-target="#chuDe_<?php echo e($cdr1->maCDR1VB); ?>">
                        <i class="fas fa-plus"></i>
                    </button>
                    <b><?php echo e(__('Topic')); ?> <?php echo e($cdr1->maCDR1VB); ?>: <?php echo e($cdr1->tenCDR1); ?>:</b>
                    <!-- /////////////////// Modal them noi dung mon hoc-->
                    <div class="modal fade" id="chuDe_<?php echo e($cdr1->maCDR1VB); ?>" tabindex="-1" role="dialog"
                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/them_chuan_dau_ra_mon_hoc')); ?>"
                                method="post">
                                <?php echo csrf_field(); ?>
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Topic')); ?>

                                            <?php echo e($cdr1->maCDR1VB); ?>: <?php echo e($cdr1->tenCDR1); ?></h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <input type="text" name="maHocPhan" value="<?php echo e($hocPhan->maHocPhan); ?>"
                                                hidden>
                                        </div>
                                        <div class="form-group">
                                            <label for=""> <?php echo e(_('Studying results ID')); ?>:</label>
                                            <input type="text" name="maKQHTVB" placeholder="" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for=""> <?php echo e(__('studying results content')); ?>:</label>
                                            <input type="text" name="tenKQHT" id="add_tenKQHT" placeholder="" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for=""> <?php echo e(__('Level-3 outcome')); ?>:</label>
                                            <select name="maCDR3[]" id="" class="form-control select-item" multiple >
                                                <?php $__currentLoopData = $cdr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($t->maCDR1 == $cdr1->maCDR1): ?>
                                                        <option value="<?php echo e($t->maCDR3); ?>" > <?php echo e($t->maCDR3VB); ?> -
                                                            <?php echo e($t->tenCDR3); ?></option>
                                                    <?php endif; ?>
                                                    <?php if($cdr1->maCDR1 == '1' && $t->maCDR1 == '4'): ?>
                                                        <option value="<?php echo e($t->maCDR3); ?>"> <?php echo e($t->maCDR3VB); ?> -
                                                            <?php echo e($t->tenCDR3); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                                        <button type="button" class="btn btn-secondary"
                                            data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </td>
            </tr>
            <?php
                $cur_rs = 0;
                $bienchay = 0;
            ?>
            <?php $__currentLoopData = $kqht; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($x->maCDR1 == $cdr1->maCDR1): ?>
                    <?php
                        $rs = $kqht
                            ->where('maCDR1', $cdr1->maCDR1)
                            ->where('maKQHT', $x->maKQHT)
                            ->count();
                        
                        if ($bienchay >= $rs || $rs > $cur_rs) {
                            $cur_rs = $rs;
                            $bienchay = 1;
                        } else {
                            $bienchay += 1;
                        }
                    ?>
                    <?php if($bienchay == 1): ?>
                        <tr>
                            <td rowspan=<?php echo e($rs); ?>><?php echo e($x->maKQHTVB); ?></td>
                            <td rowspan=<?php echo e($rs); ?>>
                                <a title="Delete" class="btn btn-danger"
                                    onclick="return confirm('Confirm?')"
                                    href="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/xoa-ket-qua-hoc-tap-mon-hoc/'.$x->maKQHT)); ?>">
                                    <i class="fa fa-trash"></i>
                                </a>
                                <?php echo e($x->tenKQHT); ?>

                              
                            </td>
                            <td><?php echo e($x->maCDR3VB); ?></td>
                            <td><?php echo e($x->maChuanAbetVB); ?></td>
                            <td>
                                <button type="button" class="btn btn-primary" data-toggle="modal"
                                    data-target="#editKQHT_HP_<?php echo e($x->id); ?>">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </td>
                        </tr>
                    <?php else: ?>
                        <tr>
                            <td><?php echo e($x->maCDR3VB); ?></td>
                            <td><?php echo e($x->maChuanAbetVB); ?></td>
                            <td>
                                <button type="button" class="btn btn-primary" data-toggle="modal"
                                    data-target="#editKQHT_HP_<?php echo e($x->id); ?>">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </td>
                        </tr>
                    <?php endif; ?>
                    <!-- Modal editing outcome-->
                    <div class="modal fade" id="editKQHT_HP_<?php echo e($x->id); ?>" tabindex="-1" role="dialog"
                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <form action="<?php echo e(asset('/quan-ly/hoc-phan/de-cuong-mon-hoc/sua_chuan_dau_ra_mon_hoc')); ?>"
                            method="post">
                            <?php echo csrf_field(); ?>
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Editing outcomes</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <input type="text" name="id" value="<?php echo e($x->id); ?>" hidden>
                                        </div>
                                        <div class="form-group">
                                            <input type="text" name="maKQHT" value="<?php echo e($x->maKQHT); ?>" hidden>
                                        </div>
                                        <div class="form-group">
                                            <input type="text" name="maHocPhan" value="<?php echo e($hocPhan->maHocPhan); ?>"
                                                hidden>
                                        </div>
                                        <div class="form-group">
                                            <label for=""> <?php echo e(_('Studying results ID')); ?>:</label>
                                            <input type="text" name="maKQHTVB" placeholder="L1,L2,..."
                                                class="form-control" value="<?php echo e($x->maKQHTVB); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label for=""> <?php echo e(__('studying results content')); ?>:</label>
                                            <input type="text" name="tenKQHT" placeholder="" class="form-control"
                                                value="<?php echo e($x->tenKQHT); ?>" id="tenKQHT">
                                        </div>
                                        <div class="form-group">
                                            <label for=""> <?php echo e(__('Level-3 outcome')); ?>:</label>
                                            <select name="maCDR3" id="" class="form-control" >
                                                <?php $__currentLoopData = $cdr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($t->maCDR1 == $cdr1->maCDR1): ?>
                                                        <?php if($t->maCDR3 == $x->maCDR3): ?>
                                                            <option value="<?php echo e($t->maCDR3); ?>" selected>
                                                                <?php echo e($t->maCDR3VB); ?> - <?php echo e($t->tenCDR3); ?> </option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($t->maCDR3); ?>"> <?php echo e($t->maCDR3VB); ?>

                                                                - <?php echo e($t->tenCDR3); ?></option>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-primary">Save</button>
                                        <button type="button" class="btn btn-secondary"
                                            data-dismiss="modal">Cancel</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<script>
   $('.select-item').click(function() {
            var price = '';
            $('option:selected', $(this)).each(function() {
                console.log($(this).text());
                price += $(this).text();
            });
            $('#add_tenKQHT').text(price);
        });
</script><?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/admin/hocphan/noidungdecuong/4_chuandaura.blade.php ENDPATH**/ ?>