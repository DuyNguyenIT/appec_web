
<?php $__env->startSection('content'); ?>
<script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
<div class="content-wrapper" style="min-height: 96px;">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0 text-dark">
            Câu hỏi tự luận<noscript></noscript>
            <nav></nav>
          </h1>
        </div>
        <!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(asset('/')); ?>">Trang chủ</a></li>
            <li class="breadcrumb-item">
              <a href="<?php echo e(asset('/giang-vien/hoc-phan')); ?>">
                <?php echo e(\Illuminate\Support\Str::limit(html_entity_decode($hocphan->tenHocPhan),$limit=20,$end='...')); ?>  
              </a>
            </li>
            <li class="breadcrumb-item ">
              <a href="<?php echo e(asset('/giang-vien/hoc-phan/chuong/'.Session::get('maHocPhan_chuong'))); ?>">
                <?php echo e(\Illuminate\Support\Str::limit(html_entity_decode($chuong->tenchuong),$limit=20,$end='...')); ?>  
              </a>
            </li><li class="breadcrumb-item"><a href="#">    
              <a href="<?php echo e(asset('/giang-vien/hoc-phan/chuong/muc/'.Session::get('maMuc'))); ?>">
              <?php echo e(\Illuminate\Support\Str::limit(html_entity_decode($muc->tenMuc),$limit=20,$end='...')); ?>  
            </a></a></li>
            <li class="breadcrumb-item active">Câu hỏi tự luận</li>
          </ol>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->

  <?php if(session('success')): ?>
  <div class="alert alert-success alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
    <h5><i class="icon fas fa-check"></i> Thông báo!</h5>
    <?php echo e(session('success')); ?>

  </div>
<?php endif; ?>
<?php if(session('warning')): ?>
  <div class="alert alert-warning alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
    <h5><i class="icon fas fa-exclamation-triangle"></i> Thông báo!</h5>
    <?php echo e(session('warning')); ?>

  </div>
<?php endif; ?>
  <!-- Main content -->

  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title"></h3>
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                  <i class="fas fa-plus"></i>
                  
              </button>

                <!-- Modal -->
                <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog modal-lg" role="document">
                    <form action="<?php echo e(asset('/giang-vien/hoc-phan/chuong/muc/cau-hoi-tu-luan/them')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Thêm câu hỏi tự luận </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">×</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <input type="text" name="maChuong" value="<?php echo e($chuong->id); ?>" id="" hidden>
                          <div class="form-group">
                            <label for="">Nhập nội dung câu hỏi:</label>
                            <textarea name="noiDungCauHoi" id="ckcontent" cols="30" rows="10" class="form-control" required></textarea>
                              <script>
                                CKEDITOR.replace( 'ckcontent', {
                                    filebrowserUploadUrl: "<?php echo e(route('uploadgv', ['_token' => csrf_token() ])); ?>",
                                    filebrowserUploadMethod: 'form'
                                } );
                            </script>
                          </div>
                         
                          <div class="form-group">
                            <label for=""> Đáp ứng kết quả học tập:</label>
                            <select name="maKQHT" id="" class="form-control" required>
                              <?php $__currentLoopData = $kqht; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($x->maKQHT); ?>"><?php echo e($x->maKQHTVB); ?>-<?php echo e($x->tenKQHT); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </div>

                      </div>
                      <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Lưu</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
                      </div>
                    </div>
                    </form>
                      
                </div>
            </div>

               
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                  <tr>
                    <th>STT</th>
                    <th>Nội dung câu hỏi</th>
                    <th>Tùy chọn</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                      $i=1;
                  ?>
                  <?php $__currentLoopData = $cauhoi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                       <td><?php echo e($i++); ?></td>
                       <td><?php echo html_entity_decode($x->noiDungCauHoi); ?></td>
                       <td>
                         <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#edit_<?php echo e($x->maCauHoi); ?>">
                          <li class="fas fa-edit"></li>
                        </button>

                        <!-- Modal -->
                        <div class="modal fade" id="edit_<?php echo e($x->maCauHoi); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                          <div class="modal-dialog modal-lg" role="document">
                            <form action="<?php echo e(asset('/giang-vien/hoc-phan/chuong/muc/cau-hoi-tu-luan/sua')); ?>" method="post">
                              <?php echo csrf_field(); ?>
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h5 class="modal-title" id="exampleModalLabel">Sửa nội dung câu hỏi</h5>
                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                  </button>
                                </div>
                                <div class="modal-body">
                                  <input type="text" name="maChuong" value="<?php echo e($chuong->id); ?>" id="" hidden>
                                  <input type="text" name="maCauHoi" value="<?php echo e($x->maCauHoi); ?>" id="" hidden>
                                  <div class="form-group">
                                    <label for="">Nhập nội dung câu hỏi:</label>
                                    <textarea name="noiDungCauHoi" id="ckcontent_<?php echo e($x->maCauHoi); ?>" cols="30" rows="10" class="form-control" required>
                                      <?php echo e($x->noiDungCauHoi); ?>

                                    </textarea>
                                      <script>
                                        CKEDITOR.replace( 'ckcontent_<?php echo e($x->maCauHoi); ?>', {
                                            filebrowserUploadUrl: "<?php echo e(route('upload', ['_token' => csrf_token() ])); ?>",
                                            filebrowserUploadMethod: 'form'
                                        } );
                                    </script>
                                  </div>
                                
                                  <div class="form-group">
                                    <label for=""> Đáp ứng kết quả học tập:</label>
                                    <select name="maKQHT" id="" class="form-control" required>
                                      <?php $__currentLoopData = $kqht; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($x->maKQHT); ?>"><?php echo e($x->maKQHTVB); ?>-<?php echo e($x->tenKQHT); ?></option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                  </div>
                                </div>
                                <div class="modal-footer">
                                  <button type="submit" class="btn btn-primary">Lưu</button>
                                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
                                </div>
                              </div>
                            </form>
                            
                          </div>
                        </div>
                       </td>
                     </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                  
                </tbody>
                <tfoot></tfoot>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('giangvien.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abet/domains/abet.ktcn.tvu.edu.vn/public_html/resources/views/giangvien/hocphan/chuong/muc/cauhoi/index_tuluan.blade.php ENDPATH**/ ?>