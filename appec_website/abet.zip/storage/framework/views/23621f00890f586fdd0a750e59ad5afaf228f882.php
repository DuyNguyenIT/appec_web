<?php $__env->startSection('content'); ?>
<div class="content-wrapper" style="min-height: 22px;">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">
              <?php echo e(__('Level-1 Student Outcomes')); ?> <noscript></noscript>
              <nav></nav>
            </h1>
          </div>
          <!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(asset('/quan-ly')); ?>"><?php echo e(__('Home')); ?></a></li>
              <li class="breadcrumb-item active"><?php echo e(__('Level-1 Student Outcomes')); ?></li>
            </ol>
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">

              <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                        <i class="fas fa-plus"></i>
              </button>

                <!-- Modal -->
                <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <form action="<?php echo e(asset('quan-ly/chuan-dau-ra/them')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Add')); ?></h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">x</span>
                          </button>
                        </div>
                        <div class="modal-body">
                          <div class="form-group">

                            <label for=""><?php echo e(__('Level-1 Student Outcome ID')); ?>:</label>
                            <input type="text" name="maCDR1VB" class="form-control" placeholder="">
                          </div>
                            <div class="form-group">
                              <label for=""><?php echo e(__('Level-1 Student Outcome Name')); ?>:</label>
                              <input type="text" name="tenCDR1" class="form-control" placeholder="">
                            </div>
                            <div class="form-group">
                              <label for=""><?php echo e(__('Level-1 Student Outcome Name')); ?> (EN):</label>
                              <input type="text" name="tenCDR1EN" class="form-control" placeholder="">
                            </div>
                        </div>
                        <div class="modal-footer"> 
                          <button type="submit" class="btn btn-primary"><?php echo e(_('Save')); ?></button>
                          <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                        </div>
                      </div>
                    </form>
                </div>
                </div> 
                </h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example2" class="table table-bordered table-hover">
                  <thead>
                    <tr>
                      <th><?php echo e(__('No.')); ?></th>
                      <th><?php echo e(__('Level-1 Student Outcomes ID')); ?></th>
                      <th><?php echo e(__('Level-1 Student Outcomes Name')); ?> </th>
                      <th><?php echo e(__('Option')); ?></th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                        $i=1;
                    ?>
                    <?php $__currentLoopData = $chuandaura; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cdr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($cdr->maCDR1VB); ?></td>
                        <td>
                          <?php if(Session::has('language') && Session::get('language')=='vi'): ?>
                              <?php echo e($cdr->tenCDR1); ?>

                          <?php else: ?>
                              <?php echo e($cdr->tenCDR1EN); ?>s
                          <?php endif; ?>
                        </td>
                        <td>
                         
                          <div class="btn-group">
                            <button title="Edit" class="btn btn-success" data-toggle="modal" data-target="#edit_<?php echo e($cdr->maCDR1); ?>">
                              <i class="fas fa-edit"></i> 
                            </button>
                          <a title="Delete" class="btn btn-danger" onclick="return confirm('Do you want to delete <?php echo e($cdr->tenCDR1); ?>?')" href="<?php echo e(asset('quan-ly/chuan-dau-ra/xoa/'.$cdr->maCDR1)); ?>"><i class="fa fa-trash"></i></a>

                          </div>
                          <a href="<?php echo e(asset('/quan-ly/chuan-dau-ra/chuan-dau-ra-2/'.$cdr->maCDR1)); ?>" class="btn btn-primary">
                                <i class="fas fa-align-justify"></i><?php echo e(__('Level-2 Student Outcomes')); ?>

                          </a>  
                         
                              <div class="modal fade" id="edit_<?php echo e($cdr->maCDR1); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                  <form action="<?php echo e(asset('quan-ly/chuan-dau-ra/sua')); ?>" method="post">
                                  <?php echo csrf_field(); ?>
                              
                                  <div class="modal-content">
                                    <div class="modal-header">
                                      <h5 class="modal-title" id="exampleModalLabel">
                                        Editing Level-1 Student Outcome Information
                                      </h5>
                                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">x</span>
                                      </button>
                                    </div>
                                    <div class="modal-body">
                                      <input type="text" name="maCDR1" value="<?php echo e($cdr->maCDR1); ?>" class="form-control" hidden>
                                      <!-- PTTMai th�m -->
                                      <div class="form-group">
                                        <label for=""><?php echo e(__('Level-1 Student Outcome ID')); ?>:</label>
                                        <input type="text" name="maCDR1VB" class="form-control" value="<?php echo e($cdr->maCDR1VB); ?>">
                                      </div> 
                                      
                                      <div class="form-group">
                                        <label for=""><?php echo e(__('Level-1 Student Outcome Name')); ?></label>
                                        <input type="text" name="tenCDR1" class="form-control" value="<?php echo e($cdr->tenCDR1); ?>">
                                      </div>

                                      <div class="form-group">
                                        <label for=""><?php echo e(__('Level-1 Student Outcome Name')); ?> (EN)</label>
                                        <input type="text" name="tenCDR1EN" class="form-control" value="<?php echo e($cdr->tenCDR1EN); ?>">
                                      </div>
                                      <!-- h&#7871;t PTTMai th�m -->
                                    </div> <!-- end modal-body-->
                                  </form>
                                    <div class="modal-footer">
                                      <button type="submit" class="btn btn-primary"><?php echo e(__('Update')); ?></button>
                                      <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                                    </div> 
                                </div>
                              </div>
                          </div>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                  <tfoot></tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2_Co Nam\1_source code\appec_web\appec_web\appec_website\resources\views/admin/chuandaura/chuanDR1.blade.php ENDPATH**/ ?>