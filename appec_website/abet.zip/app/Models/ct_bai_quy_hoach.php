<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ct_bai_quy_hoach extends Model
{
    use HasFactory;
    protected $table='ct_bai_quy_hoach';
    protected $primaryKey = 'maCTBaiQH';
    public $fillable=['maLoaiDG','maLoaiHTDG','maBaiQH','trongSo','maGV_2','isDelete'];
}
