<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class mucDoDatDuoc extends Model
{
    use HasFactory;
    protected $table='muc_do_dat_duoc';
}
