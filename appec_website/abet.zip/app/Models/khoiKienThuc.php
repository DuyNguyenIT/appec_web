<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class khoiKienThuc extends Model
{
    use HasFactory;
    protected $table='khoi_kien_thuc';
    protected $primaryKey='maKhoiKT';
    public $incrementing=false;
}
