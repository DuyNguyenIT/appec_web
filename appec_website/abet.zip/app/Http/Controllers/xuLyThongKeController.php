<?php

namespace App\Http\Controllers;

use App\Models\CDR3;
use App\Models\deThi;
use Illuminate\Http\Request;
use App\Models\danhgia_tuluan;
use session;

class xuLyThongKeController extends Controller
{
     //tao cac ham thong ke dung chung giua giao vu va giang vien
    
    //ham tra ve so lieu thong ke diem phieu cham theo tieu chi CDR3
    public static function thong_ke_CDR3($maCTBaiQH)
    {
        $chuan_dau_ra3=[];
        $chuan_dau_ra3_array=[];
        $phuongan=[];
        //duyet dethi
        $ds_de_thi=deThi::where('isDelete',false)->where('maCTBaiQH',$maCTBaiQH)->get();
        //tach lay CDR3 trong de thi
        $i=0;
        foreach($ds_de_thi as $dt){
            //de_thi->de_thi_cauhoi_tuluan-->cau_hoi
            //              |____________>phuong_an_tu_luan-->cdr_cd3
            $cdr3=deThi::where('de_thi.isDelete',false)
            ->where('maCTBaiQH',$maCTBaiQH)
            ->join('de_thi_cauhoi_tuluan',function($x){
                $x->on('de_thi_cauhoi_tuluan.maDe','=','de_thi.maDe');
            })
            ->join('phuong_an_tu_luan',function($x){
                $x->on('de_thi_cauhoi_tuluan.maPATL','=','phuong_an_tu_luan.id');
            })
            ->join('cdr_cd3',function($x){
                $x->on('cdr_cd3.maCDR3','=','phuong_an_tu_luan.maCDR3')
                ->where('cdr_cd3.isDelete',false);
            })
            ->distinct(['cdr_cd3.maCDR3','cdr_cd3.tenCDR3'])
            ->orderBy('cdr_cd3.maCDR3')
            ->get(['cdr_cd3.maCDR3','cdr_cd3.maCDR3VB','cdr_cd3.tenCDR3']);
            //tach maCDR3 tu nhieu de thi thanh 1 mang
            foreach ($cdr3 as $value) {
                if(!in_array($value['maCDR3'],$chuan_dau_ra3_array)){
                   $chuan_dau_ra3_array[$i]=$value['maCDR3'];
                   $i++;
                }
            }
        }
        //lay noi dung cdr3
        $chuan_dau_ra3=CDR3::where('isDelete',false)->whereIn('maCDR3',$chuan_dau_ra3_array)->get();
        //lay tat ca phieu cham thuoc de_thi
        $phieuCham=deThi::where('de_thi.isDelete',false)
        ->where('maCTBaiQH',$maCTBaiQH)
        ->join('phieu_cham',function($x){
            $x->on('phieu_cham.maDe','=','de_thi.maDe')
            ->where('phieu_cham.maGV',Session::get('maGV'))
            ->where('phieu_cham.isDelete',false);
        })
        ->get(['phieu_cham.maPhieuCham','phieu_cham.maDe']);
        //bien du lieu thong ke
        $data=[];
        //duyet qua tat ca chuan dau ra
        foreach ($chuan_dau_ra3 as $cdr3) {

            $temp=[];
            //lay noi dung cdr3
            array_push($temp,$cdr3->maCDR3VB);
            array_push($temp,$cdr3->tenCDR3);
            //bien dem
            $dat_A=$dat_B=$dat_C=$dat_D=$cdat=$diem_tieu_chi=0;

            foreach ($phieuCham as $pc) {
                $t=$cdr3->maCDR3;
                //dethi
                $dethi=deThi::where('isDelete',false)->where('maDe',$pc->maDe)->first();
                //dethi->phuongAn
                $phuongan=deThi::where('de_thi.isDelete',false)
                ->where('de_thi.maDe',$dethi->maDe)
                ->where('maCTBaiQH',$maCTBaiQH)
                ->join('de_thi_cauhoi_tuluan',function($x){
                    $x->on('de_thi_cauhoi_tuluan.maDe','=','de_thi.maDe');
                })
                ->join('phuong_an_tu_luan',function($x){
                   $x->on('de_thi_cauhoi_tuluan.maPATL','=','phuong_an_tu_luan.id');
               })
               ->get(['phuong_an_tu_luan.id','phuong_an_tu_luan.noiDungPA','phuong_an_tu_luan.diemPA','phuong_an_tu_luan.maCDR3']);
               //phuongan->diem_tieu_chi
                $diem_tieu_chi=$phuongan->where('maCDR3',$cdr3->maCDR3)->sum('diemPA');

                //điếm theo phiếu chấm
                $dem=danhgia_tuluan::where('maPhieuCham',$pc->maPhieuCham)
                ->join('phuong_an_tu_luan',function($x) use ($t){
                    $x->on('phuong_an_tu_luan.id','=','danhgia_tuluan.maPATL')
                    ->where('phuong_an_tu_luan.maCDR3',$t);
                })
                ->sum('danhgia_tuluan.diemDG');
               

                $tile=number_format($dem/$diem_tieu_chi,2);

                if($tile<0.25){
                    $cdat++;
                }else{
                    if($tile>=0.25 && $tile<0.5){
                        $dat_D++;
                    }else{
                        if($tile>=0.5 && $tile<0.75){
                            $dat_C++;
                        }else{
                            if($tile>=0.75 && $tile<0.85){
                                $dat_B++;
                            }else{
                                $dat_A++;
                            }
                        }
                    }
                }
            }

            array_push($temp,$dat_A);
            array_push($temp,$dat_B);
            array_push($temp,$dat_C);
            array_push($temp,$dat_D);
            array_push($temp,$cdat);
            array_push($data,$temp);
        }

        return $data;
    }
}
