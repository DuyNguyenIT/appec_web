<?php

namespace App\Http\Controllers\giangvien;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class GVThongkeController extends Controller
{
    public function index($maCTBaiQH)
    {
        //maCTBaiQH->ct_bai_quy_hoach->maLoaiHTDG
        //T1
        //T2
        //T3
        //T8
    }

    public function FunctionName(Type $var = null)
    {
        # code...
    }
}
