<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class kqHTHP_CDR3 extends Model
{
    use HasFactory;
    protected $table='kqht_hp_cdrcd3';
}
