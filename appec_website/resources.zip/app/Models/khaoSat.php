<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class khaoSat extends Model
{
    use HasFactory;
    protected $table='khao_sat';
}
